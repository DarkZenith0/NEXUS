import json
import os
import sys
import time
from pathlib import Path

def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent

BASE_DIR    = get_base_dir()
CONFIG_DIR  = BASE_DIR / "config"
CONFIG_FILE = CONFIG_DIR / "api_keys.json"

def ensure_config_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

def config_exists() -> bool:
    return CONFIG_FILE.exists()

_CONFIG_CACHE: dict | None = None
_CONFIG_MTIME: float = 0.0

def _write_config_data(data: dict) -> None:
    global _CONFIG_CACHE, _CONFIG_MTIME
    ensure_config_dir()
    tmp_path = CONFIG_FILE.with_suffix(f".tmp.{os.getpid()}.{time.time_ns()}")
    try:
        tmp_path.write_text(json.dumps(data, indent=4, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp_path, CONFIG_FILE)
    except Exception:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except Exception:
                pass
        raise
    _CONFIG_CACHE = dict(data)
    try:
        _CONFIG_MTIME = CONFIG_FILE.stat().st_mtime
    except Exception:
        _CONFIG_MTIME = 0.0

def save_api_keys(gemini_api_key: str) -> None:
    data = load_api_keys()
    data["gemini_api_key"] = gemini_api_key.strip()
    _write_config_data(data)

def load_api_keys() -> dict:
    global _CONFIG_CACHE, _CONFIG_MTIME
    if not CONFIG_FILE.exists():
        _CONFIG_CACHE = {}
        _CONFIG_MTIME = 0.0
        return {}
    try:
        mtime = CONFIG_FILE.stat().st_mtime
        if _CONFIG_CACHE is not None and mtime == _CONFIG_MTIME:
            return dict(_CONFIG_CACHE)
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        _CONFIG_CACHE = data
        _CONFIG_MTIME = mtime
        return dict(data)
    except Exception as e:
        if _CONFIG_CACHE is not None:
            return dict(_CONFIG_CACHE)
        print(f"❌ Failed to load api_keys.json: {e}")
        return {}

def get_gemini_key() -> str | None:
    return load_api_keys().get("gemini_api_key")

def is_configured() -> bool:
    key = get_gemini_key()
    return bool(key and len(key) > 15)


def get_assistant_name() -> str:
    """Return the configured assistant name, or 'NEXUS' if not set."""
    return load_api_keys().get("assistant_name", "NEXUS") or "NEXUS"


def get_user_name() -> str:
    """Return the configured user name for addressing."""
    return load_api_keys().get("user_name", "")


def save_assistant_config(assistant_name: str, user_name: str) -> None:
    """Persist assistant name and user name to config."""
    data = load_api_keys()
    data["assistant_name"] = assistant_name.strip() or "NEXUS"
    data["user_name"] = user_name.strip()
    _write_config_data(data)


# ── Assistant voice ──────────────────────────────────────────────────────────
# Gemini Live prebuilt voices (all 30 supported by Gemini 2.0 / 3.x Live models).
AVAILABLE_VOICES = [
    "Charon", "Puck", "Kore", "Fenrir", "Aoede",
    "Zephyr", "Leda", "Orus", "Callirrhoe", "Autonoe",
    "Enceladus", "Iapetus", "Umbriel", "Algieba", "Despina",
    "Erinome", "Algenib", "Rasalgethi", "Laomedeia", "Achernar",
    "Alnilam", "Schedar", "Gacrux", "Pulcherrima", "Achird",
    "Zubenelgenubi", "Vindemiatrix", "Sadachbia", "Sadaltager", "Sulafat"
]
DEFAULT_VOICE = "Charon"

SPANISH_VOICE_NAMES = [
    "es-ES-AlvaroNeural",
    "es-ES-ElviraNeural",
    "es-MX-JorgeNeural",
    "es-MX-DaliaNeural",
    "es-AR-TomasNeural",
    "es-CO-GonzaloNeural",
    "es-US-AlonsoNeural",
    "es-US-PalomaNeural"
]
DEFAULT_SPANISH_VOICE = "es-ES-AlvaroNeural"


def get_voice() -> str:
    """Return the configured Live/TTS voice, falling back to the default if unset."""
    v = load_api_keys().get("voice_name", DEFAULT_VOICE) or DEFAULT_VOICE
    if v in AVAILABLE_VOICES or v in SPANISH_VOICE_NAMES:
        return v
    return DEFAULT_VOICE


def save_voice(voice_name: str) -> None:
    """Persist the chosen voice."""
    v = (voice_name or "").strip()
    target = v if (v in AVAILABLE_VOICES or v in SPANISH_VOICE_NAMES) else DEFAULT_VOICE
    _patch_config(voice_name=target)


def get_voice_engine() -> str:
    """Return the voice synthesis engine: 'gemini', 'edge-tts', or 'elevenlabs'."""
    eng = str(load_api_keys().get("voice_engine", "")).lower().strip()
    if eng in ("elevenlabs", "eleven_labs", "eleven"):
        return "elevenlabs"
    if eng in ("edge-tts", "edgetts", "spanish"):
        return "edge-tts"
    current_voice = get_voice()
    if current_voice in SPANISH_VOICE_NAMES:
        return "edge-tts"
    return "gemini"


def save_voice_engine(engine: str) -> None:
    e = str(engine or "").lower().strip()
    if e in ("elevenlabs", "eleven_labs", "eleven"):
        eng = "elevenlabs"
    elif e in ("edge-tts", "edgetts", "spanish"):
        eng = "edge-tts"
    else:
        eng = "gemini"
    _patch_config(voice_engine=eng)


# ── ElevenLabs configuration ──────────────────────────────────────────────────

def get_elevenlabs_key() -> str:
    """Return the ElevenLabs API key, or '' if not configured."""
    return str(load_api_keys().get("elevenlabs_api_key", "")).strip()


def save_elevenlabs_key(key: str) -> None:
    _patch_config(elevenlabs_api_key=str(key or "").strip())


def get_elevenlabs_model() -> str:
    """Return configured model for ElevenLabs: defaults to 'eleven_flash_v2_5'."""
    return str(load_api_keys().get("elevenlabs_model", "eleven_flash_v2_5")).strip() or "eleven_flash_v2_5"


def save_elevenlabs_model(model: str) -> None:
    _patch_config(elevenlabs_model=str(model or "eleven_flash_v2_5").strip())


def get_elevenlabs_voice() -> str:
    """Return configured voice ID for ElevenLabs: defaults to Roger."""
    return str(load_api_keys().get("elevenlabs_voice", "CwhRBWXzGAHq8TQ4Fs17")).strip() or "CwhRBWXzGAHq8TQ4Fs17"


def save_elevenlabs_voice(voice_id: str) -> None:
    _patch_config(elevenlabs_voice=str(voice_id or "").strip())



# ── Sound Effects (SFX) ──────────────────────────────────────────────────────

def get_sfx_enabled() -> bool:
    """Whether high-tech HUD audio chimes and cues are enabled."""
    return bool(load_api_keys().get("sfx_enabled", True))


def save_sfx_enabled(enabled: bool) -> None:
    _save_flag("sfx_enabled", bool(enabled))


def get_sfx_volume() -> float:
    """HUD sound effects volume between 0.0 and 1.0."""
    return float(load_api_keys().get("sfx_volume", 0.7))


def save_sfx_volume(volume: float) -> None:
    v = float(max(0.0, min(1.0, volume)))
    _patch_config(sfx_volume=v)



def get_wake_word_enabled() -> bool:
    """Whether local wake-word gating is on (assistant sleeps until 'Hey Jarvis')."""
    return load_api_keys().get("wake_word_enabled", False)


def save_wake_word_enabled(enabled: bool) -> None:
    _save_flag("wake_word_enabled", bool(enabled))


def get_push_to_talk_enabled() -> bool:
    """Hold-a-key-to-speak. When on, the mic is closed unless the chord is held."""
    return load_api_keys().get("push_to_talk_enabled", False)


def save_push_to_talk_enabled(enabled: bool) -> None:
    _save_flag("push_to_talk_enabled", enabled)


HUD_STYLES = ("face", "core")


def get_hud_style() -> str:
    """Which centrepiece the HUD draws: the animated head, or the reactor core.

    Taste, not capability — both render in the same software painter and cost
    about the same. Defaults to the head because that is what MARK LIV shipped
    with; anyone who preferred the older look can switch back in ⚙ and the
    choice survives a restart.
    """
    v = str(load_api_keys().get("hud_style", "face")).strip().lower()
    return v if v in HUD_STYLES else "face"


def save_hud_style(style: str) -> None:
    s = str(style or "").strip().lower()
    _save_flag("hud_style", s if s in HUD_STYLES else "face")


# ── Live-session tuning ──────────────────────────────────────────────────────
# Everything here is optional and has a working default, so an untouched
# config behaves exactly like a configured one. Each value is also a way out:
# if a future model dislikes one of these, set it back and nothing else changes.

def get_thinking_enabled() -> bool:
    """Whether the Live model may spend tokens thinking before it answers.

    Off by default. A voice assistant is judged on how fast it starts talking,
    and the reasoning that actually needs deliberation in this app is delegated
    to the planning tools, which run on a separate non-Live model.
    """
    return bool(load_api_keys().get("thinking_enabled", False))


def save_thinking_enabled(enabled: bool) -> None:
    _save_flag("thinking_enabled", enabled)


def get_turn_tuning() -> dict:
    """How eagerly the server decides you have stopped speaking.

    OFF by default, and that default was earned. Cutting turns shorter looks
    like a free speed win and is not: proactive audio has to judge whether an
    utterance was even addressed to the assistant, and a turn clipped early
    gives it less to judge, so it stays quiet — and the reply to your first
    sentence only arrives once your second one has given it enough context.
    That reads as the assistant being a turn behind, which is far worse than
    the fraction of a second the tuning saves.

    Turn it on with "turn_tuning": {"enabled": true} if your own microphone and
    speaking pace suit it. `silence_ms` is the one that is felt: the pause the
    server sits through before accepting your turn is over.
    """
    cfg = load_api_keys().get("turn_tuning")
    cfg = cfg if isinstance(cfg, dict) else {}

    def _int(key, default, lo, hi):
        try:
            return max(lo, min(hi, int(cfg.get(key, default))))
        except (TypeError, ValueError):
            return default

    return {
        "enabled":    bool(cfg.get("enabled", True)),
        "silence_ms": _int("silence_ms", 450, 200, 3000),
        "prefix_ms":  _int("prefix_ms", 100, 0, 1000),
        # "high" = quicker to decide speech has ended.
        "end_sensitivity":   str(cfg.get("end_sensitivity", "high")).lower(),
        "start_sensitivity": str(cfg.get("start_sensitivity", "high")).lower(),
    }


def save_turn_tuning(values: dict) -> None:
    ensure_config_dir()
    data: dict = {}
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    cur = data.get("turn_tuning")
    cur = dict(cur) if isinstance(cur, dict) else {}
    cur.update(values or {})
    data["turn_tuning"] = cur
    CONFIG_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")


def get_proactive_audio_enabled() -> bool:
    """Whether the model gets to decide an utterance was not aimed at it and
    stay quiet.

    Off by default — keeping it False ensures the model answers every user
    utterance reliably rather than ignoring speech it misjudges as room noise.
    """
    return bool(load_api_keys().get("proactive_audio", False))


def save_proactive_audio_enabled(enabled: bool) -> None:
    _save_flag("proactive_audio", enabled)


MEDIA_RESOLUTIONS = ("default", "low", "medium", "high")


def get_media_resolution() -> str:
    """How finely the model tokenises the screenshots and camera frames it is
    sent. 'medium' keeps on-screen text readable at a fraction of the tokens a
    full-resolution frame costs; 'low' is cheaper still but starts losing small
    text, which is most of what screen captures are for."""
    v = str(load_api_keys().get("media_resolution", "medium")).strip().lower()
    return v if v in MEDIA_RESOLUTIONS else "medium"


def save_media_resolution(value: str) -> None:
    v = str(value or "").strip().lower()
    _save_flag("media_resolution", v if v in MEDIA_RESOLUTIONS else "medium")


def _save_flag(key: str, value) -> None:
    """Read-modify-write one key without disturbing the rest of the config."""
    data = load_api_keys()
    data[key] = bool(value) if isinstance(value, bool) else value
    _write_config_data(data)


def get_brief_enabled() -> bool:
    return load_api_keys().get("morning_brief_enabled", True)


def save_brief_enabled(enabled: bool) -> None:
    _save_flag("morning_brief_enabled", bool(enabled))


# ── Audio devices ────────────────────────────────────────────────────────────
# Stored as device NAMES, not sounddevice indices. Indices shift every time a
# USB device is plugged in or removed, so a saved index silently starts pointing
# at a different microphone. The empty string means "system default", which is
# both the factory setting and what an unresolvable saved device falls back to —
# so unplugging a headset degrades to the built-in speakers instead of crashing.

def _patch_config(**fields) -> None:
    """Read-modify-write one or more keys in api_keys.json."""
    data = load_api_keys()
    data.update(fields)
    _write_config_data(data)


def get_input_device() -> str:
    """Microphone device name, or '' for the system default."""
    return (load_api_keys().get("input_device", "") or "").strip()


def save_input_device(name: str) -> None:
    _patch_config(input_device=(name or "").strip())


def get_output_device() -> str:
    """Speaker device name, or '' for the system default."""
    return (load_api_keys().get("output_device", "") or "").strip()


def save_output_device(name: str) -> None:
    _patch_config(output_device=(name or "").strip())


def get_plugin_enabled(plugin_name: str) -> bool:
    """Plugins are enabled by default the moment they're discovered (opt-out model)."""
    return load_api_keys().get("plugins_enabled", {}).get(plugin_name, True)


# ── Per-plugin settings ("tokens" / connection details) ───────────────────────
# Generic store so a plugin can declare its own config fields (PLUGIN_SETTINGS)
# and the settings UI renders + persists them WITHOUT any core edit — keeping the
# drop-in model intact. Values live under plugin_config[<namespace>][<key>].
# A namespace defaults to the plugin name, but a suite of plugins (e.g. the
# several printer plugins) can share ONE namespace.
def get_plugin_config(namespace: str) -> dict:
    """All stored values for a namespace (empty dict if none set yet)."""
    cfg = load_api_keys().get("plugin_config")
    val = cfg.get(namespace) if isinstance(cfg, dict) else None
    return dict(val) if isinstance(val, dict) else {}


def get_plugin_setting(namespace: str, key: str, default=None):
    """A single value from a namespace, or `default` if unset."""
    return get_plugin_config(namespace).get(key, default)


def save_plugin_config(namespace: str, values: dict) -> None:
    """Merge `values` into a namespace's stored config."""
    data = load_api_keys()
    pc = data.get("plugin_config")
    if not isinstance(pc, dict):
        pc = {}
    cur = pc.get(namespace)
    if not isinstance(cur, dict):
        cur = {}
    cur.update(values)
    pc[namespace] = cur
    data["plugin_config"] = pc
    _write_config_data(data)


def save_plugin_enabled(plugin_name: str, enabled: bool) -> None:
    data = load_api_keys()
    plugins_cfg = data.get("plugins_enabled")
    if not isinstance(plugins_cfg, dict):
        plugins_cfg = {}
    plugins_cfg[plugin_name] = bool(enabled)
    data["plugins_enabled"] = plugins_cfg
    _write_config_data(data)


def get_mini_player_pos() -> tuple[int, int] | None:
    """Return the saved (x, y) coordinates for the floating MiniPlayer, or None."""
    data = load_api_keys()
    x = data.get("mini_pos_x")
    y = data.get("mini_pos_y")
    if isinstance(x, (int, float)) and isinstance(y, (int, float)):
        return int(x), int(y)
    return None


def save_mini_player_pos(x: int, y: int) -> None:
    """Persist the floating MiniPlayer screen position."""
    _patch_config(mini_pos_x=int(x), mini_pos_y=int(y))


def get_mini_mode_enabled() -> bool:
    """Return whether NEXUS was last running in floating MiniPlayer mode."""
    return bool(load_api_keys().get("mini_mode_enabled", False))


def save_mini_mode_enabled(enabled: bool) -> None:
    """Persist the active UI mode (True for MiniPlayer, False for Full HUD)."""
    _patch_config(mini_mode_enabled=bool(enabled))