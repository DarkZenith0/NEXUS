@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title N.E.X.U.S V4 - Sistema Inteligente
cd /d "%~dp0"

set "PY_CMD="
py -3 --version >nul 2>&1 && set "PY_CMD=py -3"
if not defined PY_CMD python --version >nul 2>&1 && set "PY_CMD=python"
if not defined PY_CMD if exist "C:\Python314\python.exe" set "PY_CMD=C:\Python314\python.exe"
if not defined PY_CMD if exist "C:\Program Files\Python312\python.exe" set "PY_CMD=C:\Program Files\Python312\python.exe"
if not defined PY_CMD if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY_CMD=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"

if not defined PY_CMD (
    echo [ERROR] No se encuentra Python.
    echo Ejecuta primero: 1_INSTALAR_PYTHON.bat
    pause
    exit /b 1
)

:: Crear acceso directo en el Escritorio si no existe
set "SHORTCUT=%USERPROFILE%\Desktop\NEXUS V4.lnk"
if not exist "%SHORTCUT%" (
    echo [*] Creando acceso directo en el Escritorio...
    powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath = '%~dp03_INICIAR_NEXUS.bat'; $s.WorkingDirectory = '%~dp0'; if (Test-Path '%~dp0config\nexus.ico') { $s.IconLocation = '%~dp0config\nexus.ico' }; $s.Description = 'N.E.X.U.S V4 - Asistente Inteligente IA'; $s.Save()" >nul 2>&1
    if exist "%SHORTCUT%" echo [OK] Acceso directo 'NEXUS V4' creado en tu Escritorio.
)

echo ===============================================================================
echo                       INICIANDO N.E.X.U.S V4
echo ===============================================================================
echo.
echo * Primer inicio:
echo   1. Se abrira una ventana pidiendote tu clave de Google AI Studio (gratuita).
echo      Consiguela en: https://aistudio.google.com/app/apikey
echo   2. Puedes conectar tus dispositivos moviles mediante WiFi / Tailscale.
echo   3. Opcional: Clave ElevenLabs si deseas clonacion de voz ultra-realista.
echo   4. Opcional: Modelos locales en Ollama (qwen2.5-coder:3b o llama3.2:3b).
echo.
echo Lanzando el motor de N.E.X.U.S...
echo ===============================================================================
echo.

%PY_CMD% main.py

if %errorlevel% neq 0 (
    echo.
    echo [!] N.E.X.U.S se cerro con codigo de salida: %errorlevel%
    echo Si falta alguna libreria, ejecuta: 2_INSTALAR_DEPENDENCIAS.bat
    pause
)
