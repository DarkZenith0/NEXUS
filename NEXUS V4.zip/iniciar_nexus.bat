@echo off
cd /d "%~dp0"
title NEXUS Launcher

set "PY_EXE="
where pythonw >nul 2>&1
if %errorlevel% equ 0 (
    set "PY_EXE=pythonw"
) else (
    where py >nul 2>&1
    if %errorlevel% equ 0 (
        set "PY_EXE=py -3"
    ) else (
        where python >nul 2>&1
        if %errorlevel% equ 0 (
            set "PY_EXE=python"
        )
    )
)

if "%PY_EXE%"=="" (
    echo [ERROR] No se encuentra Python instalado en tu equipo.
    echo Ejecuta primero 'instalar_nexus.bat'.
    pause
    exit /b 1
)

start "" %PY_EXE% "main.py"
exit /b 0
