"""
core/sfx.py — Futuristic sound effects (SFX) engine for N.E.X.U.S V2.

Generates high-fidelity sci-fi chimes and audio feedback mathematically
via numpy and sounddevice. Zero external audio asset dependencies,
zero latency, and fully customizable volume and toggle.
"""

from __future__ import annotations

import threading
import numpy as np
import sounddevice as sd
from typing import Optional

SAMPLE_RATE = 24000


def _build_chime(notes: list[tuple[float, float, float]], duration: float = 0.35) -> np.ndarray:
    """
    Synthesize an organic sci-fi harmonic chime.
    notes: list of (frequency_hz, start_time_sec, relative_amplitude)
    """
    total_samples = int(SAMPLE_RATE * duration)
    t = np.linspace(0, duration, total_samples, endpoint=False)
    signal = np.zeros(total_samples, dtype=np.float32)

    for freq, start_sec, amp in notes:
        start_idx = int(SAMPLE_RATE * start_sec)
        if start_idx >= total_samples:
            continue
        seg_t = t[start_idx:] - start_sec
        # Smooth exponential decay with warm overtone
        env = np.exp(-11.0 * seg_t)
        # Fundamental tone + soft octave overtone
        tone = np.sin(2 * np.pi * freq * seg_t) + 0.25 * np.sin(2 * np.pi * (freq * 2) * seg_t)
        # Soft attack curve (5ms) to prevent any clicking
        attack_len = min(len(seg_t), int(SAMPLE_RATE * 0.005))
        if attack_len > 0:
            env[:attack_len] *= np.linspace(0, 1, attack_len)
        signal[start_idx:] += (tone * env * amp).astype(np.float32)

    # Normalize max amplitude to prevent clipping
    peak = np.max(np.abs(signal))
    if peak > 1e-4:
        signal = (signal / peak) * 0.65
    return signal.astype(np.float32)


# ── Sound Presets ─────────────────────────────────────────────────────────────

def _gen_wake_sound() -> np.ndarray:
    """Ascending futuristic harmonic chord (D5 -> A5 -> D6) when waking up."""
    return _build_chime([
        (587.33, 0.00, 0.7),  # D5
        (880.00, 0.06, 0.8),  # A5
        (1174.66, 0.12, 0.9), # D6
    ], duration=0.45)


def _gen_sleep_sound() -> np.ndarray:
    """Soft descending resolution chord (A5 -> F#5 -> D5) when powering down."""
    return _build_chime([
        (880.00, 0.00, 0.8),  # A5
        (739.99, 0.07, 0.7),  # F#5
        (587.33, 0.14, 0.6),  # D5
    ], duration=0.45)


def _gen_action_sound() -> np.ndarray:
    """Crisp high-tech acknowledgment beep for action completion."""
    return _build_chime([
        (987.77, 0.00, 0.7),  # B5
        (1318.51, 0.05, 0.9), # E6
    ], duration=0.25)


def _gen_alert_sound() -> np.ndarray:
    """Dual-tone subtle warning pulse."""
    return _build_chime([
        (440.00, 0.00, 0.7),  # A4
        (415.30, 0.09, 0.8),  # G#4
    ], duration=0.35)


def _gen_click_sound() -> np.ndarray:
    """Subtle futuristic UI click / tick."""
    duration = 0.04
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), endpoint=False)
    env = np.exp(-120 * t)
    wave = np.sin(2 * np.pi * 1800 * t) * env * 0.4
    return wave.astype(np.float32)


# Pre-cache sound arrays in memory for zero-latency playback
_SOUND_CACHE: dict[str, np.ndarray] = {}


def _get_sound(name: str) -> np.ndarray:
    if name not in _SOUND_CACHE:
        if name == "wake":
            _SOUND_CACHE[name] = _gen_wake_sound()
        elif name == "sleep":
            _SOUND_CACHE[name] = _gen_sleep_sound()
        elif name == "action":
            _SOUND_CACHE[name] = _gen_action_sound()
        elif name == "alert":
            _SOUND_CACHE[name] = _gen_alert_sound()
        elif name == "click":
            _SOUND_CACHE[name] = _gen_click_sound()
        else:
            _SOUND_CACHE[name] = _gen_action_sound()
    return _SOUND_CACHE[name]


# ── Playback Engine ───────────────────────────────────────────────────────────

class SFXEngine:
    """Thread-safe, non-blocking sound effect dispatcher."""

    _instance: Optional[SFXEngine] = None

    def __init__(self):
        self._enabled = True
        self._volume = 0.7
        self._device_name = ""

    @classmethod
    def get(cls) -> SFXEngine:
        if cls._instance is None:
            cls._instance = SFXEngine()
        return cls._instance

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, val: bool):
        self._enabled = bool(val)

    @property
    def volume(self) -> float:
        return self._volume

    @volume.setter
    def volume(self, val: float):
        self._volume = float(max(0.0, min(1.0, val)))

    def set_output_device(self, name: str):
        self._device_name = name or ""

    def play(self, sound_name: str, volume_factor: float = 1.0):
        """Play sound asynchronously in a worker thread."""
        if not self._enabled:
            return

        def _worker():
            try:
                samples = _get_sound(sound_name)
                vol = self._volume * volume_factor
                scaled = (samples * vol).astype(np.float32)

                # Resolve audio output device if configured
                from core import audio_devices
                dev_idx = audio_devices.resolve("output", self._device_name) if self._device_name else None

                sd.play(scaled, samplerate=SAMPLE_RATE, device=dev_idx)
                sd.wait()
            except Exception as e:
                # SFX must never crash the application
                pass

        threading.Thread(target=_worker, daemon=True, name=f"SFX-{sound_name}").start()

    def play_wake(self):
        self.play("wake", volume_factor=0.85)

    def play_sleep(self):
        self.play("sleep", volume_factor=0.75)

    def play_action(self):
        self.play("action", volume_factor=0.65)

    def play_alert(self):
        self.play("alert", volume_factor=0.8)

    def play_click(self):
        self.play("click", volume_factor=0.5)


# Global singleton helper functions
def sfx_wake():
    SFXEngine.get().play_wake()

def sfx_sleep():
    SFXEngine.get().play_sleep()

def sfx_action():
    SFXEngine.get().play_action()

def sfx_alert():
    SFXEngine.get().play_alert()

def sfx_click():
    SFXEngine.get().play_click()
