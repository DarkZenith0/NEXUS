"""
core/local_llm/tool_bridge.py — Translates NEXUS V3 TOOL declarations to OpenAI/Ollama format,
and parses tool invocation responses from local models.
"""

from __future__ import annotations

import json
import re
from typing import Any


def _normalize_type(t: Any) -> Any:
    if isinstance(t, str):
        mapping = {
            "OBJECT": "object",
            "STRING": "string",
            "INTEGER": "integer",
            "NUMBER": "number",
            "BOOLEAN": "boolean",
            "ARRAY": "array",
        }
        return mapping.get(t.upper(), t.lower())
    return t


def convert_gemini_schema_to_openai(schema: dict) -> dict:
    """Recursively converts a Gemini parameters schema dict into standard JSON schema."""
    if not isinstance(schema, dict):
        return {"type": "object", "properties": {}}

    res = {}
    for k, v in schema.items():
        if k == "type":
            res["type"] = _normalize_type(v)
        elif k == "properties" and isinstance(v, dict):
            res["properties"] = {
                prop_k: convert_gemini_schema_to_openai(prop_v)
                for prop_k, prop_v in v.items()
            }
        elif k == "items" and isinstance(v, dict):
            res["items"] = convert_gemini_schema_to_openai(v)
        else:
            res[k] = v

    if "type" not in res:
        res["type"] = "object"
    return res


def convert_actions_to_openai_tools(action_declarations: list[dict]) -> list[dict]:
    """
    Converts NEXUS action declarations (from action_loader.get_tool_declarations())
    into the standard OpenAI/Ollama tool calling schema:
    [
      {
        "type": "function",
        "function": {
          "name": "...",
          "description": "...",
          "parameters": { ... }
        }
      }
    ]
    """
    openai_tools = []
    for decl in action_declarations:
        name = decl.get("name", "")
        if not name:
            continue
        desc = decl.get("description", "")
        params = decl.get("parameters") or {"type": "OBJECT", "properties": {}}
        openai_tools.append({
            "type": "function",
            "function": {
                "name": name,
                "description": desc,
                "parameters": convert_gemini_schema_to_openai(params)
            }
        })
    return openai_tools


def parse_local_tool_calls(response_message: dict | str) -> list[dict]:
    """
    Extracts tool calls from either:
    1. Native message tool_calls structure:
       {"role": "assistant", "tool_calls": [{"function": {"name": ..., "arguments": ...}}]}
    2. Embedded JSON blocks in markdown:
       ```json
       {"name": "...", "arguments": {...}}
       ```
    3. Custom tags like <tool_call>...</tool_call> or {"tool": "...", "args": ...}

    Returns a list of dicts: [{"name": str, "args": dict}]
    """
    calls: list[dict] = []

    # 1. Native Ollama/OpenAI tool_calls list
    if isinstance(response_message, dict):
        native_calls = response_message.get("tool_calls") or []
        for tc in native_calls:
            func = tc.get("function") or {}
            fn_name = func.get("name")
            raw_args = func.get("arguments")
            if fn_name:
                args = raw_args if isinstance(raw_args, dict) else {}
                if isinstance(raw_args, str):
                    try:
                        args = json.loads(raw_args)
                    except Exception:
                        args = {}
                calls.append({"name": fn_name, "args": args})

        if calls:
            return calls

        # Fallback to checking content string
        content = response_message.get("content") or ""
    else:
        content = str(response_message)

    if not content:
        return []

    # 2. Markdown json blocks
    json_blocks = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", content, re.DOTALL)
    for block in json_blocks:
        try:
            parsed = json.loads(block)
            name = parsed.get("name") or parsed.get("tool") or parsed.get("action")
            args = parsed.get("arguments") or parsed.get("args") or parsed.get("parameters")
            if name:
                calls.append({"name": str(name), "args": args if isinstance(args, dict) else {}})
        except Exception:
            pass

    if calls:
        return calls

    # 3. <tool_call> tags
    tag_matches = re.findall(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", content, re.DOTALL)
    for block in tag_matches:
        try:
            parsed = json.loads(block)
            name = parsed.get("name") or parsed.get("tool")
            args = parsed.get("arguments") or parsed.get("args")
            if name:
                calls.append({"name": str(name), "args": args if isinstance(args, dict) else {}})
        except Exception:
            pass

    return calls
