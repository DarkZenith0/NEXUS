"""
core/local_llm/router.py — Smart LLM Arbiter & Circuit Breaker for NEXUS V4.

Manages seamless routing between Cloud (Gemini Live) and Local Edge models:
- Cloud Frontier: Gemini Live WebSocket (conversational multimodal)
- Local Fast: Qwen 2.5 Coder 3B (low-latency OS actions, tool calling, quick offline chat)
- Local Work: Llama 3.2 3B (in-depth reports, documents, synthesis)
"""

from __future__ import annotations

import asyncio
import enum
import time
from typing import Callable, Optional

from .client import LocalLLMClient, get_local_llm_client
from .config import LocalModelConfig
from .tool_bridge import convert_actions_to_openai_tools


class EngineTier(str, enum.Enum):
    CLOUD = "cloud"              # Gemini Live / Online
    LOCAL_FAST = "local_fast"    # Qwen 2.5 Coder 3B
    LOCAL_WORK = "local_work"    # Llama 3.2 3B


class CircuitState(str, enum.Enum):
    CLOSED = "closed"        # Healthy (Cloud active)
    HALF_OPEN = "half_open"  # Testing recovery
    OPEN = "open"            # Tripped (Offline / Local Fallback active)


class LLMArbiter:
    """Intelligent router orchestrating cloud vs local execution with circuit breaker."""

    def __init__(
        self,
        local_client: Optional[LocalLLMClient] = None,
        action_registry: Optional[object] = None,
        logger: Optional[Callable[[str], None]] = None
    ):
        self.local_client = local_client or get_local_llm_client()
        self.action_registry = action_registry
        self.logger = logger or (lambda msg: None)

        self._circuit_state = CircuitState.CLOSED
        self._consecutive_cloud_failures: int = 0
        self._failure_threshold: int = 2
        self._last_failure_time: float = 0.0
        self._recovery_cooldown_sec: float = 45.0
        self._force_local: bool = False
        self._active_tier: EngineTier = EngineTier.CLOUD

    @property
    def active_tier(self) -> EngineTier:
        return self._active_tier

    @property
    def circuit_state(self) -> CircuitState:
        return self._circuit_state

    def set_force_local(self, force: bool) -> None:
        """Manually force local processing (for 100% offline or privacy mode)."""
        self._force_local = force
        if force:
            self._circuit_state = CircuitState.OPEN
            self._active_tier = EngineTier.LOCAL_FAST
            self.logger("[Arbiter] 🔒 Modo 100% Local Forzado Activado")
        else:
            self._circuit_state = CircuitState.CLOSED
            self._active_tier = EngineTier.CLOUD
            self.logger("[Arbiter] ☁️ Modo Nube / Híbrido Restaurado")

    def record_cloud_success(self) -> None:
        """Called when a cloud session/turn completes successfully."""
        if self._circuit_state != CircuitState.CLOSED and not self._force_local:
            self.logger("[Arbiter] 🟢 Conexión Nube recuperada con éxito. Circuito restablecido.")
        self._consecutive_cloud_failures = 0
        if not self._force_local:
            self._circuit_state = CircuitState.CLOSED
            self._active_tier = EngineTier.CLOUD

    def record_cloud_failure(self, error: Exception | str) -> bool:
        """
        Called when Gemini Live disconnects or times out.
        Returns True if the circuit breaker tripped and local fallback is now active.
        """
        self._consecutive_cloud_failures += 1
        self._last_failure_time = time.time()
        self.logger(f"[Arbiter] ⚠️ Fallo en Nube ({self._consecutive_cloud_failures}/{self._failure_threshold}): {error}")

        if self._consecutive_cloud_failures >= self._failure_threshold or self._force_local:
            if self._circuit_state != CircuitState.OPEN:
                self._circuit_state = CircuitState.OPEN
                self._active_tier = EngineTier.LOCAL_FAST
                self.logger("[Arbiter] ⚡ CIRCUIT BREAKER ACTIVADO: Conmutando a Motor Local (Qwen 2.5 Coder 3B).")
                return True
        return False

    def should_try_cloud(self) -> bool:
        """Returns True if we should attempt online cloud communication."""
        if self._force_local:
            return False
        if self._circuit_state == CircuitState.OPEN:
            # Check if cooldown elapsed to test recovery (half-open)
            if time.time() - self._last_failure_time > self._recovery_cooldown_sec:
                self._circuit_state = CircuitState.HALF_OPEN
                self.logger("[Arbiter] 🟡 Probando reconexión a Nube (Half-Open)...")
                return True
            return False
        return True

    def classify_intent(self, text: str, is_work_mode: bool = False) -> EngineTier:
        """Classifies request into the optimal engine tier."""
        if self._force_local or self._circuit_state == CircuitState.OPEN:
            return EngineTier.LOCAL_WORK if is_work_mode else EngineTier.LOCAL_FAST

        if is_work_mode:
            return EngineTier.LOCAL_WORK

        # Check for heavy report or writing keywords
        lower = text.lower()
        if any(k in lower for k in ("informe", "redacta", "resumen detallado", "documento extenso", "analiza el archivo")):
            return EngineTier.LOCAL_WORK

        return EngineTier.CLOUD

    async def execute_local_fallback(
        self,
        prompt: str,
        mode: str = "fast",
        system_prompt: Optional[str] = None
    ) -> dict:
        """
        Executes a turn locally:
        1. Formats tools from action_registry
        2. Calls local model
        3. If tools are requested, executes them on the action_registry
        4. Returns execution summary
        """
        t0 = time.time()
        openai_tools = None
        if self.action_registry and hasattr(self.action_registry, "get_tool_declarations"):
            decls = self.action_registry.get_tool_declarations()
            openai_tools = convert_actions_to_openai_tools(decls)

        sys_prompt = system_prompt or (
            "Eres N.E.X.U.S, el asistente inteligente para control del PC. "
            "Estás operando en MODO LOCAL OFFLINE. "
            "Responde de forma clara y directa en español. Si el usuario te pide una acción "
            "(como abrir apps, ajustar volumen, buscar archivos), utiliza las herramientas."
        )

        res = await self.local_client.chat(
            messages=[{"role": "user", "content": prompt}],
            tools=openai_tools,
            mode=mode,
            system_prompt=sys_prompt
        )

        tool_results = []
        if res.get("ok") and res.get("tool_calls"):
            for tc in res["tool_calls"]:
                name = tc.get("name")
                args = tc.get("args") or {}
                if self.action_registry and hasattr(self.action_registry, "run"):
                    try:
                        self.logger(f"[Local Arbiter] ⚙️ Ejecutando herramienta local: {name}({args})")
                        out = self.action_registry.run(name, args)
                        tool_results.append({"name": name, "result": str(out)})
                    except Exception as ex:
                        tool_results.append({"name": name, "error": str(ex)})

        return {
            "ok": res.get("ok", False),
            "tier": EngineTier.LOCAL_WORK if mode == "work" else EngineTier.LOCAL_FAST,
            "model": res.get("model", ""),
            "content": res.get("content", ""),
            "tool_calls": res.get("tool_calls", []),
            "tool_results": tool_results,
            "latency_sec": time.time() - t0,
            "error": res.get("error")
        }
