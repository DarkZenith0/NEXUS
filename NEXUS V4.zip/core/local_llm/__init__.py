"""
core/local_llm — N.E.X.U.S V4 Local LLM Integration Layer

Provides local inference, tool-calling bridge, and fallback orchestration:
- Low-latency mode: qwen2.5-coder:3b (fast OS control, tools, rapid Q&A)
- Work mode: llama3.2:3b (reports, documents, deep reasoning)
"""

from .config import LocalModelConfig
from .client import LocalLLMClient, get_local_llm_client
from .tool_bridge import convert_actions_to_openai_tools, parse_local_tool_calls
from .router import LLMArbiter, EngineTier, CircuitState

__all__ = [
    "LocalModelConfig",
    "LocalLLMClient",
    "get_local_llm_client",
    "convert_actions_to_openai_tools",
    "parse_local_tool_calls",
    "LLMArbiter",
    "EngineTier",
    "CircuitState",
]
