"""
core/local_llm/config.py — Configuration and model presets for NEXUS Local LLM.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
CONFIG_FILE = BASE_DIR / "config" / "local_llm_config.json"


@dataclass
class LocalModelConfig:
    enabled: bool = True
    base_url: str = "http://127.0.0.1:11434"
    model_fast: str = "qwen2.5-coder:3b"
    model_work: str = "llama3.2:3b"
    fallback_models: list[str] = field(default_factory=lambda: [
        "qwen2.5-coder:3b",
        "llama3.2:3b",
        "deepseek-r1-coder-tools:1.5b",
        "deepseek-r1:1.5b",
        "deepseek-r1:7b"
    ])
    timeout_sec: float = 45.0
    fast_temperature: float = 0.2
    work_temperature: float = 0.6
    max_context_tokens: int = 8192
    auto_start_ollama: bool = True

    @classmethod
    def load(cls) -> LocalModelConfig:
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        cfg = cls()
        if CONFIG_FILE.exists():
            try:
                data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                for k, v in data.items():
                    if hasattr(cfg, k):
                        setattr(cfg, k, v)
            except Exception:
                pass
        else:
            cfg.save()
        return cfg

    def save(self) -> None:
        try:
            CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "enabled": self.enabled,
                "base_url": self.base_url,
                "model_fast": self.model_fast,
                "model_work": self.model_work,
                "fallback_models": self.fallback_models,
                "timeout_sec": self.timeout_sec,
                "fast_temperature": self.fast_temperature,
                "work_temperature": self.work_temperature,
                "max_context_tokens": self.max_context_tokens,
                "auto_start_ollama": self.auto_start_ollama,
            }
            CONFIG_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
