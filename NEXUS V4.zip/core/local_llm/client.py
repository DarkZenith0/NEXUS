"""
core/local_llm/client.py — High-performance asynchronous client for NEXUS Local LLM Engine.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import time
from typing import AsyncGenerator, Optional

import httpx

from .config import LocalModelConfig
from .tool_bridge import parse_local_tool_calls


class LocalLLMClient:
    """Async client managing local Ollama inference, tool routing, and auto-lifecycle."""

    def __init__(self, config: Optional[LocalModelConfig] = None):
        self.config = config or LocalModelConfig.load()
        self._http = httpx.AsyncClient(
            base_url=self.config.base_url.rstrip("/"),
            timeout=self.config.timeout_sec
        )
        self._server_process: Optional[subprocess.Popen] = None
        self._cached_models: list[str] = []
        self._last_models_check: float = 0.0

    async def close(self) -> None:
        await self._http.aclose()

    async def is_server_online(self) -> bool:
        """Fast health check of the local Ollama server."""
        try:
            r = await self._http.get("/api/tags", timeout=1.5)
            return r.status_code == 200
        except Exception:
            return False

    async def ensure_server(self) -> bool:
        """Ensures the local Ollama server is running, auto-spawning it if enabled."""
        if await self.is_server_online():
            return True

        if not self.config.auto_start_ollama:
            return False

        # Attempt to launch ollama serve
        try:
            flags = 0
            if sys.platform == "win32":
                flags = subprocess.CREATE_NO_WINDOW

            self._server_process = subprocess.Popen(
                ["ollama", "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=flags
            )

            # Wait up to 6 seconds for port to open
            for _ in range(12):
                await asyncio.sleep(0.5)
                if await self.is_server_online():
                    return True
        except Exception:
            pass

        return False

    async def get_available_models(self, force_refresh: bool = False) -> list[str]:
        """Returns list of installed model names in Ollama."""
        now = time.time()
        if not force_refresh and self._cached_models and (now - self._last_models_check < 60.0):
            return self._cached_models

        if not await self.ensure_server():
            return []

        try:
            r = await self._http.get("/api/tags")
            if r.status_code == 200:
                models = [m.get("name", "") for m in r.json().get("models", []) if m.get("name")]
                self._cached_models = models
                self._last_models_check = now
                return models
        except Exception:
            pass

        return self._cached_models

    async def resolve_model(self, mode: str = "fast") -> str:
        """
        Resolves the best available local model for the requested mode:
        'fast' -> config.model_fast (e.g. qwen2.5-coder:3b) with fallbacks.
        'work' -> config.model_work (e.g. llama3.2:3b) with fallbacks.
        """
        installed = await self.get_available_models()
        if not installed:
            return self.config.model_fast

        target = self.config.model_fast if mode == "fast" else self.config.model_work

        # Exact match or tag prefix match (e.g. 'qwen2.5-coder:3b' vs 'qwen2.5-coder:latest')
        for m in installed:
            if m == target or m.startswith(target.split(":")[0]):
                return m

        # Check configured fallbacks
        for fb in self.config.fallback_models:
            for m in installed:
                if m == fb or m.startswith(fb.split(":")[0]):
                    return m

        # Final fallback: first available installed model
        return installed[0]

    async def chat(
        self,
        messages: list[dict],
        tools: Optional[list[dict]] = None,
        mode: str = "fast",
        temperature: Optional[float] = None,
        system_prompt: Optional[str] = None
    ) -> dict:
        """
        Executes a chat completion against the local model with optional tool schemas.
        Returns:
            {
                "ok": bool,
                "content": str,
                "tool_calls": list[dict], # [{"name": "...", "args": {...}}]
                "model": str,
                "latency_sec": float,
                "error": str | None
            }
        """
        t0 = time.time()
        if not await self.ensure_server():
            return {
                "ok": False,
                "content": "",
                "tool_calls": [],
                "model": "",
                "latency_sec": 0.0,
                "error": "Local Ollama server is not running or unreachable"
            }

        model = await self.resolve_model(mode=mode)
        temp = temperature if temperature is not None else (
            self.config.fast_temperature if mode == "fast" else self.config.work_temperature
        )

        # Prepare messages
        chat_msgs = []
        if system_prompt:
            chat_msgs.append({"role": "system", "content": system_prompt})
        chat_msgs.extend(messages)

        payload: dict = {
            "model": model,
            "messages": chat_msgs,
            "stream": False,
            "options": {
                "temperature": temp,
                "num_ctx": self.config.max_context_tokens
            }
        }

        if tools:
            payload["tools"] = tools

        try:
            r = await self._http.post("/api/chat", json=payload)
            latency = time.time() - t0
            if r.status_code != 200:
                return {
                    "ok": False,
                    "content": "",
                    "tool_calls": [],
                    "model": model,
                    "latency_sec": latency,
                    "error": f"Ollama HTTP {r.status_code}: {r.text}"
                }

            data = r.json()
            msg = data.get("message", {})
            content = msg.get("content", "")
            tool_calls = parse_local_tool_calls(msg)

            return {
                "ok": True,
                "content": content,
                "tool_calls": tool_calls,
                "model": model,
                "latency_sec": latency,
                "error": None
            }
        except Exception as e:
            return {
                "ok": False,
                "content": "",
                "tool_calls": [],
                "model": model,
                "latency_sec": time.time() - t0,
                "error": str(e)
            }

    async def chat_stream(
        self,
        messages: list[dict],
        mode: str = "fast",
        temperature: Optional[float] = None,
        system_prompt: Optional[str] = None
    ) -> AsyncGenerator[str, None]:
        """Streams text chunks directly from the local model."""
        if not await self.ensure_server():
            yield "[Error: Local LLM server offline]"
            return

        model = await self.resolve_model(mode=mode)
        temp = temperature if temperature is not None else (
            self.config.fast_temperature if mode == "fast" else self.config.work_temperature
        )

        chat_msgs = []
        if system_prompt:
            chat_msgs.append({"role": "system", "content": system_prompt})
        chat_msgs.extend(messages)

        payload = {
            "model": model,
            "messages": chat_msgs,
            "stream": True,
            "options": {
                "temperature": temp,
                "num_ctx": self.config.max_context_tokens
            }
        }

        try:
            async with self._http.stream("POST", "/api/chat", json=payload) as r:
                async for line in r.aiter_lines():
                    if not line:
                        continue
                    try:
                        chunk = json.loads(line)
                        text = chunk.get("message", {}).get("content", "")
                        if text:
                            yield text
                        if chunk.get("done"):
                            break
                    except Exception:
                        pass
        except Exception as e:
            yield f"[Stream Error: {e}]"


_GLOBAL_CLIENT: Optional[LocalLLMClient] = None


def get_local_llm_client() -> LocalLLMClient:
    """Returns singleton LocalLLMClient instance."""
    global _GLOBAL_CLIENT
    if _GLOBAL_CLIENT is None:
        _GLOBAL_CLIENT = LocalLLMClient()
    return _GLOBAL_CLIENT
