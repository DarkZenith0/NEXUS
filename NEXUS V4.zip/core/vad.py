"""
Voice Activity Detection (VAD) & Utterance Segmentation Engine for N.E.X.U.S.

Provides real-time, robust speech activity detection with:
- Dynamic noise floor tracking (adapts to ambient room sound).
- Pre-roll circular buffering (preserves first syllables/consonants).
- Start/end of speech hysteresis thresholds.
- False positive rejection (short transients, coughs, clicks < min_speech_ms).
- Max utterance protection (prevents hanging listening loops).
- Utterance state machine with clear event callbacks.
"""

from __future__ import annotations

import collections
import math
import time
from typing import NamedTuple
import numpy as np


class VADEvent:
    SILENCE = "SILENCE"
    SPEECH_START = "SPEECH_START"
    SPEECH_CHUNK = "SPEECH_CHUNK"
    SPEECH_END = "SPEECH_END"
    DISCARD = "DISCARD"


class VADResult(NamedTuple):
    event: str
    audio_chunk: bytes | None
    utterance_pcm: bytes | None = None
    speech_duration_ms: float = 0.0
    level: float = 0.0


class VoiceActivityDetector:
    """
    Robust real-time Voice Activity Detector operating on 16kHz mono 16-bit PCM.
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        chunk_size: int = 1024,
        min_speech_ms: int = 240,
        silence_timeout_ms: int = 420,
        max_speech_s: float = 18.0,
        pre_roll_ms: int = 220,
        initial_noise_floor: float = 80.0,
    ):
        self.sample_rate = sample_rate
        self.chunk_size = chunk_size
        self.chunk_duration_ms = (chunk_size / sample_rate) * 1000.0

        self.min_speech_ms = min_speech_ms
        self.silence_timeout_ms = silence_timeout_ms
        self.max_speech_s = max_speech_s

        # Pre-roll ring buffer
        pre_roll_chunks = max(2, int(math.ceil(pre_roll_ms / self.chunk_duration_ms)))
        self._pre_roll = collections.deque(maxlen=pre_roll_chunks)

        # Dynamic Noise Floor
        self._noise_floor = float(initial_noise_floor)
        self._noise_samples_count = 0

        # State machine
        self._is_active = False          # Currently in speech
        self._candidate_frames = 0       # Frames above trigger threshold
        self._silence_frames = 0         # Consecutive silence frames during speech
        self._speech_frames = 0          # Active speech frames in current utterance
        self._speech_start_time = 0.0
        self._current_utterance_chunks: list[bytes] = []

        # Required consecutive active frames to confirm speech start (e.g. ~120ms)
        self._min_start_frames = max(2, int(120.0 / self.chunk_duration_ms))

    @property
    def noise_floor(self) -> float:
        return self._noise_floor

    @property
    def is_speaking(self) -> bool:
        return self._is_active

    def reset(self) -> None:
        """Reset utterance state cleanly without resetting the learned noise floor."""
        self._is_active = False
        self._candidate_frames = 0
        self._silence_frames = 0
        self._speech_frames = 0
        self._speech_start_time = 0.0
        self._current_utterance_chunks.clear()
        self._pre_roll.clear()

    def process(self, indata: np.ndarray | bytes) -> VADResult:
        """
        Process a single PCM block (16kHz 16-bit mono).
        Returns a VADResult indicating event, active audio chunk, and full utterance on completion.
        """
        if isinstance(indata, bytes):
            samples = np.frombuffer(indata, dtype=np.int16)
            raw_bytes = indata
        else:
            samples = np.asarray(indata, dtype=np.int16).reshape(-1)
            raw_bytes = samples.tobytes()

        if samples.size == 0:
            return VADResult(VADEvent.SILENCE, None, level=0.0)

        # 1. Compute RMS energy
        float_samples = samples.astype(np.float32)
        rms = float(np.sqrt(np.mean(float_samples ** 2)))

        # Normalized loudness level (0.0 to 1.0)
        norm_level = max(0.0, min(1.0, (rms - self._noise_floor) / 2400.0))

        # Dynamic thresholds based on noise floor
        # Triggers speech when energy exceeds ambient noise by a comfortable margin
        start_threshold = max(220.0, self._noise_floor * 2.2 + 80.0)
        # Hysteresis: keep speech active slightly lower than start
        end_threshold = max(140.0, self._noise_floor * 1.5 + 40.0)

        is_voice_chunk = rms >= end_threshold
        is_trigger_chunk = rms >= start_threshold

        now = time.monotonic()

        # Update ambient noise floor during steady non-speech periods
        if not self._is_active and not is_trigger_chunk:
            # Slow EMA update towards current ambient sound
            self._noise_floor = self._noise_floor * 0.96 + rms * 0.04
            self._noise_samples_count += 1

        # ── State 1: IDLE / NOT CURRENTLY IN CONFIRMED SPEECH ──────────────────
        if not self._is_active:
            self._pre_roll.append(raw_bytes)

            if is_trigger_chunk:
                self._candidate_frames += 1
                if self._candidate_frames >= self._min_start_frames:
                    # Speech confirmed! Transition to active
                    self._is_active = True
                    self._speech_start_time = now
                    self._silence_frames = 0
                    self._candidate_frames = 0
                    self._speech_frames = self._min_start_frames

                    # Gather pre-roll chunks so no syllable is lost
                    initial_speech = b"".join(self._pre_roll)
                    self._current_utterance_chunks = [initial_speech]

                    return VADResult(
                        event=VADEvent.SPEECH_START,
                        audio_chunk=initial_speech,
                        level=norm_level,
                    )
            else:
                self._candidate_frames = max(0, self._candidate_frames - 1)

            return VADResult(VADEvent.SILENCE, None, level=norm_level)

        # ── State 2: CURRENTLY IN SPEECH ───────────────────────────────────────
        self._current_utterance_chunks.append(raw_bytes)
        speech_elapsed_s = now - self._speech_start_time

        # Safety max utterance timeout (e.g. 18 seconds)
        if speech_elapsed_s >= self.max_speech_s:
            full_audio = b"".join(self._current_utterance_chunks)
            total_duration = self._speech_frames * self.chunk_duration_ms
            self.reset()
            return VADResult(
                event=VADEvent.SPEECH_END,
                audio_chunk=raw_bytes,
                utterance_pcm=full_audio,
                speech_duration_ms=total_duration,
                level=norm_level,
            )

        if is_voice_chunk:
            self._silence_frames = 0
            self._speech_frames += 1
            return VADResult(
                event=VADEvent.SPEECH_CHUNK,
                audio_chunk=raw_bytes,
                level=norm_level,
            )
        else:
            self._silence_frames += 1
            silence_elapsed_ms = self._silence_frames * self.chunk_duration_ms

            if silence_elapsed_ms >= self.silence_timeout_ms:
                # End of user speech detected!
                total_duration = self._speech_frames * self.chunk_duration_ms
                full_audio = b"".join(self._current_utterance_chunks)

                # Check minimum speech duration (reject short clicks, coughs)
                if total_duration < self.min_speech_ms:
                    self.reset()
                    return VADResult(
                        event=VADEvent.DISCARD,
                        audio_chunk=None,
                        speech_duration_ms=total_duration,
                        level=norm_level,
                    )

                self.reset()
                return VADResult(
                    event=VADEvent.SPEECH_END,
                    audio_chunk=None,
                    utterance_pcm=full_audio,
                    speech_duration_ms=total_duration,
                    level=norm_level,
                )

            # Silence frame while in speech window (e.g. natural brief pauses between words)
            return VADResult(
                event=VADEvent.SPEECH_CHUNK,
                audio_chunk=raw_bytes,
                level=norm_level,
            )
