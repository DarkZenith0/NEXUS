"""
core/voice_engine.py — Advanced Voice Engine for N.E.X.U.S V2.

Supports:
1. Gemini Live prebuilt voices (30 voices with personality tags).
2. Ultra-realistic Microsoft Neural Spanish voices via Edge-TTS (free, no API key).
3. ElevenLabs Text-to-Speech API with token-efficient Flash v2.5 model and custom API keys.
4. Non-blocking audio synthesis and stoppable preview.
5. Real-time viseme and level extraction for 3D avatar lip-sync.
"""

from __future__ import annotations

import asyncio
import io
import threading
import time
from typing import Callable, Optional

import numpy as np
import sounddevice as sd
import soundfile as sf

# ── Gemini Live 30 Prebuilt Voices ────────────────────────────────────────────

GEMINI_VOICES: dict[str, str] = {
    "Charon": "Informative — Calm & Deep",
    "Puck": "Upbeat — Energetic",
    "Kore": "Firm — Focused",
    "Fenrir": "Excitable — Dynamic",
    "Aoede": "Breezy — Friendly",
    "Zephyr": "Bright — Clear",
    "Leda": "Youthful — Fresh",
    "Orus": "Firm — Assertive",
    "Callirrhoe": "Easy-going — Relaxed",
    "Autonoe": "Bright — Crisp",
    "Enceladus": "Breathy — Soft",
    "Iapetus": "Clear — Direct",
    "Umbriel": "Easy-going — Gentle",
    "Algieba": "Smooth — Melodic",
    "Despina": "Smooth — Graceful",
    "Erinome": "Clear — Articulate",
    "Algenib": "Gravelly — Deep & Textured",
    "Rasalgethi": "Informative — Precise",
    "Laomedeia": "Upbeat — Lively",
    "Achernar": "Soft — Mild",
    "Alnilam": "Firm — Steady",
    "Schedar": "Even — Balanced",
    "Gacrux": "Mature — Wise",
    "Pulcherrima": "Forward — Confident",
    "Achird": "Friendly — Warm",
    "Zubenelgenubi": "Casual — Natural",
    "Vindemiatrix": "Gentle — Kind",
    "Sadachbia": "Lively — Engaging",
    "Sadaltager": "Knowledgeable — Smart",
    "Sulafat": "Warm — Inviting",
}

# ── Microsoft Neural Spanish Voices (Edge-TTS) ───────────────────────────────

SPANISH_VOICES: dict[str, str] = {
    "es-ES-AlvaroNeural": "Álvaro (España) — Profesional & Natural",
    "es-ES-ElviraNeural": "Elvira (España) — Cálida & Expresiva",
    "es-MX-JorgeNeural": "Jorge (México) — Dinámico & Fluido",
    "es-MX-DaliaNeural": "Dalia (México) — Amable & Clara",
    "es-AR-TomasNeural": "Tomás (Argentina) — Neutro & Juvenil",
    "es-CO-GonzaloNeural": "Gonzalo (Colombia) — Suave & Articulado",
    "es-US-AlonsoNeural": "Alonso (EE.UU. Latino) — Claro & Moderno",
    "es-US-PalomaNeural": "Paloma (EE.UU. Latina) — Melódica & Agradable",
}

# ── ElevenLabs Neural Models & Preset Voices ─────────────────────────────────

ELEVENLABS_MODELS: dict[str, str] = {
    "eleven_flash_v2_5": "Eleven Flash v2.5 — Ultra-rápido & 50% menos créditos",
    "eleven_multilingual_v2": "Eleven Multilingual v2 — Máxima expresividad (29 idiomas)",
}
DEFAULT_ELEVENLABS_MODEL = "eleven_flash_v2_5"

ELEVENLABS_DEFAULT_VOICES: dict[str, str] = {
    "CwhRBWXzGAHq8TQ4Fs17": "Roger — Casual & Resonante",
    "EXAVITQu4vr4xnSDxMaL": "Sarah — Madura & Confiada",
    "FGY2WhTYpPnrIDTdsKH5": "Laura — Entusiasta & Expresiva",
    "IKne3meq5aSn9XLyUdCD": "Charlie — Profundo & Enérgico",
    "JBFqnCBsd6RMkjVDRZzb": "George — Narrador Cálido",
    "N2lVS1w4EtoT3dr4eOWO": "Callum — Intenso & Directo",
    "TX3LPaxmHKxFdv7VOQHJ": "Liam — Articulado & Joven",
    "XB0fDUnXU5powFXDhCwa": "Charlotte — Suave & Aterciopelada",
    "Xb7hH8MSUJpSbSDYk0k2": "Alice — Confiada & Británica",
    "XrExE9yKIg1WjnnlVkGX": "Matilda — Cálida & Cercana",
    "bIHbv24MWmeRgasZH58o": "Will — Amable & Relajado",
    "cgSgspJ2msm6clMCkdW9": "Jessica — Alegre & Luminosa",
    "cjVigY5qzO86Huf0OWal": "Eric — Conversacional & Fluido",
    "iP95p4xoKVk53GoZ742B": "Chris — Encantador & Amistoso",
    "nPczCjzI2devNBz1zQrb": "Brian — Profundo & Imponente",
    "onwK4e9ZLuTAKqWW03F9": "Daniel — Autoritario & Presentador",
    "pFZP5JQG7iQjIQuC4Bku": "Lily — Delicada & Serena",
    "pqHfZKP75CvOlQylNhV4": "Bill — Maduro & Fiable",
}
DEFAULT_ELEVENLABS_VOICE = "CwhRBWXzGAHq8TQ4Fs17"

DEFAULT_GEMINI_VOICE = "Charon"
DEFAULT_SPANISH_VOICE = "es-ES-AlvaroNeural"


# ── Edge-TTS Audio Synthesizer ───────────────────────────────────────────────

class EdgeTTSClient:
    """Synthesize speech using Microsoft Azure Neural voices via Edge-TTS."""

    def __init__(self, voice: str = DEFAULT_SPANISH_VOICE, rate: str = "+0%", pitch: str = "+0Hz"):
        self.voice = voice if voice in SPANISH_VOICES else DEFAULT_SPANISH_VOICE
        self.rate = rate
        self.pitch = pitch
        self._stop_event = threading.Event()

    async def _synth_bytes(self, text: str, voice: str) -> bytes:
        import edge_tts
        communicate = edge_tts.Communicate(text, voice, rate=self.rate, pitch=self.pitch)
        buf = bytearray()
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                buf.extend(chunk["data"])
        return bytes(buf)

    async def synthesize_to_pcm_async(self, text: str, voice: Optional[str] = None) -> tuple[np.ndarray, int]:
        """Convert text asynchronously to 24000 Hz float32 mono PCM numpy array."""
        target_voice = voice if (voice and voice in SPANISH_VOICES) else self.voice
        if target_voice not in SPANISH_VOICES:
            target_voice = DEFAULT_SPANISH_VOICE
        try:
            audio_bytes = await self._synth_bytes(text, target_voice)
            if not audio_bytes:
                return np.zeros(0, dtype=np.float32), 24000

            data, sr = sf.read(io.BytesIO(audio_bytes), dtype="float32")
            if data.ndim > 1:
                data = np.mean(data, axis=1)

            if sr != 24000:
                import scipy.signal
                new_len = int(len(data) * 24000 / sr)
                data = scipy.signal.resample(data, new_len).astype(np.float32)
                sr = 24000

            return data.astype(np.float32), sr
        except Exception as e:
            print(f"[VoiceEngine] Edge-TTS async error for {target_voice}: {e}")
            return np.zeros(0, dtype=np.float32), 24000

    async def synthesize_raw_pcm_async(self, text: str, voice: Optional[str] = None) -> bytes:
        """Convert text asynchronously directly to 24000 Hz 16-bit mono PCM bytes."""
        samples, sr = await self.synthesize_to_pcm_async(text, voice)
        if len(samples) == 0:
            return b""
        pcm16 = (np.clip(samples, -1.0, 1.0) * 32767).astype(np.int16)
        return pcm16.tobytes()

    def synthesize_to_pcm(self, text: str, voice: Optional[str] = None) -> tuple[np.ndarray, int]:
        """Convert text to 24000 Hz float32 mono PCM numpy array."""
        target_voice = voice or self.voice
        try:
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None

            if loop and loop.is_running():
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    return pool.submit(lambda: asyncio.run(self.synthesize_to_pcm_async(text, target_voice))).result()
            else:
                return asyncio.run(self.synthesize_to_pcm_async(text, target_voice))
        except Exception as e:
            print(f"[VoiceEngine] Edge-TTS error for {target_voice}: {e}")
            return np.zeros(0, dtype=np.float32), 24000

    def synthesize_raw_pcm(self, text: str, voice: Optional[str] = None) -> bytes:
        """Convert text directly to 24000 Hz 16-bit mono PCM bytes."""
        samples, sr = self.synthesize_to_pcm(text, voice)
        if len(samples) == 0:
            return b""
        pcm16 = (np.clip(samples, -1.0, 1.0) * 32767).astype(np.int16)
        return pcm16.tobytes()

    def speak(
        self,
        text: str,
        voice: Optional[str] = None,
        device_name: Optional[str] = None,
        on_started: Optional[Callable[[], None]] = None,
        on_finished: Optional[Callable[[], None]] = None,
    ):
        self._stop_event.clear()

        def _run():
            try:
                target_voice = voice or self.voice
                samples, sr = self.synthesize_to_pcm(text, target_voice)
                if len(samples) == 0 or self._stop_event.is_set():
                    if on_finished:
                        on_finished()
                    return

                if on_started:
                    on_started()

                from core import audio_devices
                dev_idx = audio_devices.resolve(device_name, "output") if device_name else None

                sd.play(samples, samplerate=sr, device=dev_idx)
                dur = len(samples) / float(sr)
                t0 = time.monotonic()
                while (time.monotonic() - t0) < dur:
                    if self._stop_event.is_set():
                        sd.stop()
                        break
                    time.sleep(0.04)
            except Exception as e:
                print(f"[VoiceEngine] Play error: {e}")
            finally:
                if on_finished:
                    on_finished()

        threading.Thread(target=_run, daemon=True, name="VoiceEngine-EdgeTTS").start()

    def stop(self):
        self._stop_event.set()
        try:
            sd.stop()
        except Exception:
            pass


# ── ElevenLabs Client ─────────────────────────────────────────────────────────

_VOICES_CACHE: dict[str, dict[str, str]] = {}


class ElevenLabsClient:
    """Synthesize speech using ElevenLabs API with token-efficient PCM 24000."""

    def __init__(self, api_key: str = "", model_id: str = DEFAULT_ELEVENLABS_MODEL):
        self.api_key = api_key.strip()
        self.model_id = model_id or DEFAULT_ELEVENLABS_MODEL
        self._stop_event = threading.Event()

    def _headers(self, key: Optional[str] = None) -> dict:
        k = (key or self.api_key).strip()
        return {"xi-api-key": k, "Content-Type": "application/json"}

    def get_subscription_info(self, api_key: Optional[str] = None) -> dict:
        """Fetch character limit and usage from ElevenLabs user subscription."""
        try:
            import requests
            k = (api_key or self.api_key).strip()
            if not k:
                return {"ok": False, "error": "No API key configured"}
            r = requests.get(
                "https://api.elevenlabs.io/v1/user/subscription",
                headers=self._headers(k),
                timeout=6,
            )
            if r.status_code == 200:
                data = r.json()
                return {
                    "ok": True,
                    "character_count": data.get("character_count", 0),
                    "character_limit": data.get("character_limit", 10000),
                    "tier": data.get("tier", "free"),
                }
            return {"ok": False, "error": f"HTTP {r.status_code}"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def fetch_voices(self, api_key: Optional[str] = None) -> dict[str, str]:
        """Fetch custom & preset voices from account or fall back to defaults."""
        global _VOICES_CACHE
        k = (api_key or self.api_key).strip()
        if not k:
            return ELEVENLABS_DEFAULT_VOICES
        if k in _VOICES_CACHE:
            return dict(_VOICES_CACHE[k])
        try:
            import requests
            r = requests.get(
                "https://api.elevenlabs.io/v1/voices",
                headers=self._headers(k),
                timeout=6,
            )
            if r.status_code == 200:
                vlist = r.json().get("voices", [])
                out = {}
                for v in vlist:
                    vid = v.get("voice_id")
                    vname = v.get("name")
                    labels = v.get("labels") or {}
                    desc = ", ".join(f"{k}: {val}" for k, val in labels.items() if val)
                    out[vid] = f"{vname} — {desc}" if desc else vname
                if out:
                    _VOICES_CACHE[k] = out
                    return dict(out)
        except Exception as e:
            print(f"[ElevenLabs] fetch_voices exception: {e}")
        return ELEVENLABS_DEFAULT_VOICES

    def synthesize_raw_pcm(
        self,
        text: str,
        voice_id: str = DEFAULT_ELEVENLABS_VOICE,
        model_id: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> bytes:
        """Convert text directly to 24000 Hz 16-bit mono raw PCM bytes."""
        k = (api_key or self.api_key).strip()
        if not k:
            print("[ElevenLabs] No API key provided.")
            return b""

        m = model_id or self.model_id or DEFAULT_ELEVENLABS_MODEL
        vid = voice_id or DEFAULT_ELEVENLABS_VOICE
        url = f"https://api.elevenlabs.io/v1/text-to-speech/{vid}?output_format=pcm_24000"
        payload = {
            "text": text,
            "model_id": m,
            "voice_settings": {
                "stability": 0.5,
                "similarity_boost": 0.75,
            },
        }

        try:
            import requests
            r = requests.post(url, headers=self._headers(k), json=payload, timeout=12)
            if r.status_code == 200:
                return r.content
            else:
                print(f"[ElevenLabs] Synthesis error {r.status_code}: {r.text[:140]}")
                return b""
        except Exception as e:
            print(f"[ElevenLabs] Synthesis exception: {e}")
            return b""

    def synthesize_to_pcm(
        self,
        text: str,
        voice_id: str = DEFAULT_ELEVENLABS_VOICE,
        model_id: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> tuple[np.ndarray, int]:
        """Convert text to 24000 Hz float32 mono PCM numpy array."""
        raw_pcm = self.synthesize_raw_pcm(text, voice_id, model_id, api_key)
        if not raw_pcm:
            return np.zeros(0, dtype=np.float32), 24000
        samples = np.frombuffer(raw_pcm, dtype=np.int16).astype(np.float32) / 32768.0
        return samples, 24000

    def speak(
        self,
        text: str,
        voice_id: str = DEFAULT_ELEVENLABS_VOICE,
        model_id: Optional[str] = None,
        api_key: Optional[str] = None,
        device_name: Optional[str] = None,
        on_started: Optional[Callable[[], None]] = None,
        on_finished: Optional[Callable[[], None]] = None,
    ):
        self._stop_event.clear()

        def _run():
            try:
                samples, sr = self.synthesize_to_pcm(text, voice_id, model_id, api_key)
                if len(samples) == 0 or self._stop_event.is_set():
                    if on_finished:
                        on_finished()
                    return

                if on_started:
                    on_started()

                from core import audio_devices
                dev_idx = audio_devices.resolve(device_name, "output") if device_name else None

                sd.play(samples, samplerate=sr, device=dev_idx)
                dur = len(samples) / float(sr)
                t0 = time.monotonic()
                while (time.monotonic() - t0) < dur:
                    if self._stop_event.is_set():
                        sd.stop()
                        break
                    time.sleep(0.04)
            except Exception as e:
                print(f"[ElevenLabs] Play error: {e}")
            finally:
                if on_finished:
                    on_finished()

        threading.Thread(target=_run, daemon=True, name="VoiceEngine-ElevenLabs").start()

    def stop(self):
        self._stop_event.set()
        try:
            sd.stop()
        except Exception:
            pass


# ── Gemini Live Preview Synthesizer ──────────────────────────────────────────

class GeminiLivePreview:
    """Preview Gemini prebuilt voices in authentic tone via Gemini Live."""

    def __init__(self, api_key: str = ""):
        self.api_key = api_key
        self._stop_event = threading.Event()

    def synthesize_to_pcm(self, voice_name: str, text: str = "Hola, soy NEXUS.") -> tuple[np.ndarray, int]:
        from google import genai
        from google.genai import types
        from memory.config_manager import load_api_keys

        k = (self.api_key or load_api_keys().get("gemini_api_key", "")).strip()
        if not k:
            return np.zeros(0, dtype=np.float32), 24000

        target_voice = voice_name if voice_name in GEMINI_VOICES else DEFAULT_GEMINI_VOICE
        client = genai.Client(api_key=k, http_options={"api_version": "v1alpha"})
        config = types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=target_voice)
                )
            ),
            system_instruction=f"Di única y exclusivamente la frase en español: {text}"
        )

        async def _fetch():
            async with client.aio.live.connect(model="models/gemini-3.1-flash-live-preview", config=config) as session:
                await session.send_client_content(
                    turns={"role": "user", "parts": [{"text": "Hola"}]},
                    turn_complete=True
                )
                audio_bytes = bytearray()
                async for resp in session.receive():
                    if resp.data:
                        audio_bytes.extend(resp.data)
                    if resp.server_content and resp.server_content.turn_complete:
                        break
                return bytes(audio_bytes)

        try:
            loop = asyncio.new_event_loop()
            try:
                raw_bytes = loop.run_until_complete(asyncio.wait_for(_fetch(), timeout=8))
            finally:
                loop.close()

            if not raw_bytes:
                return np.zeros(0, dtype=np.float32), 24000

            samples = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0
            return samples, 24000
        except Exception as e:
            print(f"[GeminiPreview] Error: {e}")
            return np.zeros(0, dtype=np.float32), 24000

    def speak(
        self,
        text: str = "Hola, soy NEXUS.",
        voice_name: str = DEFAULT_GEMINI_VOICE,
        device_name: Optional[str] = None,
        on_started: Optional[Callable[[], None]] = None,
        on_finished: Optional[Callable[[], None]] = None,
    ):
        self._stop_event.clear()

        def _run():
            try:
                samples, sr = self.synthesize_to_pcm(voice_name, text)
                if len(samples) == 0 or self._stop_event.is_set():
                    if on_finished:
                        on_finished()
                    return

                if on_started:
                    on_started()

                from core import audio_devices
                dev_idx = audio_devices.resolve(device_name, "output") if device_name else None

                sd.play(samples, samplerate=sr, device=dev_idx)
                dur = len(samples) / float(sr)
                t0 = time.monotonic()
                while (time.monotonic() - t0) < dur:
                    if self._stop_event.is_set():
                        sd.stop()
                        break
                    time.sleep(0.04)
            except Exception as e:
                print(f"[GeminiPreview] Play error: {e}")
            finally:
                if on_finished:
                    on_finished()

        threading.Thread(target=_run, daemon=True, name="VoiceEngine-GeminiPreview").start()

    def stop(self):
        self._stop_event.set()
        try:
            sd.stop()
        except Exception:
            pass


# ── Universal Voice Preview & Control Singleton ──────────────────────────────

_preview_lock = threading.Lock()
_active_preview_client = None
_is_previewing = False


def is_preview_active() -> bool:
    """Return whether a voice preview is currently playing."""
    return _is_previewing


def stop_preview():
    """Immediately stop any active voice preview playback."""
    global _active_preview_client, _is_previewing
    with _preview_lock:
        _is_previewing = False
        if _active_preview_client:
            try:
                _active_preview_client.stop()
            except Exception:
                pass
            _active_preview_client = None
        try:
            sd.stop()
        except Exception:
            pass


def preview_voice(
    voice_name: str,
    text: Optional[str] = None,
    engine: str = "auto",
    model_id: Optional[str] = None,
    api_key: Optional[str] = None,
    on_finish: Optional[Callable[[], None]] = None,
    device_name: Optional[str] = None,
):
    """
    Play a quick, natural voice preview using the selected engine.
    Short phrase: 'Hola, soy NEXUS.'
    Can be stopped at any moment by calling stop_preview().
    """
    global _active_preview_client, _is_previewing

    stop_preview()

    with _preview_lock:
        _is_previewing = True

        sample_phrase = (text or "Hola, soy NEXUS.").strip()

        # Engine determination
        eng = (engine or "auto").lower().strip()
        if eng == "auto":
            if voice_name in GEMINI_VOICES:
                eng = "gemini"
            elif voice_name in SPANISH_VOICES or voice_name.startswith("es-"):
                eng = "edge-tts"
            else:
                eng = "elevenlabs"

        def _wrap_finished():
            global _is_previewing, _active_preview_client
            with _preview_lock:
                _is_previewing = False
                _active_preview_client = None
            if on_finish:
                try:
                    on_finish()
                except Exception:
                    pass

        if eng == "elevenlabs":
            from memory.config_manager import get_elevenlabs_key, get_elevenlabs_model
            k = (api_key or get_elevenlabs_key()).strip()
            m = model_id or get_elevenlabs_model()
            v = voice_name or DEFAULT_ELEVENLABS_VOICE
            client = ElevenLabsClient(api_key=k, model_id=m)
            _active_preview_client = client
            client.speak(
                text=sample_phrase,
                voice_id=v,
                model_id=m,
                api_key=k,
                device_name=device_name,
                on_finished=_wrap_finished,
            )

        elif eng == "edge-tts":
            target_v = voice_name if voice_name in SPANISH_VOICES else DEFAULT_SPANISH_VOICE
            client = EdgeTTSClient(voice=target_v)
            _active_preview_client = client
            client.speak(
                text=sample_phrase,
                voice=target_v,
                device_name=device_name,
                on_finished=_wrap_finished,
            )

        else:
            # Gemini Live prebuilt voice preview
            target_v = voice_name if voice_name in GEMINI_VOICES else DEFAULT_GEMINI_VOICE
            client = GeminiLivePreview()
            _active_preview_client = client
            client.speak(
                text=sample_phrase,
                voice_name=target_v,
                device_name=device_name,
                on_finished=_wrap_finished,
            )
