"""
core/nexus_paths.py — Rutas canónicas y gestión de almacenamiento dedicado de N.E.X.U.S.

Estructura central:
- BASE_DIR: Carpeta raíz del proyecto (donde reside main.py).
- NEXUS_UPLOADS: Carpeta raíz dentro de BASE_DIR para todo el material de NEXUS.
  - NEXUS_DOCUMENTS: Informes, investigaciones, deep research, resúmenes extensos y código generado.
  - NEXUS_FILES: Archivos subidos remotamente desde el móvil vía dashboard web (icono de clip).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Dict, List, Any

def _get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent

BASE_DIR = _get_base_dir()
NEXUS_UPLOADS = BASE_DIR / "NEXUS UPLOADS"
NEXUS_DOCUMENTS = NEXUS_UPLOADS / "NEXUS DOCUMENTS"
NEXUS_FILES = NEXUS_UPLOADS / "NEXUS FILES"

def ensure_nexus_dirs() -> dict[str, Path]:
    """Crea y garantiza la existencia de las carpetas centrales de NEXUS."""
    NEXUS_UPLOADS.mkdir(parents=True, exist_ok=True)
    NEXUS_DOCUMENTS.mkdir(parents=True, exist_ok=True)
    NEXUS_FILES.mkdir(parents=True, exist_ok=True)
    return {
        "uploads": NEXUS_UPLOADS,
        "documents": NEXUS_DOCUMENTS,
        "files": NEXUS_FILES,
    }

def get_storage_summary() -> dict[str, Any]:
    """Retorna un resumen estructurado del almacenamiento de NEXUS para el prompt y la UI."""
    ensure_nexus_dirs()

    def _scan(folder: Path, limit: int = 15) -> list[dict[str, Any]]:
        items = []
        if not folder.exists():
            return items
        for p in sorted(folder.glob("*"), key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True):
            if p.is_file():
                sz = p.stat().st_size
                sz_str = f"{sz/1024:.1f} KB" if sz < 1024*1024 else f"{sz/(1024*1024):.1f} MB"
                items.append({
                    "name": p.name,
                    "path": str(p),
                    "size": sz_str,
                    "mtime": p.stat().st_mtime,
                    "ext": p.suffix.lower()
                })
                if len(items) >= limit:
                    break
        return items

    doc_files = _scan(NEXUS_DOCUMENTS)
    uploaded_files = _scan(NEXUS_FILES)

    return {
        "base_dir": str(BASE_DIR),
        "nexus_uploads": str(NEXUS_UPLOADS),
        "nexus_documents": str(NEXUS_DOCUMENTS),
        "nexus_files": str(NEXUS_FILES),
        "documents_count": len(list(NEXUS_DOCUMENTS.glob("*"))) if NEXUS_DOCUMENTS.exists() else 0,
        "files_count": len(list(NEXUS_FILES.glob("*"))) if NEXUS_FILES.exists() else 0,
        "recent_documents": doc_files,
        "recent_files": uploaded_files,
    }
