@echo off
setlocal enabledelayedexpansion

:: Asegurar que el directorio de trabajo es la carpeta donde está este script
cd /d "%~dp0"

title Instalador de N.E.X.U.S

echo ===============================================================================
echo                      INSTALADOR AUTOMATICO DE N.E.X.U.S
echo ===============================================================================
echo.

:: 1. Comprobar si se ha descomprimido el ZIP
if not exist "requirements.txt" (
    echo [ERROR CRITICO]
    echo No se encuentra el archivo 'requirements.txt'.
    echo.
    echo Parece que has abierto este archivo directamente DENTRO del archivo .ZIP
    echo sin descomprimirlo primero.
    echo.
    echo SOLUCION:
    echo  1. Cierra esta ventana.
    echo  2. Haz clic derecho sobre el archivo 'N.E.X.U.S_V4_Pack.zip'.
    echo  3. Selecciona 'Extraer todo...' y pulsa 'Extraer'.
    echo  4. Entra a la carpeta descomprimida y vuelve a ejecutar 'instalar_nexus.bat'.
    echo.
    pause
    exit /b 1
)

:: 2. Detectar comando de Python disponible (python o py)
set "PY_CMD="

:: Probar con 'py -3' (Python Launcher de Windows)
py -3 --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PY_CMD=py -3"
    goto :python_found
)

:: Probar con 'python'
python --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PY_CMD=python"
    goto :python_found
)

:: Probar con 'python3'
python3 --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PY_CMD=python3"
    goto :python_found
)

:: Si no se encuentra Python:
echo [!] ERROR: Python no esta instalado o no se encuentra en el PATH del sistema.
echo.
echo Para poder usar N.E.X.U.S necesitas tener instalado Python:
echo.
echo  PASO 1: Descarga Python desde este enlace:
echo          https://www.python.org/downloads/
echo.
echo  PASO 2: Al abrir el instalador de Python, activa OBLIGATORIAMENTE la casilla:
echo          [X] "Add python.exe to PATH"  (abajo del todo)
echo.
echo  PASO 3: Haz clic en "Install Now".
echo.
echo  PASO 4: Cuando termine, vuelve a hacer doble clic en 'instalar_nexus.bat'.
echo.
pause
exit /b 1

:python_found
echo [OK] Python detectado correctamente:
%PY_CMD% --version
echo.

:: 3. Instalar librerias necesarias
echo [1/3] Instalando dependencias necesarias (esto puede tardar 1 o 2 minutos)...
%PY_CMD% -m pip install --upgrade pip
%PY_CMD% -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo.
    echo [!] Aviso: Algunos paquetes opcionales no pudieron compilarse.
    echo [!] Instalando el nucleo esencial de N.E.X.U.S...
    %PY_CMD% -m pip install PyQt6 sounddevice soundfile edge-tts numpy "google-genai>=2.8.0,<3" requests pyautogui pyperclip pygetwindow pillow psutil fastapi "uvicorn[standard]" cryptography httpx
)
echo [OK] Dependencias instaladas correctamente.
echo.

:: 4. Instalar navegador para automatizacion
echo [2/3] Instalando soporte de navegador web (Playwright Chromium)...
%PY_CMD% -m playwright install chromium
echo.

:: 5. Crear acceso directo en el escritorio
echo [3/3] Creando acceso directo en tu Escritorio...
%PY_CMD% -c "from ui import JarvisUI; JarvisUI('face.png')._create_desktop_shortcut()" 2>nul
echo [OK] Acceso directo 'N.E.X.U.S' creado en el Escritorio.
echo.

echo ===============================================================================
echo                     INSTALACION FINALIZADA CON EXITO
echo ===============================================================================
echo.
echo Al iniciar N.E.X.U.S por primera vez, aparecera una pantalla pidiendote
echo tu clave de API de Google AI Studio (es gratuita).
echo.
echo Puedes obtenerla aqui: https://aistudio.google.com/app/apikey
echo.
set /p arrancar="Deseas iniciar N.E.X.U.S ahora mismo? (S/N): "
if /i "%arrancar%"=="S" (
    if exist "%USERPROFILE%\Desktop\N.E.X.U.S.lnk" (
        start "" "%USERPROFILE%\Desktop\N.E.X.U.S.lnk"
    ) else (
        start "" %PY_CMD% main.py
    )
)

echo.
echo Presiona cualquier tecla para cerrar el instalador...
pause >nul
exit /b 0
