"""
macro_runner.py — Macro execution and action chaining for N.E.X.U.S.

Executes predefined workflows (e.g. Modo Trabajo, Modo Estudio, Modo Ocio),
chains multiple actions with visual/timing verification, and allows saving
custom user macros persistently in config/macros.json.
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


_BASE = _base_dir()
_MACROS_FILE = _BASE / "config" / "macros.json"


def _load_macros() -> dict:
    if not _MACROS_FILE.exists():
        return {}
    try:
        return json.loads(_MACROS_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[MacroRunner] ⚠️ Error loading macros.json: {e}")
        return {}


def _save_macros(macros: dict) -> bool:
    try:
        _MACROS_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = _MACROS_FILE.with_suffix(f".tmp.{os.getpid()}.{time.time_ns()}")
        try:
            tmp_path.write_text(json.dumps(macros, indent=2, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp_path, _MACROS_FILE)
            return True
        except Exception:
            if tmp_path.exists():
                try:
                    tmp_path.unlink()
                except Exception:
                    pass
            raise
    except Exception as e:
        print(f"[MacroRunner] ❌ Error saving macros.json: {e}")
        return False


def _normalize_name(name: str) -> str:
    cleaned = name.lower().strip()
    cleaned = re.sub(r"^(modo|el\s+modo|la\s+macro|macro)\s+", "modo_", cleaned)
    cleaned = re.sub(r"[^\w\s_]", "", cleaned)
    cleaned = re.sub(r"[\s\-]+", "_", cleaned)
    if not cleaned.startswith("modo_") and "modo" in cleaned:
        cleaned = "modo_" + cleaned.replace("modo", "").strip("_")
    return cleaned


_ACTION_REGISTRY_CACHE = None

def _get_action_registry():
    global _ACTION_REGISTRY_CACHE
    if _ACTION_REGISTRY_CACHE is None:
        from core.action_loader import discover_actions
        _ACTION_REGISTRY_CACHE = discover_actions(_BASE / "actions")
    return _ACTION_REGISTRY_CACHE


def _execute_step(step: dict, player=None) -> str:
    """Executes an individual action step inside a macro."""
    tool = step.get("tool", "")

    # Auto-deduce tool if missing
    if not tool:
        if "app" in step or "app_name" in step:
            tool = "open_app"
        else:
            tool = "computer_control"

    params = dict(step)
    params.pop("tool", None)

    try:
        if tool == "open_app":
            from actions.open_app import open_app
            app_target = params.get("app") or params.get("app_name") or ""
            res = open_app({"app": app_target}, player=player)
            return f"open_app({app_target}) → {res}"

        elif tool == "computer_control":
            from actions.computer_control import computer_control
            res = computer_control(params, player=player)
            action_name = params.get("action", "")
            return f"computer_control({action_name}) → {res}"

        elif tool in ("wait", "wait_for_condition", "wait_condition"):
            cond = params.get("condition") or params.get("until") or ""
            max_secs = float(params.get("timeout") or params.get("seconds", 1.0))
            max_secs = min(max(max_secs, 0.0), 15.0)

            if cond:
                t0 = time.monotonic()
                interval = 0.04
                c_low = cond.lower().strip()
                if c_low in ("window", "window_title", "title"):
                    target_title = str(params.get("title") or params.get("value") or "").lower()
                    import win32gui
                    while time.monotonic() - t0 < max_secs:
                        found = False
                        def _enum(hwnd, _):
                            nonlocal found
                            if win32gui.IsWindowVisible(hwnd):
                                t = win32gui.GetWindowText(hwnd).lower()
                                if target_title in t:
                                    found = True
                        try:
                            win32gui.EnumWindows(_enum, None)
                        except Exception:
                            pass
                        if found:
                            elapsed = time.monotonic() - t0
                            return f"Condition met (window '{target_title}' detected in {elapsed:.2f}s)"
                        time.sleep(interval)
                    return f"Timed out waiting for window '{target_title}' after {max_secs:.1f}s"

                elif c_low in ("process", "app", "process_name"):
                    target_proc = str(params.get("process") or params.get("app") or params.get("value") or "").lower()
                    import psutil
                    while time.monotonic() - t0 < max_secs:
                        for p in psutil.process_iter(["name"]):
                            try:
                                if target_proc in p.info["name"].lower():
                                    elapsed = time.monotonic() - t0
                                    return f"Condition met (process '{target_proc}' running in {elapsed:.2f}s)"
                            except (psutil.NoSuchProcess, psutil.AccessDenied):
                                pass
                        time.sleep(interval)
                    return f"Timed out waiting for process '{target_proc}' after {max_secs:.1f}s"

                elif c_low in ("file", "file_exists"):
                    target_file = Path(params.get("path") or params.get("value") or "")
                    while time.monotonic() - t0 < max_secs:
                        if target_file.exists():
                            elapsed = time.monotonic() - t0
                            return f"Condition met (file '{target_file.name}' exists in {elapsed:.2f}s)"
                        time.sleep(interval)
                    return f"Timed out waiting for file '{target_file}' after {max_secs:.1f}s"

            # Pure calibrated timer fallback
            if max_secs > 0:
                time.sleep(max_secs)
            return f"Waited {max_secs:.2f}s"

        else:
            reg = _get_action_registry()
            if reg.has(tool):
                res = reg.run(tool, params, {"player": player})
                return f"{tool} → {res}"
            return f"Unknown tool '{tool}'"

    except Exception as e:
        print(f"[MacroRunner] ⚠️ Step error ({tool}): {e}")
        return f"Error in {tool}: {e}"


def _run_macro(macro_name: str, player=None) -> str:
    macros = _load_macros()
    key_norm = _normalize_name(macro_name)

    target_macro = None
    target_key = None

    if key_norm in macros:
        target_macro = macros[key_norm]
        target_key = key_norm
    else:
        for k, v in macros.items():
            if k in key_norm or key_norm in k or macro_name.lower() in v.get("nombre", "").lower():
                target_macro = v
                target_key = k
                break

    if not target_macro:
        avail = ", ".join(f"'{k}'" for k in macros.keys())
        return f"No se encontró la macro '{macro_name}'. Macros disponibles: {avail}"

    name = target_macro.get("nombre", target_key)
    steps = target_macro.get("pasos", [])

    if player:
        player.write_log(f"[Macro] ⚡ Activando: {name}")
    print(f"[MacroRunner] ▶ Ejecutando macro '{name}' ({len(steps)} pasos)...")

    results = []
    for idx, step in enumerate(steps, 1):
        step_res = _execute_step(step, player=player)
        results.append(f"Paso {idx}: {step_res}")
        # Steps are already synchronous; do not add artificial latency between them.

    return f"Macro '{name}' completada con éxito. ({len(steps)} pasos ejecutados)."


def _save_new_macro(macro_name: str, steps: list, description: str = "") -> str:
    if not macro_name:
        return "Error: Debe especificar un nombre para la macro."
    if not steps or not isinstance(steps, list):
        return "Error: Debe incluir una lista de pasos válidos para la macro."

    macros = _load_macros()
    key = _normalize_name(macro_name)

    macros[key] = {
        "nombre": macro_name.strip(),
        "descripcion": description or f"Macro personalizada {macro_name}",
        "pasos": steps,
    }

    if _save_macros(macros):
        return f"Macro '{macro_name}' guardada correctamente con la clave '{key}'."
    return f"Error al guardar la macro '{macro_name}' en disco."


def _list_macros() -> str:
    macros = _load_macros()
    if not macros:
        return "No hay macros configuradas actualmente."

    lines = ["Macros disponibles en N.E.X.U.S:"]
    for k, v in macros.items():
        nombre = v.get("nombre", k)
        desc = v.get("descripcion", "Sin descripción")
        pasos = len(v.get("pasos", []))
        lines.append(f"• **{nombre}** (`{k}`): {desc} [{pasos} pasos]")

    return "\n".join(lines)


def _chain_actions(steps: list, player=None) -> str:
    if not steps or not isinstance(steps, list):
        return "Error: steps debe ser una lista de acciones."

    if player:
        player.write_log(f"[Macro] Encadenando {len(steps)} acciones")

    results = []
    for idx, step in enumerate(steps, 1):
        step_res = _execute_step(step, player=player)
        results.append(f"Paso {idx}: {step_res}")
        # Steps are already synchronous; do not add artificial latency between them.

    return f"Cadena de {len(steps)} acciones completada:\n" + "\n".join(results)


def _parse_steps(raw) -> list:
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return []
    return raw if isinstance(raw, list) else []


def _execute_sequence(steps, player=None, save_as: str = "",
                      description: str = "") -> str:
    """Run a just-in-time voice workflow and optionally persist it as a macro."""
    parsed = _parse_steps(steps)
    if not parsed:
        return "No pude construir una secuencia válida de acciones."

    saved_msg = ""
    if save_as.strip():
        saved = _save_new_macro(save_as, parsed, description)
        if saved.startswith("Error"):
            return saved
        saved_msg = f" Macro guardada como '{save_as}'."

    result = _chain_actions(parsed, player=player)
    return f"Secuencia ejecutada.{saved_msg}\n{result}"


def macro_runner(
    parameters: dict,
    player=None,
    speak=None,
    response=None,
    session_memory=None,
) -> str:
    """
    Handler for macro execution, action chaining, and macro management.
    """
    params = parameters or {}
    action = params.get("action", "run_macro").lower().strip()

    if player:
        player.write_log(f"[MacroRunner] {action}")

    if action in ("run", "run_macro", "execute"):
        macro_name = params.get("macro_name") or params.get("name") or ""
        return _run_macro(macro_name, player=player)

    elif action in ("save", "save_macro", "create"):
        macro_name = params.get("macro_name") or params.get("name") or ""
        desc = params.get("description", "")
        steps = params.get("steps") or []
        if isinstance(steps, str):
            try:
                steps = json.loads(steps)
            except Exception:
                steps = []
        return _save_new_macro(macro_name, steps, desc)

    elif action in ("list", "list_macros"):
        return _list_macros()

    elif action in ("chain", "chain_actions"):
        steps = _parse_steps(params.get("steps") or [])
        return _chain_actions(steps, player=player)

    elif action in ("execute_sequence", "run_sequence", "voice_sequence"):
        return _execute_sequence(
            params.get("steps") or [],
            player=player,
            save_as=params.get("save_as") or "",
            description=params.get("description") or "",
        )

    return f"Acción desconocida para macro_runner: '{action}'"


TOOL = {
    "name": "macro_runner",
    "description": "Convierte órdenes de voz con varias acciones en una secuencia inmediata. Debes descomponer la petición en pasos, ejecutarlos ahora y, solo si el usuario lo pide, guardarlos como macro reutilizable. También ejecuta macros existentes.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "execute_sequence (crear y ejecutar ahora) | run_macro | chain_actions | list_macros | save_macro"
            },
            "macro_name": {
                "type": "STRING",
                "description": "Nombre de la macro a ejecutar o guardar (ej: 'modo_trabajo', 'modo_estudio', 'modo_ocio', 'organizar_ventanas')"
            },
            "description": {
                "type": "STRING",
                "description": "Descripción de la secuencia o macro"
            },
            "save_as": {
                "type": "STRING",
                "description": "Nombre opcional para guardar la secuencia después de ejecutarla. Vacío = ejecutar solo una vez."
            },
            "steps": {
                "type": "ARRAY",
                "description": "Pasos construidos por NEXUS a partir de la orden del usuario. Cada paso debe incluir tool y sus parámetros.",
                "items": {
                    "type": "OBJECT"
                }
            }
        },
        "required": [
            "action"
        ]
    },
    "handler": macro_runner,
}
