#computer_control.py
import io
import json
import platform
import re
import string
import subprocess
import sys

for _stream in ("stdout", "stderr"):
    try:
        _s = getattr(sys, _stream, None)
        if _s is not None and hasattr(_s, "reconfigure"):
            _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if platform.system() == "Windows":
    _WIN_HIDE: dict = {"creationflags": subprocess.CREATE_NO_WINDOW}
else:
    _WIN_HIDE: dict = {}
import time
import random
from pathlib import Path

try:
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE    = 0.05
    _PYAUTOGUI = True
except ImportError:
    _PYAUTOGUI = False

try:
    import pyperclip
    _PYPERCLIP = True
except ImportError:
    _PYPERCLIP = False

import difflib

try:
    import cv2
    _CV2 = True
except ImportError:
    _CV2 = False

try:
    import numpy as np
    _NUMPY = True
except ImportError:
    _NUMPY = False

def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


_BASE         = _base_dir()
_CONFIG_PATH  = _BASE / "config" / "api_keys.json"
_MEMORY_PATH  = _BASE / "memory" / "long_term.json"

def _load_config() -> dict:
    try:
        return json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _platform_os() -> str:
    return {"Windows": "windows", "Darwin": "mac", "Linux": "linux"}.get(
        platform.system(), "linux"
    )

def _get_os() -> str:
    return _load_config().get("os_system", _platform_os()).lower()


def _get_api_key() -> str:
    return _load_config().get("gemini_api_key", "")

_SAFE_SCREENSHOT_ROOTS = (
    Path.home(),
)

def _safe_screenshot_path(requested: str | None) -> Path:
    fallback = Path.home() / "Desktop" / "nexus_screenshot.png"
    if not requested:
        return fallback
    try:
        p = Path(requested).expanduser().resolve()
        for root in _SAFE_SCREENSHOT_ROOTS:
            if p.is_relative_to(root.resolve()):
                p.parent.mkdir(parents=True, exist_ok=True)
                return p
    except Exception:
        pass
    return fallback

def _require_pyautogui():
    if not _PYAUTOGUI:
        raise RuntimeError("PyAutoGUI not installed. Run: pip install pyautogui")

_FIRST_NAMES = [
    "Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Drew", "Quinn",
    "Avery", "Blake", "Cameron", "Dakota", "Emerson", "Finley", "Harper",
]
_LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller",
    "Davis", "Wilson", "Moore", "Taylor", "Anderson", "Thomas", "Jackson",
]
_DOMAINS = ["gmail.com", "yahoo.com", "outlook.com", "proton.me", "mail.com"]


def _random_data(data_type: str) -> str:
    dt = data_type.lower().strip()

    if dt == "first_name":
        return random.choice(_FIRST_NAMES)

    if dt == "last_name":
        return random.choice(_LAST_NAMES)

    if dt == "name":
        return f"{random.choice(_FIRST_NAMES)} {random.choice(_LAST_NAMES)}"

    if dt == "email":
        first = random.choice(_FIRST_NAMES).lower()
        last  = random.choice(_LAST_NAMES).lower()
        num   = random.randint(10, 999)
        return f"{first}.{last}{num}@{random.choice(_DOMAINS)}"

    if dt == "username":
        return f"{random.choice(_FIRST_NAMES).lower()}{random.randint(100, 9999)}"

    if dt == "password":
        chars = string.ascii_letters + string.digits + "!@#$%"
        raw   = (
            random.choice(string.ascii_uppercase)
            + random.choice(string.digits)
            + random.choice("!@#$%")
            + "".join(random.choices(chars, k=9))
        )
        return "".join(random.sample(raw, len(raw)))

    if dt == "phone":
        return f"+1{random.randint(200,999)}{random.randint(1_000_000, 9_999_999)}"

    if dt == "birthday":
        y = random.randint(1980, 2000)
        m = random.randint(1, 12)
        d = random.randint(1, 28)
        return f"{m:02d}/{d:02d}/{y}"

    if dt == "address":
        num    = random.randint(100, 9999)
        street = random.choice(["Main St", "Oak Ave", "Park Blvd", "Elm St", "Cedar Ln"])
        return f"{num} {street}"

    if dt == "zip_code":
        return str(random.randint(10000, 99999))

    if dt == "city":
        return random.choice(["New York", "Los Angeles", "Chicago", "Houston", "Phoenix"])

    return f"random_{data_type}_{random.randint(1000, 9999)}"

def _user_profile() -> dict:
    """Read identity fields from long-term memory."""
    try:
        if _MEMORY_PATH.exists():
            data     = json.loads(_MEMORY_PATH.read_text(encoding="utf-8"))
            identity = data.get("identity", {})
            return {k: v.get("value", "") for k, v in identity.items()}
    except Exception:
        pass
    return {}

def _type(text: str, interval: float = 0.03) -> str:
    _require_pyautogui()
    time.sleep(0.3)
    pyautogui.typewrite(text, interval=interval)
    return f"Typed: {text[:60]}{'…' if len(text) > 60 else ''}"


def _smart_type(text: str, clear_first: bool = True) -> str:
    _require_pyautogui()
    if clear_first:
        _clear_field()
        time.sleep(0.1)

    if len(text) > 20 and _PYPERCLIP:
        pyperclip.copy(text)
        time.sleep(0.1)
        paste_key = "command" if _get_os() == "mac" else "ctrl"
        pyautogui.hotkey(paste_key, "v")
        return f"Smart-typed (clipboard): {text[:60]}{'…' if len(text) > 60 else ''}"

    pyautogui.typewrite(text, interval=0.04)
    return f"Smart-typed: {text[:60]}{'…' if len(text) > 60 else ''}"


def _notify_click_feedback(x, y, button: str) -> None:
    """Best-effort bridge to the optional Qt click-pulse overlay."""
    if x is None or y is None:
        return
    try:
        from ui import notify_click_feedback
        notify_click_feedback(int(x), int(y), button)
    except Exception:
        pass


def _click(x=None, y=None, button: str = "left", clicks: int = 1) -> str:
    _require_pyautogui()
    if x is not None and y is not None:
        pyautogui.click(x, y, button=button, clicks=clicks)
        _notify_click_feedback(x, y, button)
        return f"{'Double-c' if clicks == 2 else 'C'}licked ({x}, {y}) [{button}]"
    pyautogui.click(button=button, clicks=clicks)
    return f"Clicked at current position [{button}]"


def _hotkey(*keys) -> str:
    _require_pyautogui()
    pyautogui.hotkey(*keys)
    return f"Hotkey: {'+'.join(keys)}"


def _press(key: str) -> str:
    _require_pyautogui()
    pyautogui.press(key)
    return f"Pressed: {key}"


def _scroll(direction: str = "down", amount: int = 3) -> str:
    _require_pyautogui()
    vertical   = direction in ("up", "down")
    clicks     = amount if direction in ("up", "right") else -amount
    pyautogui.scroll(clicks) if vertical else pyautogui.hscroll(clicks)
    return f"Scrolled {direction} ×{amount}"


def _move(x: int, y: int, duration: float = 0.3) -> str:
    _require_pyautogui()
    pyautogui.moveTo(x, y, duration=duration)
    return f"Mouse → ({x}, {y})"


def _drag(x1: int, y1: int, x2: int, y2: int, duration: float = 0.5) -> str:
    _require_pyautogui()
    pyautogui.moveTo(x1, y1, duration=0.2)
    pyautogui.dragTo(x2, y2, duration=duration, button="left")
    return f"Dragged ({x1},{y1}) → ({x2},{y2})"


def _clipboard_get() -> str:
    if _PYPERCLIP:
        return pyperclip.paste()
    _hotkey("ctrl", "c")
    time.sleep(0.2)
    return "(copied — pyperclip unavailable for read)"


def _clipboard_paste(text: str) -> str:
    if _PYPERCLIP:
        pyperclip.copy(text)
        time.sleep(0.1)
        _require_pyautogui()
        paste_key = "command" if _get_os() == "mac" else "ctrl"
        pyautogui.hotkey(paste_key, "v")
        return f"Pasted: {text[:60]}{'…' if len(text) > 60 else ''}"
    return "pyperclip not available"


def _screenshot(save_path: str | None = None, monitor=None) -> str:
    path = _safe_screenshot_path(save_path)
    arr, mon = _capture_screen_array(preferred_monitor=monitor)
    if arr is not None:
        if _CV2:
            cv2.imwrite(str(path), arr)
        else:
            from PIL import Image
            Image.fromarray(arr).save(str(path))
        return f"Screenshot saved: {path} (captured monitor: {mon.get('width')}x{mon.get('height')} at ({mon.get('left')},{mon.get('top')}))"
    try:
        _require_pyautogui()
        img  = pyautogui.screenshot()
        img.save(str(path))
        return f"Screenshot saved: {path}"
    except Exception as e:
        try:
            from PIL import Image
            blank = Image.new("RGB", (1280, 720), (30, 30, 30))
            blank.save(str(path))
            return f"Screenshot saved (display locked placeholder): {path}"
        except Exception:
            return f"Screenshot failed (display may be locked): {e}"


def _clear_field() -> str:
    _require_pyautogui()
    select_key = "command" if _get_os() == "mac" else "ctrl"
    pyautogui.hotkey(select_key, "a")
    time.sleep(0.1)
    pyautogui.press("delete")
    return "Field cleared"


def _find_in_page(text: str, next_match: bool = False) -> str:
    """
    Find text inside the currently active window, page, or document (Ctrl+F).
    """
    _require_pyautogui()
    if not text and not next_match:
        return "Please specify text to search inside the page."

    old_fs = pyautogui.FAILSAFE
    try:
        pyautogui.FAILSAFE = False
        select_key = "command" if _get_os() == "mac" else "ctrl"
        if not next_match:
            pyautogui.hotkey(select_key, "f")
            time.sleep(0.15)
            _clear_field()
            if _PYPERCLIP:
                pyperclip.copy(text)
                time.sleep(0.05)
                pyautogui.hotkey(select_key, "v")
            else:
                pyautogui.typewrite(text, interval=0.02)
            time.sleep(0.1)
            pyautogui.press("enter")
            return f"Searching for '{text}' inside current page/document (Ctrl+F)."
        else:
            pyautogui.press("f3")
            return f"Jumped to next occurrence of '{text}'."
    finally:
        pyautogui.FAILSAFE = old_fs

def _focus_window(title: str) -> str:
    os_name = _get_os()

    if os_name == "windows":
        try:
            import win32gui
            import win32con
            found_hwnd = None
            title_low = title.lower().strip()

            def _enum_win(hwnd, _):
                nonlocal found_hwnd
                if found_hwnd:
                    return
                if win32gui.IsWindowVisible(hwnd):
                    txt = win32gui.GetWindowText(hwnd)
                    if txt and title_low in txt.lower():
                        found_hwnd = hwnd

            win32gui.EnumWindows(_enum_win, None)
            if found_hwnd:
                try:
                    win32gui.ShowWindow(found_hwnd, win32con.SW_RESTORE)
                    win32gui.SetForegroundWindow(found_hwnd)
                except Exception:
                    try:
                        import win32process
                        fore_hwnd = win32gui.GetForegroundWindow()
                        fore_tid, _ = win32process.GetWindowThreadProcessId(fore_hwnd)
                        cur_tid, _ = win32process.GetWindowThreadProcessId(found_hwnd)
                        import ctypes
                        ctypes.windll.user32.AttachThreadInput(cur_tid, fore_tid, True)
                        win32gui.SetForegroundWindow(found_hwnd)
                        ctypes.windll.user32.AttachThreadInput(cur_tid, fore_tid, False)
                    except Exception:
                        pass
                # Fast reactive polling up to 100ms
                for _ in range(20):
                    if win32gui.GetForegroundWindow() == found_hwnd:
                        break
                    time.sleep(0.005)
                return f"Focused window: {title}"
        except Exception:
            pass

        try:
            # Safely escape PowerShell special characters to prevent command injection
            safe_title = title.replace("`", "``").replace('"', '`"').replace("$", "`$")
            script = f'(New-Object -ComObject WScript.Shell).AppActivate("{safe_title}")'
            subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                capture_output=True, timeout=5, **_WIN_HIDE,
            )
            time.sleep(0.2)
            return f"Focused window: {title}"
        except Exception as e:
            return f"focus_window (Windows) failed: {e}"

    if os_name == "mac":
        script = (
            f'tell application "System Events" to '
            f'set frontmost of (first process whose name contains "{title}") to true'
        )
        try:
            subprocess.run(
                ["osascript", "-e", script],
                capture_output=True, timeout=5,
            )
            time.sleep(0.3)
            return f"Focused window: {title}"
        except Exception as e:
            return f"focus_window (macOS) failed: {e}"

    if os_name == "linux":
        try:
            result = subprocess.run(
                ["wmctrl", "-a", title],
                capture_output=True, timeout=5,
            )
            if result.returncode == 0:
                time.sleep(0.3)
                return f"Focused window: {title}"
        except FileNotFoundError:
            pass
        try:
            result = subprocess.run(
                ["xdotool", "search", "--name", title, "windowactivate"],
                capture_output=True, timeout=5,
            )
            time.sleep(0.3)
            return f"Focused window: {title}"
        except FileNotFoundError:
            return "focus_window (Linux) requires wmctrl or xdotool"
        except Exception as e:
            return f"focus_window (Linux) failed: {e}"

    return f"focus_window: unknown OS '{os_name}'"

_RAPID_OCR_ENGINE = None

def _get_ocr_engine():
    global _RAPID_OCR_ENGINE
    if _RAPID_OCR_ENGINE is None:
        try:
            from rapidocr_onnxruntime import RapidOCR
            _RAPID_OCR_ENGINE = RapidOCR()
            print("[ComputerControl] ⚡ RapidOCR engine loaded and ready.")
        except Exception as e:
            print(f"[ComputerControl] ⚠️ Failed to initialize RapidOCR: {e}")
            _RAPID_OCR_ENGINE = False
    return _RAPID_OCR_ENGINE if _RAPID_OCR_ENGINE is not False else None


def _clean_target_text(desc: str) -> str:
    """Strip natural language command prefixes and Spanish filler words."""
    t = desc.lower().strip()
    t = re.sub(r"^(haz\s+clic\s+en|haz\s+click\s+en|pulsa\s+en|presiona\s+en|selecciona|toca|click\s+on|click)\s+", "", t)
    t = re.sub(r"^(el|la|los|las|un|una)\s+", "", t)
    t = re.sub(r"^(bot[oó]n|icono|pestana|pestaña|men[uú]|enlace|link|texto)\s+(de\s+)?", "", t)
    t = re.sub(r"^(el|la|los|las)\s+", "", t)
    return t.strip()


def _get_active_monitor_bounds(preferred=None) -> dict:
    """Returns {left, top, width, height} of active monitor (foreground window -> cursor -> primary)."""
    try:
        import mss
        sct_cls = getattr(mss, "MSS", mss.mss)
        with sct_cls() as sct:
            real_mons = sct.monitors[1:]
            if not real_mons:
                return sct.monitors[0]

            pref_str = str(preferred).lower().strip() if preferred is not None else ""
            if pref_str in ("all", "todas", "ambas", "combined", "0"):
                return sct.monitors[0]
            if pref_str.isdigit():
                idx = int(pref_str)
                if 1 <= idx <= len(real_mons):
                    return real_mons[idx - 1]
            if pref_str in ("left", "izquierda"):
                return min(real_mons, key=lambda m: m["left"])
            if pref_str in ("right", "derecha"):
                return max(real_mons, key=lambda m: m["left"])
            if pref_str in ("primary", "principal"):
                for m in real_mons:
                    if m.get("is_primary"):
                        return m
                return real_mons[0]
            if pref_str in ("secondary", "secundario", "secundaria"):
                for m in real_mons:
                    if not m.get("is_primary"):
                        return m

            # 1. Try active foreground window
            try:
                import win32gui
                hwnd = win32gui.GetForegroundWindow()
                if hwnd:
                    title = win32gui.GetWindowText(hwnd).upper()
                    if not any(k in title for k in ("NEXUS", "J.A.R.V.I.S", "JARVIS")):
                        rect = win32gui.GetWindowRect(hwnd)
                        cx = (rect[0] + rect[2]) // 2
                        cy = (rect[1] + rect[3]) // 2
                        for m in real_mons:
                            if m["left"] <= cx < m["left"] + m["width"] and m["top"] <= cy < m["top"] + m["height"]:
                                return m
            except Exception:
                pass

            # 2. Try mouse cursor position
            try:
                _require_pyautogui()
                mx, my = pyautogui.position()
                for m in real_mons:
                    if m["left"] <= mx < m["left"] + m["width"] and m["top"] <= my < m["top"] + m["height"]:
                        return m
            except Exception:
                pass

            # 3. Fallback to primary monitor
            for m in real_mons:
                if m.get("is_primary"):
                    return m
            return real_mons[0]
    except Exception:
        pass
    _require_pyautogui()
    w, h = pyautogui.size()
    return {"left": 0, "top": 0, "width": w, "height": h}


def _get_nexus_window_rect() -> tuple[int, int, int, int] | None:
    """Returns (left, top, right, bottom) of NEXUS HUD window to avoid clicking on self."""
    if platform.system() != "Windows":
        return None
    try:
        import win32gui
        matches = []
        def enum_cb(hwnd, extra):
            if win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd).upper()
                if any(k in title for k in ("NEXUS", "J.A.R.V.I.S", "JARVIS")):
                    extra.append(win32gui.GetWindowRect(hwnd))
            return True
        win32gui.EnumWindows(enum_cb, matches)
        if matches:
            return matches[0]
    except Exception:
        pass
    return None


def _foreground_is_nexus() -> bool:
    """Prevent an untargeted window command from acting on NEXUS itself."""
    if platform.system() != "Windows":
        return False
    try:
        import win32gui
        title = win32gui.GetWindowText(win32gui.GetForegroundWindow()).upper()
        return any(token in title for token in ("NEXUS", "J.A.R.V.I.S", "JARVIS"))
    except Exception:
        return False


def _is_inside_nexus(x: int, y: int) -> bool:
    rect = _get_nexus_window_rect()
    if not rect:
        return False
    left, top, right, bottom = rect
    return left <= x <= right and top <= y <= bottom


def _capture_screen_array(preferred_monitor=None) -> tuple[np.ndarray | None, dict]:
    """
    Captures screen and returns (numpy_bgr_array, monitor_bounds).
    Multi-backend fallback: mss -> PIL ImageGrab -> pyautogui.
    """
    mon = _get_active_monitor_bounds(preferred=preferred_monitor)
    m_left, m_top = mon.get("left", 0), mon.get("top", 0)

    # Backend 1: mss
    try:
        import mss
        sct_cls = getattr(mss, "MSS", mss.mss)
        with sct_cls() as sct:
            shot = sct.grab(mon)
            arr = np.array(shot, dtype=np.uint8)[:, :, :3]
            return arr, mon
    except Exception:
        pass

    # Backend 2: PIL ImageGrab
    try:
        from PIL import ImageGrab
        bbox = (m_left, m_top, m_left + mon["width"], m_top + mon["height"]) if mon.get("width", 0) > 0 else None
        img = ImageGrab.grab(bbox=bbox, all_screens=True)
        if _CV2:
            arr = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        else:
            arr = np.array(img)
        return arr, mon
    except Exception:
        pass

    # Backend 3: pyautogui
    try:
        _require_pyautogui()
        img = pyautogui.screenshot()
        if _CV2:
            arr = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        else:
            arr = np.array(img)
        return arr, mon
    except Exception:
        pass

    return None, mon


def _ocr_find(description: str, arr: np.ndarray, mon: dict) -> tuple[int, int] | None:
    """
    Tier 2: RapidOCR Local (~60ms).
    Pixel-perfect screen text locator. Works on 4K, any DPI, any desktop or web app.
    """
    engine = _get_ocr_engine()
    if not engine or arr is None:
        return None

    target = _clean_target_text(description)
    if not target:
        return None

    try:
        t0 = time.time()
        # ── 1080p Downscale: reducir capturas superiores a 1080p (>1920w o >1080h)
        # Acelera RapidOCR ~75% preservando nitidez y precisión subpíxel exacta
        _scale = 1.0
        arr_ocr = arr
        if arr is not None and (arr.shape[1] > 1920 or arr.shape[0] > 1080):
            _scale = min(1920.0 / arr.shape[1], 1080.0 / arr.shape[0])
            new_w = max(1, int(round(arr.shape[1] * _scale)))
            new_h = max(1, int(round(arr.shape[0] * _scale)))
            if _CV2:
                arr_ocr = cv2.resize(arr, (new_w, new_h), interpolation=cv2.INTER_AREA)
            else:
                from PIL import Image
                pil_img = Image.fromarray(arr).resize((new_w, new_h), Image.Resampling.BILINEAR)
                arr_ocr = np.array(pil_img)

        result, elapse = engine(arr_ocr)
        t_ms = (time.time() - t0) * 1000
        if not result:
            return None

        m_left = mon.get("left", 0)
        m_top  = mon.get("top", 0)

        best_score = 0.0
        best_coords = None
        target_words = set(re.findall(r"\w+", target))

        for line in result:
            box, text, score_raw = line
            text_str = str(text).strip()
            text_lower = text_str.lower()
            try:
                base_conf = float(score_raw)
            except Exception:
                base_conf = 0.85

            # Re-escalar coordenadas del espacio downscaled al monitor real sin error de truncamiento
            cx_down = (box[0][0] + box[2][0]) / 2.0
            cy_down = (box[0][1] + box[2][1]) / 2.0
            cx = int(round(cx_down / _scale)) + m_left
            cy = int(round(cy_down / _scale)) + m_top

            # Skip coordinates inside NEXUS's own HUD if target isn't asking for nexus
            if "nexus" not in target and _is_inside_nexus(cx, cy):
                continue

            match_score = 0.0

            # 1. Exact match
            if text_lower == target:
                match_score = 100.0 * base_conf
            # 2. Target contains text or text contains target
            elif target in text_lower:
                match_score = 85.0 * base_conf * (len(target) / max(len(text_lower), 1))
            elif text_lower in target and len(text_lower) >= 3:
                match_score = 75.0 * base_conf * (len(text_lower) / max(len(target), 1))
            # 3. Word token overlap
            else:
                words = set(re.findall(r"\w+", text_lower))
                if words and target_words:
                    overlap = words.intersection(target_words)
                    if overlap:
                        ratio = len(overlap) / len(target_words)
                        match_score = 70.0 * base_conf * ratio

            # 4. Fuzzy SequenceMatcher
            if match_score < 40.0:
                sim = difflib.SequenceMatcher(None, target, text_lower).ratio()
                if sim >= 0.70:
                    match_score = 65.0 * base_conf * sim

            if match_score > best_score:
                best_score = match_score
                best_coords = (cx, cy)

        if best_coords and best_score >= 35.0:
            print(f"[ComputerControl] ⚡ RapidOCR matched '{target}' at {best_coords} in {t_ms:.1f}ms (score: {best_score:.1f})")
            return best_coords

    except Exception as e:
        print(f"[ComputerControl] ⚠️ RapidOCR error: {e}")

    return None


def _opencv_icon_find(description: str, arr: np.ndarray, mon: dict) -> tuple[int, int] | None:
    """
    Tier 3: OpenCV Icon & Window Geometry detector for non-text graphical elements:
    - Close (X), Minimize (_), Maximize (□)
    - Search (magnifying glass), Settings (gear), Play, Pause, Refresh, Add (+)
    """
    clean = description.lower().strip()
    m_left = mon.get("left", 0)
    m_top = mon.get("top", 0)

    # 1. Window controls using exact OS geometry of the active target window
    if platform.system() == "Windows":
        try:
            import win32gui
            hwnd = win32gui.GetForegroundWindow()
            if hwnd:
                rect = win32gui.GetWindowRect(hwnd) # (left, top, right, bottom)
                w_left, w_top, w_right, w_bottom = rect
                w_width = w_right - w_left
                if w_width > 200:
                    if any(k in clean for k in ("cerrar", "close", "cerrar ventana", "la x", "botón x")):
                        cx, cy = w_right - 25, w_top + 15
                        print(f"[ComputerControl] 🎯 Window geometry found Close button at ({cx}, {cy})")
                        return (cx, cy)
                    if any(k in clean for k in ("minimizar", "minimize", "minimizar ventana")):
                        cx, cy = w_right - 100, w_top + 15
                        print(f"[ComputerControl] 🎯 Window geometry found Minimize button at ({cx}, {cy})")
                        return (cx, cy)
                    if any(k in clean for k in ("maximizar", "maximize", "maximizar ventana", "pantalla completa")):
                        cx, cy = w_right - 60, w_top + 15
                        print(f"[ComputerControl] 🎯 Window geometry found Maximize button at ({cx}, {cy})")
                        return (cx, cy)
        except Exception:
            pass

    # 2. Template matching with OpenCV
    if arr is not None and _CV2:
        try:
            gray_screen = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY) if len(arr.shape) == 3 else arr
            tmpl = None
            if any(k in clean for k in ("buscar", "lupa", "search")):
                tmpl = np.zeros((32, 32), dtype=np.uint8)
                cv2.circle(tmpl, (13, 13), 9, 255, 2)
                cv2.line(tmpl, (19, 19), (28, 28), 255, 3)
            elif any(k in clean for k in ("ajustes", "configuración", "configuracion", "engranaje", "gear", "settings")):
                tmpl = np.zeros((32, 32), dtype=np.uint8)
                cv2.circle(tmpl, (16, 16), 8, 255, 3)
                for angle in range(0, 360, 45):
                    rad = np.deg2rad(angle)
                    x1 = int(16 + 8 * np.cos(rad)); y1 = int(16 + 8 * np.sin(rad))
                    x2 = int(16 + 14 * np.cos(rad)); y2 = int(16 + 14 * np.sin(rad))
                    cv2.line(tmpl, (x1, y1), (x2, y2), 255, 2)
            elif any(k in clean for k in ("reproducir", "play", "reanudar")):
                tmpl = np.zeros((32, 32), dtype=np.uint8)
                pts = np.array([[10, 8], [24, 16], [10, 24]], np.int32)
                cv2.fillPoly(tmpl, [pts], 255)
            elif any(k in clean for k in ("pausa", "pausar", "pause")):
                tmpl = np.zeros((32, 32), dtype=np.uint8)
                cv2.rectangle(tmpl, (10, 8), (14, 24), 255, -1)
                cv2.rectangle(tmpl, (18, 8), (22, 24), 255, -1)
            elif any(k in clean for k in ("agregar", "añadir", "nuevo", "+", "plus")):
                tmpl = np.zeros((32, 32), dtype=np.uint8)
                cv2.line(tmpl, (16, 8), (16, 24), 255, 3)
                cv2.line(tmpl, (8, 16), (24, 16), 255, 3)

            if tmpl is not None:
                screen_edges = cv2.Canny(gray_screen, 50, 150)
                tmpl_edges = cv2.Canny(tmpl, 50, 150)
                res = cv2.matchTemplate(screen_edges, tmpl_edges, cv2.TM_CCOEFF_NORMED)
                min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
                if max_val >= 0.35:
                    th, tw = tmpl.shape
                    cx = max_loc[0] + tw // 2 + m_left
                    cy = max_loc[1] + th // 2 + m_top
                    if not _is_inside_nexus(cx, cy):
                        print(f"[ComputerControl] 🎯 OpenCV template matched icon '{clean}' at ({cx}, {cy}) (conf: {max_val:.2f})")
                        return (cx, cy)
        except Exception as e:
            print(f"[ComputerControl] ⚠️ OpenCV icon matching error: {e}")

    return None


def _try_browser_dom_click(description: str) -> str | None:
    """
    Tier 1 Browser-DOM Click:
    If a Playwright browser session is active, delegates to browser_control's DOM click.
    """
    try:
        from actions.browser_control import _registry
        if _registry.has():
            sess = _registry.get()
            if sess:
                res = sess.run(sess.smart_click(description))
                if res and not res.startswith("Could not find"):
                    print(f"[ComputerControl] 🌐 Browser DOM clicked: {res}")
                    return res
    except Exception as e:
        pass
    return None


def _grounding_find(description: str, arr: np.ndarray | None = None, mon: dict | None = None) -> tuple[int, int] | None:
    """
    Tier 4 Multimodal Gemini UI Grounding fallback for custom or novel visual elements.
    """
    api_key = _get_api_key()
    if not api_key:
        print("[ComputerControl] ⚠️ No API key for screen grounding")
        return None

    try:
        from google.genai import types as gtypes
        from PIL import Image

        if mon is None:
            mon = _get_active_monitor_bounds()
        m_left, m_top, m_w, m_h = mon["left"], mon["top"], mon["width"], mon["height"]

        if arr is not None and _CV2:
            rgb = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(rgb)
        else:
            arr_new, mon = _capture_screen_array()
            if arr_new is not None and _CV2:
                rgb = cv2.cvtColor(arr_new, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(rgb)
            else:
                img = pyautogui.screenshot()

        orig_w, orig_h = img.size
        # ── 1080p Downscale: redimensionar si supera 1080p manteniendo aspect ratio
        if orig_w > 1920 or orig_h > 1080:
            scale = min(1920.0 / orig_w, 1080.0 / orig_h)
            new_size = (max(1, int(round(orig_w * scale))), max(1, int(round(orig_h * scale))))
            img_to_send = img.resize(new_size, Image.Resampling.BILINEAR)
        else:
            img_to_send = img

        buf = io.BytesIO()
        img_to_send.save(buf, format="JPEG", quality=75)
        image_bytes = buf.getvalue()

        prompt = (
            f"You are a computer UI grounding model. Locate the element described as: '{description}'.\n"
            f"Reply ONLY with the normalized bounding box in range 0 to 1000 as JSON: [ymin, xmin, ymax, xmax].\n"
            f"If the element is not found on screen, reply: NOT_FOUND"
        )

        from core import gemini
        response = gemini.call(
            [gtypes.Part.from_bytes(data=image_bytes, mime_type="image/jpeg"), prompt],
            tier=gemini.SMART, timeout_ms=25_000,
        )
        if response is None:
            return None

        text = (response.text or "").strip()
        if "NOT_FOUND" in text.upper():
            print(f"[ComputerControl] ⚠️ Grounding: '{description}' not found.")
            return None

        box_match = re.search(r"\[\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\]", text)
        if box_match:
            ymin, xmin, ymax, xmax = map(int, box_match.groups())
            center_x_norm = (xmin + xmax) / 2000.0
            center_y_norm = (ymin + ymax) / 2000.0
            screen_x = int(round(m_left + center_x_norm * m_w))
            screen_y = int(round(m_top + center_y_norm * m_h))
            print(f"[ComputerControl] 🎯 Grounding box [{ymin},{xmin},{ymax},{xmax}] → Screen ({screen_x}, {screen_y})")
            return (screen_x, screen_y)

    except Exception as e:
        print(f"[ComputerControl] ⚠️ Grounding failed: {e}")

    return None


def _smart_find(description: str, preferred_monitor=None) -> tuple[int, int] | None:
    """
    Unified 4-Tier Smart Element Finder:
    1. Tier 1: Browser DOM (Playwright) - if browser automation active
    2. Tier 2: RapidOCR Local (~60ms) - for 95% of desktop buttons, links, menus, and text
    3. Tier 3: OpenCV Icon & Window Geometry (~15ms) - for non-text icons (✕, 🔍, ⚙, ▶, ⏸, +)
    4. Tier 4: Gemini Multimodal Grounding (0-1000 normalized boxes) - fallback for custom graphics
    """
    if not description:
        return None

    print(f"[ComputerControl] 🔍 Smart-finding: '{description}' (monitor: {preferred_monitor or 'auto'})...")

    arr, mon = _capture_screen_array(preferred_monitor=preferred_monitor)

    # Icon priority routing: si la descripción coincide con iconos conocidos,
    # ejecutar OpenCV (~15ms) primero antes que OCR (~800ms en 4K)
    _ICON_KEYWORDS = {
        "cerrar", "close", "minimizar", "minimize", "maximizar", "maximize",
        "buscar", "lupa", "search", "ajustes", "configuración", "configuracion",
        "engranaje", "gear", "settings", "reproducir", "play", "pausa",
        "pausar", "pause", "agregar", "añadir", "nuevo"
    }
    desc_lower = description.lower().strip()
    _is_icon_query = any(k in desc_lower for k in _ICON_KEYWORDS)

    if _is_icon_query:
        # Tier 3 first: OpenCV geometry (~15ms)
        coords = _opencv_icon_find(description, arr, mon)
        if coords:
            return coords
        # Then Tier 2: OCR
        if arr is not None:
            coords = _ocr_find(description, arr, mon)
            if coords:
                return coords
    else:
        # Tier 2 first: RapidOCR (main text/button finder)
        if arr is not None:
            coords = _ocr_find(description, arr, mon)
            if coords:
                return coords
        # Tier 3: OpenCV fallback
        coords = _opencv_icon_find(description, arr, mon)
        if coords:
            return coords

    # Tier 4: Gemini Multimodal Grounding Fallback
    coords = _grounding_find(description, arr, mon)
    if coords:
        return coords

    return None


def _smooth_click(x: int, y: int, button: str = "left", clicks: int = 1) -> str:
    """Smooth mouse move and click with visual feedback."""
    _require_pyautogui()
    pyautogui.moveTo(x, y, duration=0.15)
    time.sleep(0.03)
    pyautogui.click(x, y, button=button, clicks=clicks)
    _notify_click_feedback(x, y, button)
    btn_label = "Double-click" if clicks == 2 else f"{button.capitalize()}-click"
    return f"{btn_label} executed at ({x}, {y})"


def _snap_window(position: str = "left", title: str | None = None) -> str:
    """
    Snap, tile, or resize windows.
    position: 'left' | 'right' | 'top' | 'maximize' | 'minimize' | 'restore' | 'center'
    """
    _require_pyautogui()
    pos = position.lower().strip()

    title_upper = (title or "").upper()
    if any(token in title_upper for token in ("NEXUS", "J.A.R.V.I.S", "JARVIS")):
        return "No voy a modificar la ventana de NEXUS. Indica otra aplicación."
    if not title and _foreground_is_nexus():
        return ("La ventana activa es NEXUS. Indica el título o la aplicación "
                "que quieres modificar para evitar actuar sobre mí mismo.")

    if title:
        _focus_window(title)
        time.sleep(0.4)

    if platform.system() == "Windows":
        old_failsafe = pyautogui.FAILSAFE
        try:
            pyautogui.FAILSAFE = False
            if pos in ("maximize", "max", "full", "top"):
                pyautogui.hotkey("win", "up")
                return f"Window maximized ({title or 'active'})"
            elif pos in ("minimize", "min"):
                pyautogui.hotkey("win", "down")
                time.sleep(0.1)
                pyautogui.hotkey("win", "down")
                return f"Window minimized ({title or 'active'})"
            elif pos in ("restore", "normal"):
                pyautogui.hotkey("win", "down")
                return f"Window restored ({title or 'active'})"
            elif pos in ("left", "izquierda"):
                pyautogui.hotkey("win", "left")
                return f"Window snapped LEFT ({title or 'active'})"
            elif pos in ("right", "derecha"):
                pyautogui.hotkey("win", "right")
                return f"Window snapped RIGHT ({title or 'active'})"
            elif pos == "center":
                import win32gui
                import win32con
                hwnd = win32gui.GetForegroundWindow()
                if hwnd:
                    mon = _get_active_monitor_bounds()
                    tw = int(mon["width"] * 0.75)
                    th = int(mon["height"] * 0.75)
                    tx = mon["left"] + (mon["width"] - tw) // 2
                    ty = mon["top"] + (mon["height"] - th) // 2
                    win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                    win32gui.MoveWindow(hwnd, tx, ty, tw, th, True)
                    return f"Window centered ({title or 'active'})"
        except Exception as e:
            print(f"[ComputerControl] ⚠️ snap_window error: {e}")
        finally:
            pyautogui.FAILSAFE = old_failsafe

    return f"Snapped window to {pos}"


def _window_command(command: str, title: str = "") -> str:
    """Close or minimize a named window without ever targeting NEXUS."""
    if not title or not title.strip():
        return "Debes indicar el título de la aplicación que quieres modificar."
    target = title.strip()
    upper = target.upper()
    if any(token in upper for token in ("NEXUS", "J.A.R.V.I.S", "JARVIS")):
        return "No voy a cerrar ni minimizar la ventana de NEXUS."
    _require_pyautogui()
    focused = False
    if platform.system() == "Windows":
        try:
            import win32gui
            matches = []
            def _find(hwnd, _extra):
                if win32gui.IsWindowVisible(hwnd):
                    caption = win32gui.GetWindowText(hwnd)
                    if target.lower() in caption.lower():
                        matches.append(hwnd)
                return True
            win32gui.EnumWindows(_find, None)
            if matches:
                win32gui.SetForegroundWindow(matches[0])
                focused = True
        except Exception:
            pass
    if not focused:
        result = _focus_window(target)
        if "failed" in result.lower() or "requires" in result.lower():
            return f"No encontré la ventana '{target}'."
    time.sleep(0.15)
    if command == "minimize":
        pyautogui.hotkey("win", "down") if platform.system() == "Windows" else pyautogui.hotkey("alt", "F9")
        return f"Ventana minimizada: {target}"
    pyautogui.hotkey("alt", "f4")
    return f"Ventana cerrada: {target}"

def computer_control(
    parameters: dict,
    response=None,
    player=None,
    session_memory=None,
) -> str:
    """
    Dispatch table for all computer control actions.

    parameters keys (all optional unless noted):
      action        : (required) one of the actions listed below
      text          : text to type or paste
      x, y          : screen coordinates
      button        : 'left' | 'right' (default: left)
      keys          : hotkey string, e.g. 'ctrl+c'
      key           : single key name, e.g. 'enter'
      direction     : 'up' | 'down' | 'left' | 'right'
      amount        : scroll amount (default: 3)
      seconds       : wait duration
      title         : window title fragment for focus_window
      description   : natural-language element description for screen_find/click
      type          : data type for random_data
      field         : memory field name for user_data
      clear_first   : bool, clear field before typing (default: true)
      path          : save path for screenshot (must be inside home dir)

    Actions:
      type          — type text at cursor
      smart_type    — clear field + type (clipboard-backed)
      click         — left click
      double_click  — double left click
      right_click   — right click
      move          — move mouse
      drag          — click-drag between two points
      hotkey        — key combination
      press         — single key
      scroll        — scroll the wheel
      copy          — read clipboard
      paste         — write + paste clipboard
      screenshot    — capture screen (safe path only)
      wait          — sleep N seconds
      clear_field   — select-all + delete
      focus_window  — bring window to foreground
      screen_find   — AI element finder (returns x,y)
      screen_click  — AI element finder + click
      random_data   — generate fake form data
      user_data     — pull real data from memory
    """
    params = parameters or {}
    action = params.get("action", "").lower().strip()

    if not action:
        return "No action specified for computer_control."

    if player:
        player.write_log(f"[Computer] {action}")

    print(f"[ComputerControl] ▶ {action}  {params}")

    try:

        if action == "type":
            return _type(params.get("text", ""))

        if action == "smart_type":
            return _smart_type(
                params.get("text", ""),
                clear_first=params.get("clear_first", True),
            )

        if action in ("click", "left_click"):
            return _click(params.get("x"), params.get("y"), "left", 1)

        if action == "double_click":
            return _click(params.get("x"), params.get("y"), "left", 2)

        if action == "right_click":
            return _click(params.get("x"), params.get("y"), "right", 1)

        if action == "minimize_window":
            return _window_command("minimize", params.get("title", ""))

        if action == "close_window":
            return _window_command("close", params.get("title", ""))

        if action == "move":
            return _move(int(params.get("x", 0)), int(params.get("y", 0)))

        if action == "drag":
            return _drag(
                int(params.get("x1", 0)), int(params.get("y1", 0)),
                int(params.get("x2", 0)), int(params.get("y2", 0)),
            )

        if action == "hotkey":
            raw  = params.get("keys", "")
            keys = [k.strip() for k in raw.split("+")] if isinstance(raw, str) else raw
            return _hotkey(*keys)

        if action == "press":
            return _press(params.get("key", "enter"))

        if action == "scroll":
            return _scroll(
                direction=params.get("direction", "down"),
                amount=int(params.get("amount", 3)),
            )

        if action == "copy":
            return _clipboard_get()

        if action == "paste":
            return _clipboard_paste(params.get("text", ""))

        if action == "screenshot":
            return _screenshot(params.get("path"), monitor=params.get("monitor"))

        if action in ("find_in_page", "search_page"):
            text = params.get("text") or params.get("query") or params.get("description", "")
            next_m = bool(params.get("next", False))
            return _find_in_page(text, next_match=next_m)

        if action in ("screen_find", "smart_find"):
            desc = params.get("description", "")
            coords = _smart_find(desc, preferred_monitor=params.get("monitor"))
            return f"{coords[0]},{coords[1]}" if coords else "NOT_FOUND"

        if action in ("screen_click", "smart_click"):
            desc = params.get("description", "")
            dom_res = _try_browser_dom_click(desc)
            if dom_res:
                return dom_res
            coords = _smart_find(desc, preferred_monitor=params.get("monitor"))
            if coords:
                res = _smooth_click(coords[0], coords[1], button="left", clicks=1)
                return f"{res} on '{desc}'"
            return f"Element not found on screen: '{desc}'"

        if action == "smart_double_click":
            desc = params.get("description", "")
            coords = _smart_find(desc, preferred_monitor=params.get("monitor"))
            if coords:
                res = _smooth_click(coords[0], coords[1], button="left", clicks=2)
                return f"{res} on '{desc}'"
            return f"Element not found on screen: '{desc}'"

        if action == "smart_right_click":
            desc = params.get("description", "")
            coords = _smart_find(desc, preferred_monitor=params.get("monitor"))
            if coords:
                res = _smooth_click(coords[0], coords[1], button="right", clicks=1)
                return f"{res} on '{desc}'"
            return f"Element not found on screen: '{desc}'"

        if action == "snap_window":
            return _snap_window(
                position=params.get("position", "left"),
                title=params.get("title"),
            )

        if action == "wait":
            secs = float(params.get("seconds", 1.0))
            secs = min(secs, 30.0)
            time.sleep(secs)
            return f"Waited {secs}s"

        if action == "clear_field":
            return _clear_field()

        if action == "focus_window":
            return _focus_window(params.get("title", ""))

        if action == "random_data":
            dt     = params.get("type", "name")
            result = _random_data(dt)
            print(f"[ComputerControl] 🎲 random {dt} → {result}")
            return result

        if action == "user_data":
            field   = params.get("field", "name")
            profile = _user_profile()
            value   = profile.get(field, "")
            if not value:
                value = _random_data(field)
                print(f"[ComputerControl] ⚠️ No '{field}' in memory, using random: {value}")
            return value

        return f"Unknown action: '{action}'"

    except Exception as e:
        print(f"[ComputerControl] ❌ {action}: {e}")
        return f"computer_control '{action}' failed: {e}"


# ── Tool declaration (auto-discovered by core/action_loader.py) ──────────────
TOOL = {
    "name": "computer_control",
    "description": "Direct computer control with safe named-window operations. For minimizing or closing apps use minimize_window/close_window with an explicit title; never target NEXUS or JARVIS.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "smart_click | smart_double_click | smart_right_click | smart_find | find_in_page | snap_window | minimize_window | close_window | click | double_click | right_click | type | smart_type | hotkey | press | scroll | move | drag | copy | paste | screenshot | wait | clear_field | focus_window | random_data | user_data"
            },
            "description": {
                "type": "STRING",
                "description": "Natural language UI element description for smart_click / smart_find (e.g. 'botón Guardar', 'icono de descargas', 'primer resultado de Google')"
            },
            "monitor": {
                "type": "STRING",
                "description": "Target screen for screenshot or smart clicks: 'active' (default), '1', '2', 'left', 'right', 'all'"
            },
            "next": {
                "type": "BOOLEAN",
                "description": "For find_in_page: jump to next match"
            },
            "position": {
                "type": "STRING",
                "description": "For snap_window: left | right | maximize | minimize | restore | center"
            },
            "text": {
                "type": "STRING",
                "description": "Text to type or paste"
            },
            "x": {
                "type": "INTEGER",
                "description": "X coordinate"
            },
            "y": {
                "type": "INTEGER",
                "description": "Y coordinate"
            },
            "keys": {
                "type": "STRING",
                "description": "Key combination e.g. 'ctrl+c'"
            },
            "key": {
                "type": "STRING",
                "description": "Single key e.g. 'enter'"
            },
            "direction": {
                "type": "STRING",
                "description": "up | down | left | right"
            },
            "amount": {
                "type": "INTEGER",
                "description": "Scroll amount (default: 3)"
            },
            "seconds": {
                "type": "NUMBER",
                "description": "Seconds to wait"
            },
            "title": {
                "type": "STRING",
                "description": "Window title for focus_window or snap_window. Required when minimizing, maximizing or arranging another app; never use NEXUS/JARVIS."
            },
            "type": {
                "type": "STRING",
                "description": "Data type for random_data"
            },
            "field": {
                "type": "STRING",
                "description": "Field for user_data: name|email|city"
            },
            "clear_first": {
                "type": "BOOLEAN",
                "description": "Clear field before typing (default: true)"
            },
            "path": {
                "type": "STRING",
                "description": "Save path for screenshot"
            }
        },
        "required": [
            "action"
        ]
    },
    "handler": computer_control,
}
