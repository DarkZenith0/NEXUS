# media_player.py
"""
Media Player & Playback Controller for N.E.X.U.S.

Provides everyday capabilities:
1. Play songs/music on Spotify, YouTube Music, or YouTube with autoplay.
2. Play on-screen videos in browser or media player (standard or fullscreen).
3. Universal OS media controls (play/pause, next track, previous track, stop, mute, volume).
Works system-wide without requiring window focus or interfering with other actions.
"""
from __future__ import annotations

import ctypes
import os
import platform
import re
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path
from typing import Optional

# ── Platform detection ───────────────────────────────────────────────────────
_IS_WINDOWS = platform.system() == "Windows"
_IS_MAC = platform.system() == "Darwin"
_IS_LINUX = platform.system() == "Linux"

# ── Windows Virtual-Key Codes for Multimedia ────────────────────────────────
_VK_MEDIA_NEXT_TRACK = 0xB0
_VK_MEDIA_PREV_TRACK = 0xB1
_VK_MEDIA_STOP       = 0xB2
_VK_MEDIA_PLAY_PAUSE = 0xB3
_VK_VOLUME_MUTE      = 0xAD
_VK_VOLUME_DOWN      = 0xAE
_VK_VOLUME_UP        = 0xAF
_KEYEVENTF_KEYUP     = 0x0002

_CNW = (
    {"creationflags": subprocess.CREATE_NO_WINDOW}
    if _IS_WINDOWS else {}
)


def _log_print(msg: str) -> None:
    try:
        print(msg)
    except Exception:
        try:
            print(msg.encode("ascii", "replace").decode("ascii"))
        except Exception:
            pass


def _open_url_or_uri(uri: str) -> bool:
    """Open URL or URI protocol handler cross-platform."""
    try:
        if _IS_WINDOWS:
            os.startfile(uri)
            return True
        elif _IS_MAC:
            subprocess.Popen(["open", uri])
            return True
        elif _IS_LINUX:
            subprocess.Popen(["xdg-open", uri])
            return True
    except Exception as e:
        _log_print(f"[MediaPlayer] Failed to open {uri}: {e}")
        try:
            if _IS_WINDOWS:
                subprocess.Popen(["cmd", "/c", "start", "", uri], shell=False, **_CNW)
                return True
        except Exception:
            pass
    return False


def _send_win_media_key(vk_code: int) -> bool:
    """Send hardware-level multimedia key event on Windows."""
    if not _IS_WINDOWS:
        return False
    try:
        user32 = ctypes.windll.user32
        user32.keybd_event(vk_code, 0, 0, 0)
        time.sleep(0.04)
        user32.keybd_event(vk_code, 0, _KEYEVENTF_KEYUP, 0)
        return True
    except Exception as e:
        _log_print(f"[MediaPlayer] Error sending key 0x{vk_code:02X}: {e}")
        return False


def _scrape_youtube_first_video(query: str) -> Optional[str]:
    """Find the top matching YouTube video ID for a query."""
    try:
        import requests
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
        }
        search_url = f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(query)}"
        r = requests.get(search_url, headers=headers, timeout=5)
        if r.status_code == 200:
            video_ids = re.findall(r'"videoId":"([A-Za-z0-9_-]{11})"', r.text)
            for vid in video_ids:
                if f"/shorts/{vid}" not in r.text[:r.text.find(vid) + 50]:
                    return vid
            if video_ids:
                return video_ids[0]
    except Exception as e:
        _log_print(f"[MediaPlayer] Video scrape fallback: {e}")
    return None


# ── Action Handlers ──────────────────────────────────────────────────────────

def _handle_play_music(params: dict, player=None) -> str:
    query = str(params.get("query") or params.get("song") or "").strip()
    platform_pref = str(params.get("platform") or "default").lower().strip()

    if not query:
        # If no query specified, just trigger play/resume
        _send_win_media_key(_VK_MEDIA_PLAY_PAUSE)
        return "Reanudando reproducción de música."

    if player:
        player.write_log(f"[MediaPlayer] 🎵 Música: '{query}' (plataforma: {platform_pref})")
    _log_print(f"[MediaPlayer] Musica: '{query}' ({platform_pref})")

    # 1. Spotify
    if platform_pref in ("spotify", "sp"):
        # Try native Spotify URI first
        encoded_q = urllib.parse.quote(query)
        spotify_uri = f"spotify:search:{encoded_q}"
        if _open_url_or_uri(spotify_uri):
            return f"Buscando y reproduciendo '{query}' en Spotify."
        web_url = f"https://open.spotify.com/search/{encoded_q}"
        _open_url_or_uri(web_url)
        return f"Abriendo '{query}' en Spotify Web."

    # 2. YouTube Music
    if platform_pref in ("youtube_music", "ytm", "ytmusic"):
        encoded_q = urllib.parse.quote_plus(query)
        ytm_url = f"https://music.youtube.com/search?q={encoded_q}"
        _open_url_or_uri(ytm_url)
        return f"Reproduciendo '{query}' en YouTube Music."

    # 3. Default / Smart: Check if Spotify is running, else direct YouTube with autoplay
    if _IS_WINDOWS:
        try:
            # Check if Spotify is active in process list
            out = subprocess.check_output(
                ["tasklist", "/FI", "IMAGENAME eq Spotify.exe", "/NH"],
                creationflags=subprocess.CREATE_NO_WINDOW if _IS_WINDOWS else 0,
                text=True
            )
            if "Spotify.exe" in out:
                encoded_q = urllib.parse.quote(query)
                if _open_url_or_uri(f"spotify:search:{encoded_q}"):
                    return f"Reproduciendo '{query}' en Spotify."
        except Exception:
            pass

    # Direct top track playback on YouTube
    vid = _scrape_youtube_first_video(f"{query} song audio")
    if vid:
        watch_url = f"https://www.youtube.com/watch?v={vid}&autoplay=1"
        _open_url_or_uri(watch_url)
        return f"Reproduciendo la canción '{query}' en pantalla."

    yt_search = f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(query)}"
    _open_url_or_uri(yt_search)
    return f"Buscando y reproduciendo '{query}' en YouTube."


def _handle_play_video(params: dict, player=None) -> str:
    query = str(params.get("query") or params.get("video") or "").strip()
    fullscreen = bool(params.get("fullscreen", False))

    if not query:
        _send_win_media_key(_VK_MEDIA_PLAY_PAUSE)
        return "Reanudando reproducción de video."

    if player:
        player.write_log(f"[MediaPlayer] 🎬 Video: '{query}' (fullscreen={fullscreen})")
    _log_print(f"[MediaPlayer] Video: '{query}' (fullscreen={fullscreen})")

    # If it's a direct URL or local video file
    if query.startswith("http://") or query.startswith("https://"):
        url = query
        if fullscreen and "youtube.com/watch?v=" in url:
            vid = url.split("watch?v=")[-1].split("&")[0]
            url = f"https://www.youtube.com/embed/{vid}?autoplay=1"
        elif "autoplay=1" not in url and "youtube.com" in url:
            url += "&autoplay=1" if "?" in url else "?autoplay=1"
        _open_url_or_uri(url)
        return f"Reproduciendo video en pantalla: {url}"

    if os.path.isfile(query):
        _open_url_or_uri(query)
        return f"Abriendo archivo de video local: {os.path.basename(query)}"

    # Search for top video
    vid = _scrape_youtube_first_video(query)
    if vid:
        if fullscreen:
            target_url = f"https://www.youtube.com/embed/{vid}?autoplay=1"
        else:
            target_url = f"https://www.youtube.com/watch?v={vid}&autoplay=1"
        _open_url_or_uri(target_url)
        mode_str = " en pantalla completa" if fullscreen else ""
        return f"Reproduciendo el video '{query}'{mode_str}."

    search_url = f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(query)}"
    _open_url_or_uri(search_url)
    return f"Buscando video de '{query}' en YouTube."


def _handle_media_control(params: dict, player=None) -> str:
    cmd = str(params.get("command") or params.get("action") or "play_pause").lower().strip()
    cmd = cmd.replace("-", "_").replace(" ", "_")

    if player:
        player.write_log(f"[MediaPlayer] ⏯️ Control multimedia: {cmd}")
    _log_print(f"[MediaPlayer] Control multimedia: {cmd}")

    if _IS_WINDOWS:
        if cmd in ("play_pause", "toggle", "play", "pause", "reproducir", "pausar", "parar"):
            _send_win_media_key(_VK_MEDIA_PLAY_PAUSE)
            return "Reproducción alternada (Play/Pausa)."
        elif cmd in ("next", "next_track", "siguiente", "pasar"):
            _send_win_media_key(_VK_MEDIA_NEXT_TRACK)
            return "Pista siguiente reproducida."
        elif cmd in ("prev", "previous", "previous_track", "anterior"):
            _send_win_media_key(_VK_MEDIA_PREV_TRACK)
            return "Pista anterior reproducida."
        elif cmd in ("stop", "detener"):
            _send_win_media_key(_VK_MEDIA_STOP)
            return "Reproducción detenida."
        elif cmd in ("volume_up", "subir_volumen", "subir"):
            _send_win_media_key(_VK_VOLUME_UP)
            _send_win_media_key(_VK_VOLUME_UP)
            return "Volumen incrementado."
        elif cmd in ("volume_down", "bajar_volumen", "bajar"):
            _send_win_media_key(_VK_VOLUME_DOWN)
            _send_win_media_key(_VK_VOLUME_DOWN)
            return "Volumen reducido."
        elif cmd in ("mute", "silenciar", "unmute"):
            _send_win_media_key(_VK_VOLUME_MUTE)
            return "Silencio multimedia alternado (Mute)."
    elif _IS_MAC:
        try:
            if cmd in ("play_pause", "toggle", "play", "pause"):
                subprocess.Popen(["osascript", "-e", 'tell application "Music" to playpause'])
            elif cmd in ("next", "next_track"):
                subprocess.Popen(["osascript", "-e", 'tell application "Music" to next track'])
            elif cmd in ("prev", "previous"):
                subprocess.Popen(["osascript", "-e", 'tell application "Music" to previous track'])
            return f"Comando multimedia '{cmd}' enviado."
        except Exception:
            pass

    return f"Comando multimedia '{cmd}' ejecutado."


# ── Action Dispatcher ────────────────────────────────────────────────────────

def media_player(
    parameters: dict,
    response=None,
    player=None,
    session_memory=None,
    speak=None,
) -> str:
    """Dispatches media playback, streaming, and universal controls."""
    params = parameters or {}
    action = str(params.get("action") or "").lower().strip()

    if action in ("play_music", "play_song", "song", "music", "musica", "cancion"):
        return _handle_play_music(params, player)
    elif action in ("play_video", "video"):
        return _handle_play_video(params, player)
    elif action in ("media_control", "control", "playback", "volume", "next", "prev", "pause", "play"):
        if "command" not in params and action in ("next", "prev", "pause", "play"):
            params["command"] = action
        return _handle_media_control(params, player)

    # Smart fallback based on parameters
    if "song" in params or "music" in params:
        return _handle_play_music(params, player)
    if "video" in params:
        return _handle_play_video(params, player)
    if "command" in params:
        return _handle_media_control(params, player)

    # Default to playing music or media control
    query = params.get("query")
    if query:
        return _handle_play_music(params, player)
    return _handle_media_control({"command": "play_pause"}, player)


# ── Tool declaration (auto-discovered by core/action_loader.py) ──────────────
TOOL = {
    "name": "media_player",
    "description": (
        "Controls on-screen media playback, music, and videos. "
        "Use for: playing songs or music on Spotify or YouTube Music, "
        "playing videos on screen with autoplay, and system media controls "
        "(play, pause, next track, previous track, mute, stop)."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "play_music | play_video | media_control (default: play_music)"
            },
            "query": {
                "type": "STRING",
                "description": "Name of the song, artist, album, playlist, or video to play"
            },
            "platform": {
                "type": "STRING",
                "description": "spotify | youtube_music | youtube | default"
            },
            "fullscreen": {
                "type": "BOOLEAN",
                "description": "Play video in fullscreen mode (play_video only)"
            },
            "command": {
                "type": "STRING",
                "description": "play_pause | next | previous | stop | volume_up | volume_down | mute (media_control only)"
            }
        },
        "required": []
    },
    "handler": media_player,
}
