"""
actions/work_agent.py — Motor de Modo Trabajo y Razonamiento Profundo para N.E.X.U.S.

Permite a NEXUS:
1. Redactar extensos informes profesionales multi-sección (con tablas, análisis profundo,
   conclusiones y recomendaciones) guardados en Markdown y Word (.docx).
2. Generar código completo, arquitecturas limpias y scripts ejecutables sin truncado.
3. Analizar documentos extensos (PDFs, DOCX, TXT) en su totalidad.
4. Alternar activamente entre Modo Trabajo (Deep Reasoning) y Modo Rápido (Baja Latencia).
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from core import gemini

def _get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent

BASE_DIR = _get_base_dir()

from core.nexus_paths import NEXUS_DOCUMENTS, ensure_nexus_dirs

# Carpeta estándar para informes y documentos de NEXUS (NEXUS UPLOADS / NEXUS DOCUMENTS)
def _get_reports_dir() -> Path:
    ensure_nexus_dirs()
    return NEXUS_DOCUMENTS

# Estado global del modo de trabajo
_WORK_MODE_ACTIVE = False
_WORK_MODE_LISTENERS: list[Any] = []

def is_work_mode() -> bool:
    return _WORK_MODE_ACTIVE

def set_work_mode(active: bool) -> None:
    global _WORK_MODE_ACTIVE
    _WORK_MODE_ACTIVE = bool(active)
    for listener in _WORK_MODE_LISTENERS:
        try:
            listener(_WORK_MODE_ACTIVE)
        except Exception:
            pass

def register_work_mode_listener(callback) -> None:
    if callback not in _WORK_MODE_LISTENERS:
        _WORK_MODE_LISTENERS.append(callback)


def _slugify(text: str, max_len: int = 30) -> str:
    cleaned = re.sub(r"[^\w\s-]", "", text, flags=re.UNICODE).strip().lower()
    slug = re.sub(r"[-\s]+", "_", cleaned)
    return slug[:max_len] or "informe"


def _read_source_file(file_path: str) -> str:
    if not file_path:
        return ""
    p = Path(file_path)
    if not p.exists():
        return ""
    ext = p.suffix.lower()
    
    if ext == ".pdf":
        try:
            import pdfplumber
            text_parts = []
            with pdfplumber.open(p) as pdf:
                for page in pdf.pages:
                    t = page.extract_text()
                    if t:
                        text_parts.append(t)
            return "\n\n".join(text_parts)
        except Exception:
            try:
                import pypdf
                reader = pypdf.PdfReader(str(p))
                return "\n\n".join(page.extract_text() or "" for page in reader.pages)
            except Exception:
                pass
                
    elif ext in (".docx", ".doc"):
        try:
            import docx
            doc = docx.Document(p)
            return "\n\n".join(para.text for para in doc.paragraphs if para.text.strip())
        except Exception:
            pass
            
    try:
        return p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""


def _save_to_docx(markdown_text: str, docx_path: Path, title: str) -> bool:
    """Convierte el informe estructurado en Markdown a un documento Microsoft Word (.docx)."""
    try:
        import docx
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        
        doc = docx.Document()
        
        # Título principal
        h1 = doc.add_heading(title, 0)
        h1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Fecha y metadata
        meta = doc.add_paragraph()
        meta.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        run_meta = meta.add_run(f"Generado por N.E.X.U.S V3 — {datetime.now().strftime('%d/%m/%Y %H:%M')}")
        run_meta.font.size = Pt(9)
        run_meta.font.italic = True
        run_meta.font.color.rgb = RGBColor(128, 128, 128)
        
        doc.add_paragraph()  # Espacio
        
        lines = markdown_text.splitlines()
        in_code_block = False
        code_lines = []
        
        for line in lines:
            sline = line.strip()
            if sline.startswith("```"):
                if in_code_block:
                    p = doc.add_paragraph("\n".join(code_lines))
                    p.style = "No Spacing"
                    for r in p.runs:
                        r.font.name = "Consolas"
                        r.font.size = Pt(9.5)
                    code_lines = []
                    in_code_block = False
                else:
                    in_code_block = True
                    code_lines = []
                continue
                
            if in_code_block:
                code_lines.append(line)
                continue
                
            if not sline:
                continue
                
            if sline.startswith("# "):
                doc.add_heading(sline[2:].strip(), level=1)
            elif sline.startswith("## "):
                doc.add_heading(sline[3:].strip(), level=2)
            elif sline.startswith("### "):
                doc.add_heading(sline[4:].strip(), level=3)
            elif sline.startswith("- ") or sline.startswith("* "):
                p = doc.add_paragraph(style="List Bullet")
                _add_markdown_runs(p, sline[2:].strip())
            elif re.match(r"^\d+\.\s+", sline):
                content = re.sub(r"^\d+\.\s+", "", sline)
                p = doc.add_paragraph(style="List Number")
                _add_markdown_runs(p, content)
            else:
                p = doc.add_paragraph()
                _add_markdown_runs(p, sline)
                
        docx_path.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(docx_path))
        return True
    except Exception as e:
        print(f"[WorkAgent] [WARN] Error saving .docx: {e}")
        return False


def _add_markdown_runs(paragraph, text: str):
    """Maneja negritas simples (**texto**) al escribir en párrafos de Word."""
    parts = re.split(r"(\*\*.*?\*\*)", text)
    for part in parts:
        if part.startswith("**") and part.endswith("**") and len(part) >= 4:
            r = paragraph.add_run(part[2:-2])
            r.bold = True
        else:
            paragraph.add_run(part)


def _notify_content_and_remote(title: str, content: str, player=None) -> None:
    """Envía el documento al panel de la UI del escritorio y al dashboard móvil."""
    # 1. UI local (PyQt6)
    if player and hasattr(player, "show_content"):
        try:
            player.show_content(title, content)
        except Exception:
            pass
            
    # 2. Control Remoto Móvil (Dashboard Server)
    try:
        from dashboard import server as ds_server
        inst = getattr(ds_server, "_server_instance", None)
        if inst and hasattr(inst, "broadcast"):
            msg = {
                "type": "document",
                "title": title,
                "content": content,
                "ts": datetime.now().isoformat(),
            }
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    asyncio.create_task(inst.broadcast(msg))
                else:
                    loop.run_until_complete(inst.broadcast(msg))
            except Exception:
                pass
    except Exception:
        pass


def work_agent_handler(parameters: dict, player=None, speak=None, session_memory=None) -> str:
    """
    Punto de entrada de la herramienta work_agent.
    """
    action = (parameters.get("action") or "").lower().strip()
    topic = parameters.get("topic") or ""
    details = parameters.get("details") or ""
    file_path = parameters.get("file_path") or ""
    mode = (parameters.get("mode") or "").lower().strip()
    
    # ── 1. GESTIÓN DE MODO TRABAJO / MODO RÁPIDO ────────────────────────────
    if action == "set_mode":
        if mode in ("work", "trabajo", "deep", "pro", "on", "true"):
            set_work_mode(True)
            if player and hasattr(player, "write_log"):
                player.write_log("[MODO] 🧠 Modo Trabajo ACTIVADO (Modelos Pro / Razonamiento)")
            return (
                "Modo Trabajo activado, señor. A partir de ahora emplearé modelos de "
                "razonamiento avanzado (Gemini 2.5 Pro) para informes exhaustivos, "
                "análisis profundos y desarrollo de código completo."
            )
        else:
            set_work_mode(False)
            if player and hasattr(player, "write_log"):
                player.write_log("[MODO] ⚡ Modo Rápido ACTIVADO (Baja latencia)")
            return (
                "Modo Rápido activado, señor. He restablecido la máxima velocidad de respuesta "
                "inmediata para conversación y control del equipo."
            )

    # ── 2. REDACCIÓN DE EXTENSOS INFORMES / INVESTIGACIÓN EN PROFUNDIDAD ─────
    if action in ("create_report", "deep_research", "comprehensive_analysis"):
        if not topic and file_path:
            topic = f"Análisis de {Path(file_path).name}"
        if not topic:
            return "Indica el tema o documento sobre el cual deseas que redacte el informe."

        print(f"[WorkAgent] [WORK] Redactando informe en profundidad sobre: {topic}")
        if player and hasattr(player, "write_log"):
            player.write_log(f"[WorkAgent] [DOC] Redactando informe exhaustivo: {topic}...")

        # Leer archivo fuente si se especificó
        source_context = ""
        if file_path:
            content = _read_source_file(file_path)
            if content:
                source_context = f"\n\n--- DOCUMENTO FUENTE ({Path(file_path).name}) ---\n{content[:75000]}"
                print(f"[WorkAgent] [FILE] Incluidos {len(content):,} caracteres de documento fuente.")

        # Realizar búsquedas de apoyo si se requiere investigación
        web_context = ""
        if action == "deep_research" or "investiga" in details.lower() or "noticias" in details.lower():
            try:
                from actions.web_search import _search_duckduckgo
                search_results = _search_duckduckgo(topic, max_results=5)
                if search_results:
                    web_context = f"\n\n--- DATOS DE INVESTIGACIÓN WEB RECIENTE ---\n{search_results}"
            except Exception:
                pass

        prompt = (
            f"Actúa como un analista e investigador senior de élite. Redacta un INFORME EXHAUSTIVO, "
            f"EXTENSO Y PROFUNDAMENTE ESTRUCTURADO sobre el siguiente tema:\n\n"
            f"TEMA: {topic}\n"
            f"INSTRUCCIONES ADICIONALES: {details}\n"
            f"{web_context}\n"
            f"{source_context}\n\n"
            f"REGLAS OBLIGATORIAS DE REDACCIÓN:\n"
            f"1. IDIOMA: 100% en ESPAÑOL formal, técnico y profesional.\n"
            f"2. EXTENSIÓN: NO hagas un simple resumen. Debe ser un informe exhaustivo, desglosado minuciosamente "
            f"con el máximo nivel de detalle, análisis crítico y profundidad intelectual.\n"
            f"3. FORMATO MARKDOWN PROFESIONAL:\n"
            f"   - # TÍTULO DEL INFORME\n"
            f"   - ## 1. Resumen Ejecutivo (Conclusiones clave sintetizadas)\n"
            f"   - ## 2. Marco Teórico / Contexto y Antecedentes\n"
            f"   - ## 3. Análisis en Profundidad (con subsecciones ### 3.1, ### 3.2, etc.)\n"
            f"   - ## 4. Tabla Comparativa o Métricas Clave (usando tablas Markdown | Col | Col |)\n"
            f"   - ## 5. Riesgos, Oportunidades e Impacto\n"
            f"   - ## 6. Recomendaciones Tácticas y Próximos Pasos\n"
            f"   - ## 7. Conclusión Final y Referencias\n"
            f"4. Proporciona datos concretos, ejemplos prácticos y argumentación sólida. Evita generalidades."
        )

        try:
            report_text = gemini.text(prompt, tier=gemini.WORK, timeout_ms=180000)
            if not report_text or len(report_text) < 100:
                report_text = gemini.text(prompt, tier=gemini.SMART, timeout_ms=90000)
        except Exception as e:
            return f"Error durante la generación del informe: {e}"

        if not report_text:
            return "No se pudo generar el informe debido a un fallo en los modelos de lenguaje."

        # Guardar en archivo
        now = datetime.now()
        slug = _slugify(topic)
        ts_str = now.strftime("%Y%m%d_%H%M%S")
        reports_dir = _get_reports_dir()
        
        md_file = reports_dir / f"Informe_{slug}_{ts_str}.md"
        docx_file = reports_dir / f"Informe_{slug}_{ts_str}.docx"
        
        try:
            md_file.write_text(report_text, encoding="utf-8")
            _save_to_docx(report_text, docx_file, topic)
        except Exception as e:
            print(f"[WorkAgent] [WARN] Error saving files: {e}")

        # Mostrar en pantalla y móvil
        _notify_content_and_remote(f"INFORME: {topic[:40]}", report_text, player=player)

        # Extraer las primeras 2-3 frases para el resumen verbal
        first_lines = [l.strip() for l in report_text.splitlines() if l.strip() and not l.startswith("#")]
        verbal_summary = " ".join(first_lines[:3])[:320]
        if len(verbal_summary) > 300:
            verbal_summary = verbal_summary[:300] + "..."

        return (
            f"Informe exhaustivo redactado con éxito y abierto en su pantalla, señor. "
            f"He guardado las versiones completas en Markdown y Word en su carpeta de documentos ({md_file.name}). "
            f"Resumen clave: {verbal_summary}"
        )

    # ── 3. GENERACIÓN DE CÓDIGO COMPLETO Y ARQUITECTURAS ──────────────────────
    if action in ("generate_code", "build_script"):
        if not topic:
            return "Indica qué software, script o módulo de código necesitas que desarrolle."

        print(f"[WorkAgent] [CODE] Generando código en profundidad: {topic}")
        if player and hasattr(player, "write_log"):
            player.write_log(f"[WorkAgent] [CODE] Desarrollando código completo: {topic}...")

        prompt = (
            f"Actúa como un Ingeniero de Software Principal de Google. Desarrolla una solución "
            f"de código COMPLETA, ROBUSTA, MODULAR Y LISTA PARA PRODUCCIÓN para la siguiente necesidad:\n\n"
            f"OBJETIVO: {topic}\n"
            f"ESPECIFICACIONES / DETALLES: {details}\n\n"
            f"REGLAS CRÍTICAS:\n"
            f"1. CÓDIGO ÍNTEGRO: PROHIBIDO USAR '// ... resto del código', 'pass', 'TODO' o dejar funciones a medias. "
            f"Escribe cada línea de código de forma completa y funcional.\n"
            f"2. Manejo exhaustivo de excepciones, tipado estricto (type hints) y comentarios técnicos explicativos.\n"
            f"3. Si se requieren dependencias externas, incluye al inicio las instrucciones de instalación (pip install / npm install).\n"
            f"4. Proporciona un bloque de prueba/ejecución 'if __name__ == \"__main__\":' o ejemplo de uso verificable.\n"
            f"5. Redacta las explicaciones de acompañamiento SIEMPRE EN ESPAÑOL claro y directo."
        )

        try:
            code_result = gemini.text(prompt, tier=gemini.WORK, timeout_ms=180000)
            if not code_result or len(code_result) < 50:
                code_result = gemini.text(prompt, tier=gemini.SMART, timeout_ms=90000)
        except Exception as e:
            return f"Error durante la generación de código: {e}"

        if not code_result:
            return "No fue posible generar el código solicitado."

        # Determinar ruta de guardado
        save_target = None
        if file_path:
            save_target = Path(file_path)
            if not save_target.is_absolute():
                save_target = Path.home() / "Desktop" / save_target
        else:
            # Extraer lenguaje probable o crear archivo en Desktop
            ext = ".py"
            if "javascript" in topic.lower() or "js" in topic.lower(): ext = ".js"
            elif "typescript" in topic.lower() or "ts" in topic.lower(): ext = ".ts"
            elif "html" in topic.lower(): ext = ".html"
            elif "powershell" in topic.lower() or "ps1" in topic.lower(): ext = ".ps1"
            elif "c++" in topic.lower() or "cpp" in topic.lower(): ext = ".cpp"
            
            slug = _slugify(topic, max_len=24)
            save_target = Path.home() / "Desktop" / f"nexus_{slug}{ext}"

        # Extraer solo el código si viene dentro de fences
        pure_code = code_result
        if "```" in code_result:
            matches = re.findall(r"```(?:[a-zA-Z0-9_\-]+)?\n(.*?)```", code_result, re.DOTALL)
            if matches:
                pure_code = max(matches, key=len).strip()

        try:
            save_target.parent.mkdir(parents=True, exist_ok=True)
            save_target.write_text(pure_code, encoding="utf-8")
        except Exception as e:
            print(f"[WorkAgent] [WARN] Error saving code file: {e}")

        # Desplegar en panel de contenido y móvil
        _notify_content_and_remote(f"CÓDIGO: {save_target.name}", code_result, player=player)

        return (
            f"Código desarrollado con éxito y guardado en su Escritorio ({save_target.name}). "
            f"El código completo y sus instrucciones están desplegados en su pantalla."
        )

    return f"Acción desconocida para work_agent: '{action}'. Opciones válidas: create_report, generate_code, deep_research, set_mode."


# ── Tool declaration (auto-discovered by core/action_loader.py) ──────────────
TOOL = {
    "name": "work_agent",
    "description": (
        "Herramienta de MODO TRABAJO y Razonamiento Profundo. "
        "Permite redactar extensos informes de investigación estructurados, "
        "desarrollar código de software completo y modular, realizar análisis exhaustivos "
        "de documentos sin límite de longitud o alternar entre Modo Trabajo y Modo Rápido."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": (
                    "Acción a ejecutar: 'create_report' (redacta informe exhaustivo), "
                    "'generate_code' (desarrolla software completo), "
                    "'deep_research' (investigación profunda), "
                    "'set_mode' (activa o desactiva Modo Trabajo)."
                ),
            },
            "topic": {
                "type": "STRING",
                "description": "Tema central del informe, investigación o función del código.",
            },
            "details": {
                "type": "STRING",
                "description": "Especificaciones, secciones requeridas, fuentes o restricciones.",
            },
            "file_path": {
                "type": "STRING",
                "description": "Ruta opcional de archivo a analizar en profundidad o archivo destino de código.",
            },
            "mode": {
                "type": "STRING",
                "description": "Para 'set_mode': 'work' para Modo Trabajo o 'fast' para Modo Rápido.",
            },
        },
        "required": ["action"],
    },
    "handler": work_agent_handler,
}
