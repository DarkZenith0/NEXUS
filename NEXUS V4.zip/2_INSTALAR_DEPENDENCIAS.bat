@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title PASO 2 - Instalador de Dependencias N.E.X.U.S V4
cd /d "%~dp0"

echo ===============================================================================
echo         N.E.X.U.S V4 - PASO 2: INSTALACION DE DEPENDENCIAS Y LIBRERIAS
echo ===============================================================================
echo.

if not exist "requirements.txt" (
    echo [ERROR CRITICO] No se encuentra el archivo 'requirements.txt'.
    echo Asegurate de descomprimir el ZIP antes de ejecutar este archivo.
    pause
    exit /b 1
)

set "PY_CMD="
py -3 --version >nul 2>&1 && set "PY_CMD=py -3"
if not defined PY_CMD python --version >nul 2>&1 && set "PY_CMD=python"
if not defined PY_CMD if exist "C:\Python314\python.exe" set "PY_CMD=C:\Python314\python.exe"
if not defined PY_CMD if exist "C:\Program Files\Python312\python.exe" set "PY_CMD=C:\Program Files\Python312\python.exe"
if not defined PY_CMD if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY_CMD=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"

if not defined PY_CMD (
    echo [ERROR] No se encuentra Python en el sistema.
    echo Por favor, ejecuta primero: 1_INSTALAR_PYTHON.bat
    pause
    exit /b 1
)

echo [OK] Python detectado:
%PY_CMD% --version
echo.

echo [1/3] Actualizando gestor de paquetes pip...
%PY_CMD% -m pip install --upgrade pip --quiet

echo.
echo [2/3] Instalando librerias de N.E.X.U.S (IA, sonido, interfaz, dashboard, etc.)...
echo       (Esto puede tardar 1 o 2 minutos, ten paciencia)...
echo.
%PY_CMD% -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo.
    echo [!] Asegurando paquetes esenciales de contingencia...
    %PY_CMD% -m pip install PyQt6 sounddevice soundfile edge-tts numpy "google-genai>=2.8.0,<3" requests beautifulsoup4 playwright pyautogui pyperclip pygetwindow pillow psutil fastapi "uvicorn[standard]" cryptography python-multipart qrcode[pil] httpx python-docx openpyxl ddgs
)

echo.
echo [3/3] Instalando navegador para automatizaciones web (Playwright Chromium)...
%PY_CMD% -m playwright install chromium

echo.
echo [*] Verificando integracion de librerias criticas...
%PY_CMD% -c "import PyQt6, sounddevice, edge_tts, google.genai, fastapi, uvicorn, cryptography, psutil, PIL, requests; print('[TEST OK] Todas las librerias importadas con exito.')"

echo.
echo ===============================================================================
echo  [EXITO TOTAL] ¡Todas las dependencias estan instaladas y verificadas!
echo  Ahora ya puedes abrir N.E.X.U.S ejecutando el ultimo paso:
echo.
echo   ---> 3_INICIAR_NEXUS.bat
echo ===============================================================================
echo.
pause
exit /b 0
