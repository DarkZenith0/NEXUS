@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title PASO 1 - Instalador de Python para N.E.X.U.S V4
cd /d "%~dp0"

echo ===============================================================================
echo            N.E.X.U.S V4 - PASO 1: INSTALACION Y VERIFICACION DE PYTHON
echo ===============================================================================
echo.

:: 1. Comprobar si Python ya esta instalado en el sistema
set "PY_FOUND=0"
set "PY_EXE="

py -3 --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PY_EXE=py -3"
    set "PY_FOUND=1"
    goto :python_ready
)

python --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PY_EXE=python"
    set "PY_FOUND=1"
    goto :python_ready
)

if exist "C:\Python314\python.exe" (
    set "PY_EXE=C:\Python314\python.exe"
    set "PY_FOUND=1"
    goto :python_ready
)
if exist "C:\Program Files\Python312\python.exe" (
    set "PY_EXE=C:\Program Files\Python312\python.exe"
    set "PY_FOUND=1"
    goto :python_ready
)
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    set "PY_FOUND=1"
    goto :python_ready
)

:: 2. Si no se encuentra, descargarlo e instalarlo automaticamente
echo [!] Python no esta detectado en el PATH de Windows.
echo [*] Iniciando instalacion automatica de Python oficial para Windows (64-bit)...
echo.

where winget >nul 2>&1
if %errorlevel% equ 0 (
    echo [*] Instalando Python mediante Windows Package Manager (winget)...
    winget install Python.Python.3.12 --scope machine --accept-package-agreements --accept-source-agreements
    if %errorlevel% equ 0 goto :post_install
)

set "INSTALLER=%TEMP%\python_installer_nexus.exe"
if exist "%INSTALLER%" del /f /q "%INSTALLER%" >nul 2>&1

echo [*] Descargando instalador oficial de Python 3.12 (64-bit)...
where curl.exe >nul 2>&1
if %errorlevel% equ 0 (
    curl.exe -L -o "%INSTALLER%" "https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe"
) else (
    powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe', '%INSTALLER%')"
)

if not exist "%INSTALLER%" (
    echo.
    echo [ERROR] No se pudo descargar el instalador automaticamente.
    echo Por favor, descargalo manualmente desde: https://www.python.org/downloads/
    echo IMPORTANTE: Marca la casilla "[X] Add python.exe to PATH" durante la instalacion.
    echo.
    pause
    exit /b 1
)

echo [*] Instalando Python con Add to PATH activado...
echo     Si Windows te solicita permisos de administrador, pulsa "Si".
"%INSTALLER%" /passive InstallAllUsers=1 PrependPath=1 Include_pip=1
if %errorlevel% neq 0 (
    "%INSTALLER%" /passive PrependPath=1 Include_pip=1
)
del /f /q "%INSTALLER%" >nul 2>&1

:post_install
echo.
echo ===============================================================================
echo  [OK] PASO 1 COMPLETADO: Python se ha instalado correctamente.
echo  Ahora ya puedes continuar con el siguiente archivo:
echo.
echo   ---> 2_INSTALAR_DEPENDENCIAS.bat
echo ===============================================================================
echo.
pause
exit /b 0

:python_ready
echo ===============================================================================
echo  [OK] PYTHON YA ESTA INSTALADO Y DETECTADO EN TU EQUIPO:
echo ===============================================================================
echo.
echo  Comando detectado: %PY_EXE%
%PY_EXE% --version
echo.
echo  No necesitas instalar nada en este paso.
echo  Ya puedes cerrar esta ventana y ejecutar el siguiente paso:
echo.
echo   ---> 2_INSTALAR_DEPENDENCIAS.bat
echo ===============================================================================
echo.
pause
exit /b 0
