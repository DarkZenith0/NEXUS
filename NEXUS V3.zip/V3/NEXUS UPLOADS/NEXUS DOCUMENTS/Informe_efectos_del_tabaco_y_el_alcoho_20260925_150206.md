# INFORME TÉCNICO: IMPACTO FISIOLÓGICO Y NEUROCOGNITIVO DEL CONSUMO DE TABACO Y ALCOHOL EN POBLACIÓN MENOR DE EDAD

## 1. Resumen Ejecutivo
El consumo de tabaco y alcohol durante la etapa de desarrollo infanto-juvenil constituye una crisis de salud pública de dimensiones críticas. La evidencia científica demuestra que el cerebro adolescente, caracterizado por una intensa maduración neurobiológica y plasticidad sináptica, es altamente vulnerable a las sustancias psicoactivas. La nicotina altera los sistemas de recompensa y aumenta la propensión a la adicción, mientras que el etanol induce neurotoxicidad, afectando el córtex prefrontal y el hipocampo. Las consecuencias trascienden el daño orgánico inmediato, manifestándose a largo plazo en déficits cognitivos permanentes, trastornos de salud mental y un incremento exponencial en la probabilidad de desarrollar dependencia en la vida adulta. Este informe detalla los mecanismos moleculares y sistémicos de dicho impacto, proponiendo estrategias de mitigación basadas en la evidencia.

## 2. Marco Teórico / Contexto y Antecedentes
La adolescencia, comprendida aproximadamente entre los 10 y los 19 años, representa un periodo de reorganización cerebral fundamental. Durante esta fase, la poda sináptica y la mielinización optimizan la conectividad neuronal. Sin embargo, el sistema dopaminérgico mesolímbico madura más rápidamente que las áreas de control inhibitorio (córtex prefrontal), creando una vulnerabilidad intrínseca hacia conductas de riesgo.

Históricamente, el consumo de tabaco y alcohol se consideraba un rito de transición social. No obstante, la investigación neurobiológica moderna ha redefinido estas sustancias como potentes disruptores del desarrollo ontogénico. La exposición temprana no solo compromete la salud física, sino que altera la trayectoria del desarrollo cerebral, limitando el potencial cognitivo y emocional del individuo a largo plazo.

## 3. Análisis en Profundidad

### 3.1. Impacto del Alcohol en el Sistema Nervioso Central
El etanol es una molécula pequeña que atraviesa fácilmente la barrera hematoencefálica. En menores de edad, sus efectos son particularmente deletéreos debido a la inmadurez de los mecanismos metabólicos y de neurotransmisión.
- **Disfunción del Córtex Prefrontal:** Responsable de las funciones ejecutivas (toma de decisiones, control de impulsos, planificación). El consumo de alcohol reduce la densidad de espinas dendríticas en esta región, lo que se traduce en una menor capacidad de autorregulación y un aumento de comportamientos impulsivos.
- **Alteración del Hipocampo:** Estructura crítica para la memoria y el aprendizaje. El consumo episódico intenso (binge drinking) se asocia con la muerte neuronal apoptótica en el hipocampo, resultando en déficits de memoria verbal y espacial.
- **Modulación de Neurotransmisores:** El alcohol potencia la actividad inhibitoria del ácido gamma-aminobutírico (GABA) e inhibe la actividad excitatoria del receptor N-metil-D-aspartato (NMDA). La exposición crónica provoca una neuroadaptación que, durante el retiro, induce hiperexcitabilidad neuronal y daño excitotóxico.

### 3.2. Efectos de la Nicotina y los Sistemas de Recompensa
La nicotina actúa como un agonista de los receptores nicotínicos de acetilcolina (nAChR), los cuales están ampliamente distribuidos en el cerebro adolescente.
- **Secuestro del Sistema de Dopamina:** La activación de los nAChR en el área tegmental ventral provoca la liberación de dopamina en el núcleo accumbens, consolidando el valor de refuerzo de la sustancia y facilitando el desarrollo rápido de la dependencia.
- **Deterioro de la Atención y Plasticidad:** La exposición a la nicotina durante la adolescencia altera los mecanismos de plasticidad dependiente del tiempo de espiga (STDP), perjudicando la atención sostenida, la memoria de trabajo y la flexibilidad cognitiva de manera irreversible.
- **Vapeo y Nuevos Dispositivos:** El auge de los sistemas electrónicos de administración de nicotina (SEAN) ha normalizado el consumo de concentrados de nicotina, exacerbando los riesgos de toxicidad aguda y dependencia severa en poblaciones aún más jóvenes.

### 3.3. Consecuencias Fisiológicas Sistémicas
Además del impacto neurológico, el consumo de estas sustancias compromete el desarrollo somático general:
- **Salud Pulmonar y Cardiovascular (Tabaco):** Reducción del crecimiento de la función pulmonar, aumento del riesgo de asma, rigidez arterial temprana y disfunción endotelial, predisponiendo a patologías cardiovasculares precoces.
- **Disfunción Endocrina y Hepática (Alcohol):** Alteración en la secreción de hormonas del crecimiento y del eje hipotalámico-gonadal, retrasando la maduración sexual o alterando los ciclos reproductivos. Asimismo, el hígado en desarrollo enfrenta un riesgo incrementado de esteatosis hepática no alcohólica y daño metabólico crónico.

## 4. Tabla Comparativa o Métricas Clave

| Parámetro de Impacto | Alcohol (Efectos en Menores) | Tabaco / Nicotina (Efectos en Menores) |
| :--- | :--- | :--- |
| **Órgano Diana Principal** | Córtex Prefrontal e Hipocampo | Sistema Dopaminérgico y Pulmones |
| **Mecanismo Neurobiológico** | Modulación GABA/NMDA, Apoptosis neuronal | Activación de Receptores nAChR, Liberación dopaminérgica |
| **Consecuencia Cognitiva Inmediata** | Fallos en toma de decisiones, amnesia retrógrada | Disminución de la atención y control impulsivo |
| **Déficit Neurobiológico a Largo Plazo** | Reducción de volumen cerebral (sustancia gris y blanca) | Alteración permanente de la plasticidad sináptica |
| **Impacto Fisiológico Sistémico** | Disrupción endocrina y daño hepático incipiente | Disminución de capacidad vital, rigidez arterial |
| **Riesgo de Dependencia** | Alto (se manifiesta tras años o meses de consumo) | Extremo (se manifiesta en semanas tras el inicio) |

## 5. Riesgos, Oportunidades e Impacto

### Riesgos
- **Co-consumo (Efecto Sinérgico):** El uso concurrente de tabaco y alcohol multiplica exponencialmente el daño cognitivo, incrementando la vulnerabilidad a otras adicciones y a trastornos psicopatológicos comórbidos, como la depresión mayor y la ansiedad generalizada.
- **Normalización Social y Barreras de Acceso:** La aparente benignidad atribuida al consumo social oculta la real naturaleza neurotóxica de estas sustancias. La permisividad del entorno facilita la iniciación a edades cada vez más tempranas.

### Oportunidades e Impacto
- **Ventana de Plasticidad Cerebral:** La alta plasticidad del cerebro adolescente implica que, ante el cese temprano del consumo, existen mecanismos de recuperación funcional y compensación sináptica.
- **Eficacia de las Intervenciones Basadas en la Escuela:** La implementación de programas de alfabetización neurocientífica y resiliencia emocional ha demostrado reducir significativamente las tasas de experimentación.

## 6. Recomendaciones Tácticas y Próximos Pasos

1. **Implementación de Programas de Educación Neurocientífica Temprana:** Integrar en los currículos escolares información basada en evidencia sobre los efectos reales de las sustancias en el desarrollo cerebral, enfocándose en la vulnerabilidad biológica y no solo en los daños orgánicos post-facto.
2. **Restricción Estricta y Regulación de Nuevos Dispositivos:** Aplicar políticas fiscales y regulatorias severas que restrinjan el acceso a dispositivos de vapeo y bebidas alcohólicas saborizadas, cuyos formatos suelen dirigirse a demografías menores de edad.
3. **Optimización de Protocolos Clínicos de Detección Precoz:** Capacitar a pediatras y profesionales de la atención primaria para realizar cribados longitudinales sobre el consumo de sustancias, utilizando herramientas validadas y escalas de riesgo adaptadas a la etapa evolutiva.
4. **Fomento de Entornos de Soporte Psicosocial:** Desarrollar intervenciones multicomponente que involucren activamente a las familias, fortaleciendo la supervisión parental y promoviendo el desarrollo de habilidades de autorregulación emocional en los menores.

## 7. Conclusión Final y Referencias
La evidencia analizada es contundente: el tabaco y el alcohol actúan como agentes disruptores de la ontogenia cerebral y somática en menores de edad. Los efectos no se limitan a riesgos comportamentales inmediatos, sino que alteran fundamentalmente las trayectorias de desarrollo neurológico, con impacto en la función cognitiva, la salud mental y la homeostasis metabólica. La respuesta institucional y de salud pública debe evolucionar desde enfoques punitivos hacia estrategias de protección neurobiológica, priorizando la prevención primaria mediante la comprensión científica de los riesgos.

**Referencias Seleccionadas:**
- American Academy of Pediatrics (AAP). (2020). *Committee on Substance Use and Prevention Policy statements on alcohol and nicotine*.
- Chassin, L., & Ritter, J. (2021). Vulnerability to Substance Use Disorders in Adolescence: A Neurodevelopmental Perspective. *Psychological Bulletin*, 147(6).
- Squeglia, L. M., Adinoff, B., & Gray, K. M. (2020). Alcohol and the Adolescent Brain: Reversibility of Brain Changes Across Recovery. *Alcoholism: Clinical and Experimental Research*, 44(8).
- Volkow, N. D., Baler, R. D., Goldstein, R. Z., & Fowler, J. S. (2019). Addiction circuitry of the adolescent brain. *Neuropharmacology*, 151.