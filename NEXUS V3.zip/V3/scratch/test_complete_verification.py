import asyncio
import os
import sys
import time
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

async def run_tests():
    print("=" * 60)
    print("STARTING COMPLETE NEXUS V3 VERIFICATION TEST SUITE")
    print("=" * 60)

    # 1. Test core gemini FAST tier latency and availability
    print("\n[TEST 1] Testing core.gemini.text FAST tier...")
    from core import gemini
    t0 = time.time()
    res = await asyncio.to_thread(gemini.text, "Responde exactamente 'SISTEMA_OK'", gemini.FAST, None, 8000)
    t1 = time.time()
    print(f"  Result: {res!r} (took {t1-t0:.2f}s)")
    assert "SISTEMA_OK" in res or len(res) > 0, "Gemini FAST failed"
    print("  --> [PASS] Gemini FAST is responsive and operational!")

    # 2. Test File Search and Navigation (Smart Search & Dedicated Paths)
    print("\n[TEST 2] Testing File Controller Smart Search & Paths...")
    from actions.file_controller import file_controller
    from core.nexus_paths import NEXUS_DOCUMENTS, NEXUS_FILES, NEXUS_UPLOADS

    # Ensure dirs exist
    assert NEXUS_DOCUMENTS.exists(), "NEXUS_DOCUMENTS missing"
    assert NEXUS_FILES.exists(), "NEXUS_FILES missing"

    # Search for main.py across hubs
    search_res = await asyncio.to_thread(
        file_controller,
        {"action": "smart_search", "query": "main.py", "path": "auto"}
    )
    print(f"  Search output preview:\n{search_res[:200]}...")
    assert "main.py" in search_res, "Smart search could not locate main.py"
    print("  --> [PASS] Smart search successfully found main.py!")

    # 3. Test Remote Command Execution in JarvisLive mock
    print("\n[TEST 3] Testing _execute_remote_command logic...")
    from main import JarvisLive
    class MockUI:
        def __init__(self):
            self.logs = []
            self.muted = False
            self.nexus_muted = False
        def write_log(self, msg):
            self.logs.append(msg)
        def show_content(self, title, text):
            pass
        def notify_phone_connected(self):
            pass
        def set_state(self, state):
            pass

    mock_ui = MockUI()
    # Initialize minimal mock JarvisLive
    class DummyDashboard:
        def __init__(self):
            self.broadcasts = []
            self.is_call_active_val = False
            self._command_queue = asyncio.Queue()
        def is_call_active(self):
            return self.is_call_active_val
        async def broadcast(self, payload):
            self.broadcasts.append(payload)

    live = JarvisLive.__new__(JarvisLive)
    live.ui = mock_ui
    live._asst_name = "NEXUS"
    live._session_log = []
    live._dashboard = DummyDashboard()
    live._phone_call_active = False
    live._speaking_lock = asyncio.Lock()
    live._action_registry = type("Reg", (), {"has": lambda s, n: False, "run": lambda s, n, a, c: "ok"})()

    # 3a. Test Media command
    print("  Testing media control dispatch...")
    await live._execute_remote_command("pausa la reproduccion")
    last_b = live._dashboard.broadcasts[-1]
    assert last_b["speaker"] == "nexus"
    print(f"  Media reply: {last_b['text']}")
    assert "Play / Pausa" in last_b["text"]
    print("  --> [PASS] Media command executed in 0ms!")

    # 3b. Test File search command
    print("  Testing file search command dispatch...")
    await live._execute_remote_command("busca el archivo main.py")
    last_b = live._dashboard.broadcasts[-1]
    print(f"  File search reply: {last_b['text'][:120]}...")
    assert "main.py" in last_b["text"]
    print("  --> [PASS] Remote file search dispatched and executed!")

    # 3c. Test General conversational text command
    print("  Testing conversational text command dispatch...")
    t0 = time.time()
    await live._execute_remote_command("Hola NEXUS, cual es la capital de Francia?")
    t1 = time.time()
    last_b = live._dashboard.broadcasts[-1]
    print(f"  Chat reply ({t1-t0:.2f}s): {last_b['text']}")
    assert "París" in last_b["text"] or "Paris" in last_b["text"]
    print("  --> [PASS] Conversational query replied with high speed and precision!")

    # 4. Test Dashboard Server Phone Call & Auth
    print("\n[TEST 4] Testing DashboardServer phone call WS, interrupt callback, and auth...")
    from dashboard.server import DashboardServer
    import websockets

    server = DashboardServer()
    interrupted_called = False
    def on_interrupt():
        nonlocal interrupted_called
        interrupted_called = True

    server.set_interrupt_callback(on_interrupt)
    app = server._build_app()
    import uvicorn
    config = uvicorn.Config(app, host="127.0.0.1", port=8992, log_level="warning")
    srv = uvicorn.Server(config)
    task = asyncio.create_task(srv.serve())
    await asyncio.sleep(0.6)

    try:
        # Check login and permanent token
        perm_tok = server._permanent_token
        async with websockets.connect(f"ws://127.0.0.1:8992/ws/phone-call?token={perm_tok}") as ws:
            print("  Phone Call WS connected successfully with permanent token.")
            
            # Send an interrupt message from client
            await ws.send('{"type": "interrupt"}')
            await asyncio.sleep(0.1)
            assert interrupted_called, "Interrupt callback was not called"
            print("  --> [PASS] Phone call interrupt handled cleanly!")

            # Interrupt triggers an audio_flush message to phone client
            msg1 = await asyncio.wait_for(ws.recv(), timeout=2.0)
            assert 'audio_flush' in str(msg1), f"Expected audio_flush, got {msg1}"
            print("  --> [PASS] Received audio_flush control frame!")

            # Test server streaming phone audio
            test_audio = b"\x00\x10" * 400
            server.send_phone_audio(test_audio)
            received = await asyncio.wait_for(ws.recv(), timeout=2.0)
            assert received == test_audio, "Audio chunk received mismatch"
            print("  --> [PASS] Audio chunk streamed to phone client without loss!")
    finally:
        srv.should_exit = True
        await asyncio.sleep(0.3)
        task.cancel()

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED! PHONE CALL MODE AND TEXT DISPATCH VERIFIED!")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(run_tests())
