import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

BASE = Path(__file__).resolve().parent.parent

def replace_in_file(rel_path: str, replacements: list[tuple[str, str]]):
    f = BASE / rel_path
    if not f.exists():
        print(f"Skipping {rel_path} (not found)")
        return
    text = f.read_text(encoding="utf-8")
    original = text
    for old, new in replacements:
        text = text.replace(old, new)
    if text != original:
        f.write_text(text, encoding="utf-8")
        print(f"✅ Updated {rel_path}")
    else:
        print(f"ℹ️ No changes in {rel_path}")

# 1. main.py
replace_in_file("main.py", [
    ("[JARVIS]", "[NEXUS]"),
    ("SYS: JARVIS online.", "SYS: N.E.X.U.S online."),
    ("SYS: JARVIS online - sleeping. Say 'Hey Jarvis' to wake me.", "SYS: N.E.X.U.S online - modo reposo."),
    ('"speaker": "jarvis"', '"speaker": "nexus"'),
    ("Select a file for JARVIS", "Select a file for NEXUS"),
])

# 2. ui.py
replace_in_file("ui.py", [
    ("Select a file for JARVIS", "Select a file for NEXUS"),
    ("MICROPHONE - what JARVIS hears you with", "MICROPHONE - what NEXUS hears you with"),
    ("SPEAKERS - what JARVIS talks through", "SPEAKERS - what NEXUS talks through"),
    ("??  WHAT JARVIS REMEMBERS", "⚡  WHAT NEXUS REMEMBERS"),
    ("WHAT JARVIS REMEMBERS", "WHAT NEXUS REMEMBERS"),
    ("Phone connected - JARVIS ready", "Phone connected - NEXUS ready"),
    ("shows what JARVIS is doing", "shows what NEXUS is doing"),
    ('"A Friendly Assistant"\n                     if _disp in ("JARVIS", "J.A.R.V.I.S)', '"Next-Gen Extended Utility System"\n                     if _disp in ("NEXUS", "N.E.X.U.S", "JARVIS", "J.A.R.V.I.S)'),
    ('if display in ("JARVIS", "J.A.R.V.I.S):\n            self._sub_lbl.setText("Just A Rather Very Intelligent System")', 'if display in ("NEXUS", "N.E.X.U.S"):\n            self._sub_lbl.setText("Next-Gen Extended Utility System")\n        elif display in ("JARVIS", "J.A.R.V.I.S"):\n            self._sub_lbl.setText("Just A Rather Very Intelligent System")'),
    ('"JARVIS_AI"', '"NEXUS_AI"'),
    ('"jarvis.desktop"', '"nexus.desktop"'),
    ('"com.jarvis.assistant.plist"', '"com.nexus.assistant.plist"'),
    ('"com.jarvis.assistant"', '"com.nexus.assistant"'),
])

# 3. actions/code_helper.py
replace_in_file("actions/code_helper.py", [
    ("jarvis_code", "nexus_code"),
    ("jarvis_screenshot.png", "nexus_screenshot.png"),
])

# 4. actions/browser_control.py
replace_in_file("actions/browser_control.py", [
    (".jarvis_profiles", ".nexus_profiles"),
    ("jarvis_profile", "nexus_profile"),
    ("jarvis_screenshot.png", "nexus_screenshot.png"),
    ("jarvis = str(Path.home() / \".jarvis_profiles\"", "nexus = str(Path.home() / \".nexus_profiles\""),
])

# 5. actions/flight_finder.py
replace_in_file("actions/flight_finder.py", [
    ("JARVIS - Flight Search Results", "NEXUS - Flight Search Results"),
])

# 6. actions/youtube_video.py
replace_in_file("actions/youtube_video.py", [
    ("JARVIS - YouTube Summary", "NEXUS - YouTube Summary"),
])

# 7. actions/dev_agent.py
replace_in_file("actions/dev_agent.py", [
    ("jarvis_projects", "nexus_projects"),
])

# 8. actions/reminder.py
replace_in_file("actions/reminder.py", [
    (".jarvis", ".nexus"),
    ("com.jarvis.reminder", "com.nexus.reminder"),
    ("JARVISReminder_", "NEXUSReminder_"),
])

# 9. actions/game_updater.py
replace_in_file("actions/game_updater.py", [
    ("JARVIS_GameUpdater", "NEXUS_GameUpdater"),
    ("com.jarvis.gameupdater", "com.nexus.gameupdater"),
])

# 10. dashboard/static/app.html
replace_in_file("dashboard/static/app.html", [
    ("<title>JARVIS Dashboard</title>", "<title>NEXUS Dashboard</title>"),
    ("placeholder=\"Message JARVIS...\"", "placeholder=\"Message NEXUS...\""),
    ("speaker === \"jarvis\"", "speaker === \"nexus\" || speaker === \"jarvis\""),
])

# 11. dashboard/static/login.html
replace_in_file("dashboard/static/login.html", [
    ("<title>JARVIS</title>", "<title>NEXUS</title>"),
    ("<p>Connecting to JARVIS...</p>", "<p>Connecting to NEXUS...</p>"),
])

# 12. dashboard/server.py
replace_in_file("dashboard/server.py", [
    ("Connecting to JARVIS...", "Connecting to NEXUS..."),
    ("JARVIS Dashboard", "NEXUS Dashboard"),
])

print("\n🎉 Rebranding to NEXUS completed successfully!")
