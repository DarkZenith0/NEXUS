import asyncio
import os
import sys
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

def test_gemini_work_tier():
    print("[TEST 1] Testing core.gemini tiers...")
    from core import gemini
    assert hasattr(gemini, "WORK"), "gemini.WORK missing"
    assert hasattr(gemini, "REASONING"), "gemini.REASONING missing"
    assert gemini._LADDERS[gemini.WORK] == ("gemini-2.5-pro", "gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.5-flash")
    print("  -> gemini.WORK model ladder verified:", gemini._LADDERS[gemini.WORK])

def test_work_agent_execution():
    print("[TEST 2] Testing actions.work_agent...")
    from actions import work_agent
    
    # Test work mode state toggle
    assert not work_agent.is_work_mode(), "Initial work mode should be False"
    work_agent.set_work_mode(True)
    assert work_agent.is_work_mode(), "Work mode should now be True"
    work_agent.set_work_mode(False)
    assert not work_agent.is_work_mode(), "Work mode should now be False"

    # Test create_report execution with mock prompt/topic
    print("  -> Generating test report via work_agent...")
    result = work_agent.work_agent_handler({
        "action": "create_report",
        "topic": "Resumen Ejecutivo de Arquitectura NEXUS V3",
        "requirements": "Explicar brevemente el modo trabajo y el modo llamada."
    })
    print("  -> Handler returned:", result[:150], "...")
    assert "Informe exhaustivo redactado con" in result or "Informe guardado" in result or "guardado las versiones completas" in result, f"Unexpected result: {result}"
    
    # Check that file was saved in Documents/NEXUS_Informes
    reports_dir = Path.home() / "Documents" / "NEXUS_Informes"
    assert reports_dir.exists(), "NEXUS_Informes directory was not created"
    md_files = list(reports_dir.glob("*.md"))
    docx_files = list(reports_dir.glob("*.docx"))
    print(f"  -> Found {len(md_files)} .md files and {len(docx_files)} .docx files in {reports_dir}")
    assert len(md_files) > 0, "No markdown file generated"
    assert len(docx_files) > 0, "No docx file generated"

def test_file_processor_action():
    print("[TEST 3] Testing actions.file_processor...")
    from actions import file_processor
    # Verify that file_processor module defines comprehensive_report handling
    code = Path(file_processor.__file__).read_text(encoding="utf-8")
    assert "comprehensive_report" in code, "comprehensive_report missing from file_processor.py"
    assert "gemini.WORK" in code, "gemini.WORK tier missing from file_processor.py"
    print("  -> comprehensive_report and gemini.WORK verified in file_processor")

def test_dashboard_api_and_ws():
    print("[TEST 4] Testing dashboard server mode endpoints...")
    from dashboard import server
    srv = server.DashboardServer()
    # Check that new endpoints and methods exist
    assert hasattr(srv, "send_phone_audio"), "send_phone_audio missing on DashboardServer"
    assert hasattr(srv, "broadcast_document"), "broadcast_document missing on DashboardServer"
    assert hasattr(srv, "_phone_call_clients"), "_phone_call_clients missing on DashboardServer"
    print("  -> DashboardServer phone audio & document broadcast verified")

if __name__ == "__main__":
    test_gemini_work_tier()
    test_work_agent_execution()
    test_file_processor_action()
    test_dashboard_api_and_ws()
    print("\n[SUCCESS] ALL TESTS PASSED SUCCESSFULLY!")
