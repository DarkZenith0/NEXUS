"""
Comprehensive validation suite for NEXUS V2 UI Redesign, VAD, and Mini-Player.
Runs headlessly and verifies all components, design tokens, and state transitions.
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

# Ensure offscreen Qt platform for reliable test execution
os.environ["QT_QPA_PLATFORM"] = "offscreen"

# Add V2 to sys.path
V2_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(V2_DIR))

import numpy as np
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QPainter, QPixmap
from PyQt6.QtCore import Qt

from core.vad import VoiceActivityDetector, VADEvent
import ui
from ui import (
    C, MetricBar, LogWidget, FileDropZone, _DropCanvas,
    MiniPlayerOverlay, MainWindow,
)


def run_tests():
    print("============================================================")
    print("TEST 1: Design Tokens & Palette Verification")
    print("============================================================")
    assert C.BG == "#0c0e14", f"Unexpected BG: {C.BG}"
    assert C.PRI == "#ff2e4d", f"Unexpected PRI: {C.PRI}"
    assert C.TEXT == "#f8fafc", f"Unexpected TEXT: {C.TEXT}"
    assert C.TEXT_MED == "#94a3b8", f"Unexpected TEXT_MED: {C.TEXT_MED}"
    assert C.TEXT_DIM == "#64748b", f"Unexpected TEXT_DIM: {C.TEXT_DIM}"
    assert C.GREEN == "#10b981", f"Unexpected GREEN: {C.GREEN}"
    assert C.RED == "#ef4444", f"Unexpected RED: {C.RED}"
    
    # Calculate simple luminosity contrast ratio (WCAG compliance)
    def rel_lum(hex_col):
        r, g, b = [int(hex_col[i:i+2], 16) / 255.0 for i in (1, 3, 5)]
        def f(c): return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
        return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)

    bg_l = rel_lum(C.BG)
    text_l = rel_lum(C.TEXT)
    contrast_ratio = (text_l + 0.05) / (bg_l + 0.05)
    print(f"Primary Text Contrast Ratio: {contrast_ratio:.2f}:1 (WCAG AA requires >= 4.5:1)")
    assert contrast_ratio >= 10.0, "Contrast ratio between text and background is below SaaS standards!"
    print("[OK] Design tokens and WCAG contrast verified!")

    print("\n============================================================")
    print("TEST 2: Voice Activity Detector (VAD) Speech & Silence Timing")
    print("============================================================")
    vad = VoiceActivityDetector(sample_rate=16000, chunk_size=320, min_speech_ms=240, silence_timeout_ms=650)
    
    # Send 10 chunks of silence (200ms)
    silence_chunk = np.zeros(320, dtype=np.int16).tobytes()
    for _ in range(10):
        res = vad.process(silence_chunk)
        assert res.event == VADEvent.SILENCE
        assert res.audio_chunk is None

    # Send 15 chunks of speech (300ms > 240ms threshold)
    t = np.linspace(0, 0.02, 320, endpoint=False)
    tone_pcm = (np.sin(2 * np.pi * 440 * t) * 12000).astype(np.int16).tobytes()
    speech_started = False
    for i in range(15):
        res = vad.process(tone_pcm)
        if res.event == VADEvent.SPEECH_START:
            speech_started = True
            assert res.audio_chunk is not None, "Pre-roll frames must be included on speech start!"

    assert speech_started, "VAD failed to detect speech start after 300ms of sustained tone!"
    assert vad.is_speaking, "VAD state should be speaking!"

    # Send silence until silence_timeout (650ms / 20ms = ~33 chunks)
    speech_ended = False
    for i in range(40):
        res = vad.process(silence_chunk)
        if res.event == VADEvent.SPEECH_END:
            speech_ended = True
            break

    assert speech_ended, "VAD failed to detect speech end after 650ms of silence!"
    assert not vad.is_speaking, "VAD state should be idle after speech end!"

    # Test transient noise discard (cough / click: 3 chunks = 60ms < 240ms)
    vad.reset()
    for _ in range(3):
        res = vad.process(tone_pcm)
        assert res.event == VADEvent.SILENCE, "Short click (<240ms) should not trigger SPEECH_START!"

    for _ in range(10):
        res = vad.process(silence_chunk)
    assert not vad.is_speaking, "VAD correctly discarded transient noise!"
    print("[OK] VAD real-time speech/silence detection verified!")

    print("\n============================================================")
    print("TEST 3: Qt Widgets & Paint Events")
    print("============================================================")
    app = QApplication.instance() or QApplication(sys.argv)

    # Test MetricBar
    m_bar = MetricBar("CPU", C.PRI)
    m_bar.resize(140, 38)
    for v in [10.0, 25.0, 50.0, 75.0, 42.0]:
        m_bar.set_value(v, f"{v:.0f}%")
    pm = QPixmap(140, 38)
    pm.fill(Qt.GlobalColor.black)
    p = QPainter(pm)
    m_bar.paintEvent(None)
    p.end()
    assert m_bar._value == 42.0
    print("[OK] MetricBar rendering and sparkline logic verified!")

    # Test LogWidget
    log = LogWidget()
    log.append_log("You: Hola NEXUS")
    log.append_log("NEXUS: Hola, ¿en qué puedo ayudarte hoy?")
    log.append_log("SYS: Sistema activo")
    assert len(log._queue) > 0 or log._typing
    print("[OK] LogWidget queueing and semantic tag parser verified!")

    # Test FileDropZone & _DropCanvas
    drop_zone = FileDropZone()
    drop_zone.resize(320, 100)
    canvas = drop_zone._canvas
    canvas.resize(320, 100)
    pm_drop = QPixmap(320, 100)
    p_drop = QPainter(pm_drop)
    canvas.paintEvent(None)
    p_drop.end()
    print("[OK] FileDropZone & _DropCanvas rendering verified!")

    print("\n============================================================")
    print("TEST 4: MiniPlayerOverlay (Floating Capsule)")
    print("============================================================")
    mini = MiniPlayerOverlay(assistant_name="NEXUS")
    assert mini.width() == MiniPlayerOverlay._EXP_W
    assert mini.height() == MiniPlayerOverlay._EXP_H

    # Test states
    mini.set_state("LISTENING")
    assert mini._state == "LISTENING"
    mini.set_state("THINKING")
    assert mini._state == "THINKING"
    mini.set_state("SPEAKING")
    assert mini._state == "SPEAKING"

    # Test text updates
    mini.set_subtitle("Probando texto largo que debe elidirse correctamente sin desbordar los límites del widget.")
    
    # Test collapse mode
    mini.set_collapsed(True)
    assert mini.is_collapsed()
    assert mini.width() == MiniPlayerOverlay._COL_W
    assert mini.height() == MiniPlayerOverlay._COL_H

    # Test expand mode
    mini.set_collapsed(False)
    assert not mini.is_collapsed()
    assert mini.width() == MiniPlayerOverlay._EXP_W

    # Paint event verification
    pm_mini = QPixmap(mini.width(), mini.height())
    p_mini = QPainter(pm_mini)
    mini.paintEvent(None)
    p_mini.end()
    print("[OK] MiniPlayerOverlay capsule states, collapse/expand, and painting verified!")

    print("\n============================================================")
    print("TEST 5: MainWindow Layout & Mode Transition")
    print("============================================================")
    win = MainWindow(face_path="")
    assert win._title_lbl.text() == "NEXUS"
    assert win._mini_btn is not None
    assert win._drawer_btn is not None
    assert win._state_badge is not None

    # Test state badge dynamic transitions
    assert "LISTO" in win._state_badge.text()
    win._apply_state("LISTENING")
    assert "ESCUCHANDO" in win._state_badge.text()
    win._apply_state("THINKING")
    assert "PENSANDO" in win._state_badge.text()
    win._apply_state("SPEAKING")
    assert "RESPONDIENDO" in win._state_badge.text()
    win._apply_state("MUTED")
    assert "SILENCIADO" in win._state_badge.text()
    win._apply_state("IDLE")
    assert "LISTO" in win._state_badge.text()
    print("[OK] MainWindow state badge dynamic updates verified!")

    # Toggle Mini-Mode transition
    win.show()
    win.toggle_mini_mode()
    assert win._is_mini_mode is True
    assert win.isHidden() or not win.isVisible()

    # Restore from Mini-Mode
    win.toggle_mini_mode()
    assert win._is_mini_mode is False
    assert win.isVisible()

    # Test drawer toggle
    win._toggle_drawer(True)
    assert win._quick_drawer.isVisible()
    win._toggle_drawer(False)
    assert not win._quick_drawer.isVisible()

    win.close()
    print("[OK] MainWindow layout, drawer, and mini-mode round-trip verified!")

    print("\n************************************************************")
    print("ALL REDESIGN, VAD, AND MINI-PLAYER VALIDATION TESTS PASSED 100%!")
    print("************************************************************")


if __name__ == "__main__":
    run_tests()
