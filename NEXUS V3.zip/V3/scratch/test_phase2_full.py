import io
import json
import os
import sys
import time
from pathlib import Path
import numpy as np

# Ensure project root is on sys.path
base_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(base_dir))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import cv2
from PIL import Image, ImageDraw, ImageFont

def test_rapid_ocr_synthetic():
    print("\n" + "=" * 60)
    print("TEST 1: RapidOCR Local on Synthetic High-Res UI Canvas")
    print("=" * 60)
    
    from actions.computer_control import _ocr_find, _get_ocr_engine
    
    engine = _get_ocr_engine()
    assert engine is not None, "RapidOCR engine failed to initialize!"
    print("✅ RapidOCR engine initialized successfully.")
    
    # Create a 1920x1080 synthetic screen canvas simulating an app UI
    canvas = np.full((1080, 1920, 3), 245, dtype=np.uint8) # light gray background
    
    # Button 1: "Guardar Cambios" at (300, 200) to (500, 250) -> center (400, 225)
    cv2.rectangle(canvas, (300, 200), (520, 250), (60, 120, 216), -1) # blue button
    cv2.putText(canvas, "Guardar Cambios", (315, 235), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 255), 2)
    
    # Button 2: "Descargas" at (800, 500) to (980, 550) -> center (890, 525)
    cv2.rectangle(canvas, (800, 500), (980, 550), (40, 180, 80), -1) # green button
    cv2.putText(canvas, "Descargas", (820, 535), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    # Button 3: "Aceptar" at (1200, 700) to (1350, 750) -> center (1275, 725)
    cv2.rectangle(canvas, (1200, 700), (1350, 750), (70, 70, 70), -1)
    cv2.putText(canvas, "Aceptar", (1225, 735), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    
    # Target monitor mock (left=0, top=0, width=1920, height=1080)
    mon = {"left": 0, "top": 0, "width": 1920, "height": 1080}
    
    # Query 1: Exact / Multi-word Spanish natural language
    queries = [
        ("haz clic en el boton Guardar Cambios", (400, 225), 60),
        ("pulsa en descargas", (890, 525), 60),
        ("selecciona aceptar", (1275, 725), 60),
    ]
    
    for query, expected_center, tolerance in queries:
        t0 = time.time()
        coords = _ocr_find(query, canvas, mon)
        elapsed = (time.time() - t0) * 1000
        print(f"Query: '{query}' -> Found at {coords} in {elapsed:.1f}ms")
        assert coords is not None, f"Failed to find element for query: '{query}'"
        dx = abs(coords[0] - expected_center[0])
        dy = abs(coords[1] - expected_center[1])
        assert dx <= tolerance and dy <= tolerance, f"Coordinates {coords} deviated too far from {expected_center} (dx={dx}, dy={dy})"
        print(f"  -> Accuracy: delta_x={dx}px, delta_y={dy}px (within {tolerance}px tolerance)")
        
    print("✅ All RapidOCR test queries passed with high precision!")

def test_opencv_icon_detection():
    print("\n" + "=" * 60)
    print("TEST 2: OpenCV Icon & Template Matching Detector")
    print("=" * 60)
    
    from actions.computer_control import _opencv_icon_find
    
    # Create canvas with drawn icons
    canvas = np.full((600, 800, 3), 240, dtype=np.uint8)
    
    # Draw Search icon (magnifying glass) at (200, 150)
    cv2.circle(canvas, (200, 150), 12, (20, 20, 20), 2)
    cv2.line(canvas, (208, 158), (222, 172), (20, 20, 20), 3)
    
    # Draw Add icon (+) at (400, 150)
    cv2.line(canvas, (400, 140), (400, 160), (20, 20, 20), 3)
    cv2.line(canvas, (390, 150), (410, 150), (20, 20, 20), 3)
    
    # Draw Play icon (triangle) at (600, 150)
    pts = np.array([[592, 138], [612, 150], [592, 162]], np.int32)
    cv2.fillPoly(canvas, [pts], (20, 20, 20))
    
    mon = {"left": 0, "top": 0, "width": 800, "height": 600}
    
    icon_tests = [
        ("haz click en la lupa de buscar", (200, 150), 30),
        ("añadir nuevo elemento", (400, 150), 30),
        ("darle al play", (600, 150), 30),
    ]
    
    for query, expected_center, tolerance in icon_tests:
        coords = _opencv_icon_find(query, canvas, mon)
        print(f"Icon Query: '{query}' -> Found at {coords}")
        assert coords is not None, f"Failed to find icon for query: '{query}'"
        dx = abs(coords[0] - expected_center[0])
        dy = abs(coords[1] - expected_center[1])
        assert dx <= tolerance and dy <= tolerance, f"Coordinates {coords} deviated from {expected_center}"
        print(f"  -> Accuracy: delta_x={dx}px, delta_y={dy}px (within {tolerance}px tolerance)")
        
    print("✅ All OpenCV icon matching tests passed!")

def test_browser_dom_delegation():
    print("\n" + "=" * 60)
    print("TEST 3: Browser DOM Delegation Hook")
    print("=" * 60)
    
    from actions.computer_control import _try_browser_dom_click
    
    # When no browser is open, it must return None cleanly without exceptions
    res = _try_browser_dom_click("botón de login")
    print("Browser DOM delegation when inactive:", res)
    assert res is None, "Expected None when browser session is inactive"
    print("✅ Browser DOM delegation inactive fallback verified!")

def test_nexus_hud_exclusion():
    print("\n" + "=" * 60)
    print("TEST 4: NEXUS HUD Self-Click Exclusion")
    print("=" * 60)
    
    import actions.computer_control as cc
    
    # Mock NEXUS window rect to (100, 100, 500, 500)
    orig_get_rect = cc._get_nexus_window_rect
    cc._get_nexus_window_rect = lambda: (100, 100, 500, 500)
    
    try:
        assert cc._is_inside_nexus(300, 300) == True, "Point inside HUD was not detected as inside!"
        assert cc._is_inside_nexus(50, 50) == False, "Point outside HUD was falsely detected as inside!"
        assert cc._is_inside_nexus(600, 300) == False, "Point outside HUD was falsely detected as inside!"
        print("✅ NEXUS HUD exclusion boundary filter verified!")
    finally:
        cc._get_nexus_window_rect = orig_get_rect

def test_full_action_runner():
    print("\n" + "=" * 60)
    print("TEST 5: Full Action Runner & Chaining")
    print("=" * 60)
    
    from core.action_loader import discover_actions
    reg = discover_actions(base_dir / "actions")
    
    assert reg.has("computer_control"), "computer_control tool not found"
    assert reg.has("macro_runner"), "macro_runner tool not found"
    
    # Test dispatching a chained macro through macro_runner
    test_macro = {
        "action": "save_macro",
        "macro_name": "test_chain_macro",
        "description": "Macro de prueba encadenada",
        "steps": [
            {"tool": "computer_control", "action": "wait", "seconds": 0.05},
            {"tool": "computer_control", "action": "wait", "seconds": 0.05}
        ]
    }
    save_res = reg.run("macro_runner", test_macro, {})
    assert "guardada correctamente" in save_res
    print("Save macro:", save_res)
    
    run_res = reg.run("macro_runner", {"action": "run_macro", "macro_name": "test_chain_macro"}, {})
    assert "completada con éxito" in run_res
    print("Run macro:", run_res)
    
    # Cleanup
    macros_file = base_dir / "config" / "macros.json"
    data = json.loads(macros_file.read_text(encoding="utf-8"))
    if "test_chain_macro" in data:
        del data["test_chain_macro"]
        macros_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print("✅ Macro Runner & action chaining verified!")

def test_module_imports_sanity():
    print("\n" + "=" * 60)
    print("TEST 6: Sanity Check on Core Codebase")
    print("=" * 60)
    
    # Verify main core modules import cleanly
    import core.action_loader
    import core.gemini
    import core.voice_engine
    import memory.config_manager
    from memory.config_manager import get_assistant_name
    
    name = get_assistant_name()
    print(f"Assistant Name from config: '{name}'")
    assert name == "NEXUS", f"Expected 'NEXUS', got '{name}'"
    
    print("✅ All core modules imported and assistant name verified as NEXUS!")

if __name__ == "__main__":
    test_rapid_ocr_synthetic()
    test_opencv_icon_detection()
    test_browser_dom_delegation()
    test_nexus_hud_exclusion()
    test_full_action_runner()
    test_module_imports_sanity()
    print("\n" + "🎉" * 20)
    print("ALL 6 TESTS PASSED WITH 100% SUCCESS!")
    print("🎉" * 20)
