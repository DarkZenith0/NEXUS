import asyncio
import os
import sys
import time
from pathlib import Path

# Ensure project root is in sys.path
base_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(base_dir))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def test_atomic_writes():
    print("\n" + "=" * 60)
    print("TEST 1: Atomic File Writes (Config, Memory, Macros)")
    print("=" * 60)

    from memory.config_manager import load_api_keys, _write_config_data, CONFIG_FILE
    from memory.memory_manager import load_memory, save_memory, MEMORY_PATH
    from actions.macro_runner import _load_macros, _save_macros, _MACROS_FILE

    # 1. Config Manager Atomic Write
    cfg = load_api_keys()
    cfg["_test_atomic_key"] = "test_val_123"
    _write_config_data(cfg)
    reloaded_cfg = load_api_keys()
    assert reloaded_cfg.get("_test_atomic_key") == "test_val_123", "Config atomic write failed"
    # Clean up test key
    del cfg["_test_atomic_key"]
    _write_config_data(cfg)
    print("✅ config_manager atomic write & reload verified.")

    # 2. Memory Manager Atomic Write
    mem = load_memory()
    mem.setdefault("notes", {})["_test_atomic_note"] = {"value": "atomic_verified", "updated": "2026-09-24"}
    save_memory(mem)
    reloaded_mem = load_memory()
    assert reloaded_mem.get("notes", {}).get("_test_atomic_note", {}).get("value") == "atomic_verified"
    del mem["notes"]["_test_atomic_note"]
    save_memory(mem)
    print("✅ memory_manager atomic write & reload verified.")

    # 3. Macro Runner Atomic Write
    macros = _load_macros()
    macros["_test_atomic_macro"] = {"nombre": "Test Atomic", "pasos": []}
    assert _save_macros(macros) == True
    reloaded_macros = _load_macros()
    assert "_test_atomic_macro" in reloaded_macros
    del macros["_test_atomic_macro"]
    _save_macros(macros)
    print("✅ macro_runner atomic write & reload verified.")


def test_qt_thread_safety():
    print("\n" + "=" * 60)
    print("TEST 2: Qt Thread-Safety (_phone_connected_sig)")
    print("=" * 60)

    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtCore import pyqtSignal
    import ui

    # Verify signal definition in class
    assert hasattr(ui.MainWindow, "_phone_connected_sig"), "MainWindow missing _phone_connected_sig"
    assert hasattr(ui.MainWindow, "_on_phone_connected_ui"), "MainWindow missing _on_phone_connected_ui"
    print("✅ MainWindow._phone_connected_sig properly defined and registered.")


def test_desktop_sandbox_hardening():
    print("\n" + "=" * 60)
    print("TEST 3: Desktop Sandbox Hardening (ctypes neutralized)")
    print("=" * 60)

    from actions.desktop import _build_sandbox, _execute_generated_code

    sandbox = _build_sandbox()
    assert "ctypes" not in sandbox, "ctypes MUST NOT be present in desktop sandbox!"
    print("✅ ctypes verified absent from sandbox globals.")

    # Attempt execution of code trying to use ctypes
    malicious_code = "ctypes.CDLL(None)"
    res = _execute_generated_code(malicious_code)
    print(f"Malicious ctypes execution result: {res}")
    assert "name 'ctypes' is not defined" in res, "Sandbox allowed undefined ctypes!"
    print("✅ Malicious ctypes execution safely blocked!")


def test_computer_control_focus_window():
    print("\n" + "=" * 60)
    print("TEST 4: Computer Control _focus_window Sanitization")
    print("=" * 60)

    from actions.computer_control import _focus_window

    # Test with malicious quote characters
    test_titles = [
        'NonExistentApp" && whoami',
        "Test'Window`$Env:UserName",
        'RegularTestWindow',
    ]

    for title in test_titles:
        res = _focus_window(title)
        print(f"_focus_window('{title}') -> {res}")
        # Must not raise an unhandled exception or crash
        assert isinstance(res, str)
    print("✅ _focus_window properly handles special characters without command injection!")


def test_language_fallbacks():
    print("\n" + "=" * 60)
    print("TEST 5: Language Consistency (100% Spanish Rule)")
    print("=" * 60)

    main_py_text = (base_dir / "main.py").read_text(encoding="utf-8")
    assert 'lang = lang or "English"' not in main_py_text, "Found legacy English fallback in session summary!"
    assert 'or "English"' not in main_py_text, "Found legacy English fallback in main.py!"
    assert 'lang = lang or "Español"' in main_py_text, "Español fallback missing in session summary!"
    print("✅ 100% Spanish language fallback verified in main.py!")


def test_multi_drive_support():
    print("\n" + "=" * 60)
    print("TEST 6: Multi-drive & Safe Path Support")
    print("=" * 60)

    from actions.file_controller import _get_safe_roots, _is_safe_path

    roots = _get_safe_roots()
    print(f"Detected safe roots: {[str(r) for r in roots]}")
    assert len(roots) >= 1, "At least home directory must be safe"

    # Home path must be safe
    assert _is_safe_path(Path.home() / "Desktop"), "Home desktop not detected as safe!"
    assert _is_safe_path(Path.home() / "Downloads"), "Home downloads not detected as safe!"

    # Windows system drive should be safe
    c_drive = Path("C:/")
    if c_drive.exists():
        assert _is_safe_path(Path("C:/Users")), "C:/Users path must be safe!"

    print("✅ Multi-drive safe path detection verified!")


def test_edge_tts_async_synthesis():
    print("\n" + "=" * 60)
    print("TEST 7: Edge-TTS Native Async Synthesis")
    print("=" * 60)

    from core.voice_engine import EdgeTTSClient

    client = EdgeTTSClient(voice="es-ES-AlvaroNeural")

    async def _test():
        raw_pcm = await client.synthesize_raw_pcm_async("Prueba de sintetizador asíncrono.")
        return raw_pcm

    t0 = time.time()
    pcm = asyncio.run(_test())
    elapsed = (time.time() - t0) * 1000
    print(f"Edge-TTS synthesized {len(pcm)} bytes in {elapsed:.1f}ms")
    assert len(pcm) > 0, "Edge-TTS produced 0 bytes!"
    # 24000 Hz, 16-bit mono = 48000 bytes per second
    duration_sec = len(pcm) / 48000.0
    print(f"Audio duration: {duration_sec:.2f}s")
    assert duration_sec > 0.5, "Synthesized audio duration too short!"
    print("✅ Edge-TTS native async synthesis verified!")


def test_windows_app_launcher():
    print("\n" + "=" * 60)
    print("TEST 8: Fast Windows App Resolver & Registry Lookup")
    print("=" * 60)

    from actions.open_app import _find_app_in_windows_registry

    chrome_path = _find_app_in_windows_registry("chrome")
    edge_path = _find_app_in_windows_registry("msedge")
    notepad_path = _find_app_in_windows_registry("notepad")

    print(f"Chrome registry path: {chrome_path}")
    print(f"Edge registry path:   {edge_path}")
    print(f"Notepad registry path:{notepad_path}")

    # At least one standard browser/editor should be in Windows App Paths
    found_any = any([chrome_path, edge_path, notepad_path])
    assert found_any, "Expected at least one standard Windows app in App Paths!"
    print("✅ Windows App Paths registry resolution verified!")


def test_dashboard_uploads_rebranding():
    print("\n" + "=" * 60)
    print("TEST 9: Dashboard Uploads Rebranding")
    print("=" * 60)

    from dashboard.server import _make_uploads_dir

    uploads_dir = _make_uploads_dir()
    print(f"Resolved uploads directory: {uploads_dir}")
    assert uploads_dir.exists(), "Uploads directory must exist"
    assert "NEXUS Uploads" in str(uploads_dir) or "uploads" in str(uploads_dir) or "JARVIS Uploads" in str(uploads_dir)
    print("✅ Dashboard uploads branding verified!")


if __name__ == "__main__":
    t_start = time.time()
    test_atomic_writes()
    test_qt_thread_safety()
    test_desktop_sandbox_hardening()
    test_computer_control_focus_window()
    test_language_fallbacks()
    test_multi_drive_support()
    test_edge_tts_async_synthesis()
    test_windows_app_launcher()
    test_dashboard_uploads_rebranding()
    total_time = time.time() - t_start

    print("\n" + "🌟" * 30)
    print(f"ALL 9 SYSTEM IMPROVEMENT TESTS PASSED 100% IN {total_time:.2f}s!")
    print("🌟" * 30 + "\n")
