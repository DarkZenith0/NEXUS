import json
import sys
from pathlib import Path

# Add project root to path
base_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(base_dir))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from core.action_loader import discover_actions

def test_discovery():
    print("=== TEST 1: Action Discovery ===")
    reg = discover_actions(base_dir / "actions")
    assert reg.has("computer_control"), "computer_control not registered"
    assert reg.has("macro_runner"), "macro_runner not registered"
    print("✅ Both computer_control and macro_runner discovered successfully!")
    return reg

def test_macro_runner(reg):
    print("\n=== TEST 2: Macro Runner ===")
    # 1. List macros
    res_list = reg.run("macro_runner", {"action": "list_macros"}, {})
    print("List macros result:\n", res_list)
    assert "Modo Trabajo" in res_list, "Modo Trabajo missing from list"

    # 2. Save a custom test macro
    test_steps = [
        {"tool": "computer_control", "action": "wait", "seconds": 0.2},
        {"tool": "computer_control", "action": "wait", "seconds": 0.2}
    ]
    res_save = reg.run("macro_runner", {
        "action": "save_macro",
        "macro_name": "modo_test_unitario",
        "description": "Macro de prueba unitaria rápida",
        "steps": test_steps
    }, {})
    print("Save macro result:", res_save)
    assert "guardada correctamente" in res_save

    # 3. Run the custom test macro
    res_run = reg.run("macro_runner", {
        "action": "run_macro",
        "macro_name": "modo_test_unitario"
    }, {})
    print("Run macro result:", res_run)
    assert "completada con éxito" in res_run

    # 4. Clean up test macro
    macros_file = base_dir / "config" / "macros.json"
    data = json.loads(macros_file.read_text(encoding="utf-8"))
    if "modo_test_unitario" in data:
        del data["modo_test_unitario"]
        macros_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        print("Cleaned up temporary test macro.")
    print("✅ Macro Runner tested and verified!")

def test_computer_control(reg):
    print("\n=== TEST 3: Computer Control Smart Actions ===")
    # 1. Test wait action
    res_wait = reg.run("computer_control", {"action": "wait", "seconds": 0.1}, {})
    print("Wait action result:", res_wait)
    assert "Waited" in res_wait

    # 2. Test snap_window logic
    res_snap = reg.run("computer_control", {"action": "snap_window", "position": "left"}, {})
    print("Snap window result:", res_snap)
    assert "Window snapped" in res_snap or "Snapped window" in res_snap

    # 3. Test smart_find fallback when element does not exist
    res_find = reg.run("computer_control", {"action": "smart_find", "description": "elemento_inexistente_xyz_12345"}, {})
    print("Smart find result (non-existent):", res_find)
    assert res_find == "NOT_FOUND"

    print("✅ Computer Control smart actions verified!")

if __name__ == "__main__":
    reg = test_discovery()
    test_macro_runner(reg)
    test_computer_control(reg)
    print("\n🎉 ALL PHASE 2 TESTS PASSED PERFECTLY!")
