"""
Verification script for:
1. Login with permanent token, master PIN, and device token
2. Persistent device auth check (/api/auth-check, /api/device-login)
3. WebSocket phone call single-client enforcement
4. Audio flush & interrupt propagation
5. Sequential audio delivery without overlap
"""
import sys
import os
import json
import asyncio
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from dashboard.server import DashboardServer
import uvicorn
import httpx
import websockets

async def run_tests():
    print("[TEST] Initializing DashboardServer...")
    server = DashboardServer()
    
    interrupted_event = asyncio.Event()
    def on_interrupt():
        print("[TEST] Interrupt callback invoked!")
        interrupted_event.set()
        
    server.set_interrupt_callback(on_interrupt)
    
    # Run uvicorn on test port 8995
    TEST_PORT = 8995
    config = uvicorn.Config(server.app, host="127.0.0.1", port=TEST_PORT, log_level="error")
    uv_server = uvicorn.Server(config)
    server_task = asyncio.create_task(uv_server.serve())
    
    # Wait for server to start listening
    for _ in range(50):
        if uv_server.started:
            break
        await asyncio.sleep(0.05)
        
    base_url = f"http://127.0.0.1:{TEST_PORT}"
    ws_url = f"ws://127.0.0.1:{TEST_PORT}"
    
    try:
        async with httpx.AsyncClient(base_url=base_url) as client:
            # 1. Test Master PIN login
            print("[TEST] 1. Testing Master PIN login...")
            res = await client.post("/login", json={"pin": server._master_pin})
            assert res.status_code == 200, f"Master PIN failed: {res.text}"
            data = res.json()
            assert data["ok"] is True
            token1 = data["token"]
            device_token1 = data.get("device_token")
            print(f"  -> OK. Token received: {token1[:15]}..., DeviceToken: {device_token1}")
            
            # 2. Test Permanent Token login
            print("[TEST] 2. Testing Permanent Token login...")
            perm_token = server._permanent_token
            assert perm_token, "Permanent token not configured in remote_config.json"
            res = await client.post("/login", json={"pin": perm_token})
            assert res.status_code == 200, f"Permanent token login failed: {res.text}"
            data = res.json()
            assert data["ok"] is True
            token2 = data["token"]
            device_token2 = data.get("device_token")
            print(f"  -> OK. Token received: {token2[:15]}..., DeviceToken: {device_token2}")
            
            # 3. Test /api/auth-check
            print("[TEST] 3. Testing /api/auth-check...")
            res = await client.post("/api/auth-check", json={"token": token2})
            assert res.status_code == 200 and res.json().get("ok") is True, f"Auth check failed: {res.text}"
            print("  -> OK. Valid token accepted.")
            
            res_bad = await client.post("/api/auth-check", json={"token": "invalid.jwt.token"})
            assert res_bad.status_code == 401, "Bad token should return 401"
            print("  -> OK. Invalid token rejected.")
            
            # 4. Test /api/device-login (remembered device)
            print("[TEST] 4. Testing /api/device-login with device_token...")
            res = await client.post("/api/device-login", json={"device_token": device_token2})
            assert res.status_code == 200 and res.json().get("ok") is True, f"Device login failed: {res.text}"
            print("  -> OK. Device login successfully generated session token.")
            
        # 5. Test WebSocket Phone Call & Single-Client Enforcement
        print("[TEST] 5. Testing Phone Call WebSocket & Single Client Enforcement...")
        call_ws_url = f"{ws_url}/ws/phone-call?token={token2}"
        
        ws1 = await websockets.connect(call_ws_url)
        print("  -> Client 1 connected.")
        assert len(server._phone_call_clients) == 1
        
        # Connect Client 2 (simulating mobile page reload or re-open)
        ws2 = await websockets.connect(call_ws_url)
        print("  -> Client 2 connected.")
        await asyncio.sleep(0.2)
        
        # Client 1 should have been closed cleanly to prevent duplicate audio feeds!
        assert len(server._phone_call_clients) == 1
        is_closed = (getattr(ws1, "close_code", None) is not None) or (ws1.state.name in ("CLOSED", "CLOSING"))
        assert is_closed, f"Client 1 should be closed when Client 2 connects, current state: {ws1.state.name}"
        print("  -> OK. Client 1 automatically closed; Client 2 is the sole active client.")
        
        # 6. Test Audio Queue and Delivery
        print("[TEST] 6. Testing sequential audio delivery...")
        dummy_chunk = b"\x00\x01" * 1600 # 3200 bytes of audio
        server.send_phone_audio(dummy_chunk)
        
        msg = await asyncio.wait_for(ws2.recv(), timeout=2.0)
        print(f"DEBUG: msg type={type(msg)}, content={msg if isinstance(msg, str) else len(msg)}")
        assert isinstance(msg, bytes) and len(msg) == len(dummy_chunk), f"Received audio chunk mismatch: {msg}"
        print("  -> OK. Audio chunk received sequentially.")
        
        # 7. Test User Interrupt (barge-in) from mobile
        print("[TEST] 7. Testing User Interrupt (barge-in)...")
        # Enqueue some chunks
        for _ in range(5):
            server.send_phone_audio(dummy_chunk)
            
        # Send interrupt message from client
        await ws2.send(json.dumps({"type": "interrupt"}))
        await asyncio.sleep(0.2)
        
        assert interrupted_event.is_set(), "Interrupt callback should have been fired!"
        print("  -> OK. Interrupt received, callback fired, audio queue cleared.")
        
        # Receive flush notice on client (drain any remaining in-flight audio chunks)
        flush_msg = None
        while True:
            m = await asyncio.wait_for(ws2.recv(), timeout=2.0)
            if isinstance(m, str):
                flush_msg = m
                break
        flush_data = json.loads(flush_msg)
        assert flush_data.get("type") == "audio_flush", f"Expected audio_flush, got {flush_msg}"
        print("  -> OK. Client received audio_flush confirmation.")
        
        await ws2.close()
        print("\n[ALL TESTS PASSED SUCCESSFULLY!]")
        return True
        
    finally:
        uv_server.should_exit = True
        await asyncio.sleep(0.1)
        server_task.cancel()
        try:
            await server_task
        except asyncio.CancelledError:
            pass

if __name__ == "__main__":
    success = asyncio.run(run_tests())
    sys.exit(0 if success else 1)
