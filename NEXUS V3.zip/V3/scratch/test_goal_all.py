"""
scratch/test_goal_all.py — Verificación exhaustiva de los 4 objetivos del Goal de NEXUS V3
"""
import sys
import os
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

# Ensure path
ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

def test_1_and_2_file_controller_and_storage():
    print("\n--- TEST 1 & 2: Búsqueda Inteligente, Atajos y Rutas de Almacenamiento ---")
    from core.nexus_paths import (
        BASE_DIR, NEXUS_UPLOADS, NEXUS_DOCUMENTS, NEXUS_FILES,
        ensure_nexus_dirs, get_storage_summary
    )
    from actions import file_controller

    # 1. Verificar carpetas físicas
    dirs = ensure_nexus_dirs()
    assert NEXUS_UPLOADS.exists(), "NEXUS UPLOADS no existe"
    assert NEXUS_DOCUMENTS.exists(), "NEXUS DOCUMENTS no existe"
    assert NEXUS_FILES.exists(), "NEXUS FILES no existe"
    print(f"[OK] Carpetas físicas verificadas:\n  - Uploads: {NEXUS_UPLOADS}\n  - Documents: {NEXUS_DOCUMENTS}\n  - Files: {NEXUS_FILES}")

    # 2. Atajos de resolución de rutas
    assert file_controller._resolve_path("nexus") == BASE_DIR
    assert file_controller._resolve_path("uploads") == NEXUS_UPLOADS
    assert file_controller._resolve_path("nexus_documents") == NEXUS_DOCUMENTS
    assert file_controller._resolve_path("nexus_files") == NEXUS_FILES
    assert file_controller._resolve_path("informes") == NEXUS_DOCUMENTS
    print("[OK] Atajos canónicos de resolución de rutas validados con éxito.")

    # 3. Creación ágil de carpeta y archivo con subdirectorios
    folder_res = file_controller.create_folder("nexus_documents", "Test_Carpeta/Sub")
    assert "successfully" in folder_res.lower()
    print(f"[OK] create_folder: {folder_res}")

    file_res = file_controller.create_file("nexus_documents/Test_Carpeta/Sub", "test_reporte.md", "# Test Reporte\nContenido de prueba.")
    assert "successfully" in file_res.lower()
    print(f"[OK] create_file: {file_res}")

    # 4. Búsqueda inteligente (smart_search)
    search_file = file_controller.smart_search(query="test_reporte", path="nexus_documents", item_type="file")
    assert "test_reporte.md" in search_file
    print(f"[OK] smart_search (archivo):\n{search_file}")

    search_folder = file_controller.smart_search(query="Test_Carpeta", path="nexus_documents", item_type="folder")
    assert "Test_Carpeta" in search_folder
    print(f"[OK] smart_search (carpeta):\n{search_folder}")

    # 5. Resumen de almacenamiento dedicado (nexus_storage)
    storage_summary = file_controller.nexus_storage()
    assert "NEXUS DOCUMENTS" in storage_summary
    assert "NEXUS FILES" in storage_summary
    print(f"[OK] nexus_storage summary:\n{storage_summary}")

    # Limpieza
    test_sub = NEXUS_DOCUMENTS / "Test_Carpeta"
    if test_sub.exists():
        import shutil
        shutil.rmtree(test_sub)
    print("[OK] Limpieza de ficheros temporales de test completada.")


def test_3_phone_call_audio_isolation():
    print("\n--- TEST 3: Modo Llamada y Aislamiento de Audio (Silenciado PC) ---")
    from dashboard.server import DashboardServer

    # 1. Verificación de listeners en DashboardServer
    srv = DashboardServer()
    call_events = []

    def mock_listener(active: bool):
        call_events.append(active)

    srv.add_call_listener(mock_listener)
    assert mock_listener in srv._call_state_listeners, "Listener no registrado"

    # Simular inicio de llamada
    srv._notify_call_listeners(True)
    assert call_events == [True], f"Esperado [True], obtenido {call_events}"
    assert srv.is_call_active() == False  # Aún no hay websockets agregados

    # Simular fin de llamada
    srv._notify_call_listeners(False)
    assert call_events == [True, False], f"Esperado [True, False], obtenido {call_events}"
    print("[OK] Eventos de llamada en DashboardServer verificados.")

    # 2. Verificación de lógica en JarvisLive
    # Mocking de JarvisLive para verificar callback y banderas
    class MockUI:
        def __init__(self):
            self.muted = False
            self.nexus_muted = False
            self.logs = []
        def write_log(self, text):
            self.logs.append(text)
        def set_state(self, state):
            pass

    ui = MockUI()
    # Importar clase o instanciar mocks
    import main
    # Validar que JarvisLive tiene los métodos y banderas implementados
    assert hasattr(main.JarvisLive, "_on_phone_call_state_changed"), "_on_phone_call_state_changed no está en JarvisLive"
    print("[OK] JarvisLive._on_phone_call_state_changed existe y está cableado.")


def test_4_dashboard_ui_and_endpoints():
    print("\n--- TEST 4: Verificación de la Interfaz Web y Endpoints Móviles ---")
    app_html_path = ROOT_DIR / "dashboard" / "static" / "app.html"
    assert app_html_path.exists(), "app.html no existe"
    content = app_html_path.read_text(encoding="utf-8")

    # Verificaciones de elementos clave en el rediseño
    assert "N.E.X.U.S" in content
    assert "dock-container" in content, "Falta dock inferior tipo ChatGPT/Gemini"
    assert "call-overlay" in content, "Falta modal de llamada"
    assert "storage-drawer" in content, "Falta drawer de almacenamiento dedicado"
    assert "NEXUS DOCUMENTS" in content, "Falta tab NEXUS DOCUMENTS"
    assert "NEXUS FILES" in content, "Falta tab NEXUS FILES"
    assert "sub-bar" in content, "Falta sub-barra rápida"
    print(f"[OK] Archivo app.html validado con éxito ({len(content)} bytes).")

    # Validar que los endpoints /api/storage y /documents/{filename} están en server.py
    server_py = (ROOT_DIR / "dashboard" / "server.py").read_text(encoding="utf-8")
    assert "/api/storage" in server_py, "Falta endpoint /api/storage en server.py"
    assert "/documents/{filename}" in server_py, "Falta endpoint /documents/{filename} en server.py"
    assert "UPLOADS_DIR = NEXUS_FILES" in server_py, "UPLOADS_DIR debe apuntar a NEXUS_FILES"
    print("[OK] Endpoints de almacenamiento y streaming en server.py validados.")


if __name__ == "__main__":
    try:
        test_1_and_2_file_controller_and_storage()
        test_3_phone_call_audio_isolation()
        test_4_dashboard_ui_and_endpoints()
        print("\n=======================================================")
        print("✅ TODAS LAS PRUEBAS COMPLETADAS CON ÉXITO ABSOLUTO")
        print("=======================================================")
        sys.exit(0)
    except AssertionError as e:
        print(f"\n❌ ERROR DE VERIFICACIÓN: {e}")
        sys.exit(1)
    except Exception as e:
        import traceback
        traceback.print_exc()
        sys.exit(1)
