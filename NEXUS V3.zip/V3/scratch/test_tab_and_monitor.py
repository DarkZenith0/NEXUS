import json
import sys
import time
from pathlib import Path

# Add project root
base_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(base_dir))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

def test_smart_monitor_detection():
    print("\n" + "=" * 60)
    print("TEST 1: Smart Multi-Monitor Detection and Screen Capture")
    print("=" * 60)
    
    import mss
    from actions.screen_processor import _get_smart_monitor, _capture_screen
    from actions.computer_control import _get_active_monitor_bounds, _screenshot
    
    sct_cls = getattr(mss, "MSS", mss.mss)
    with sct_cls() as sct:
        real_count = len(sct.monitors) - 1
        print(f"Detected {real_count} physical monitor(s).")
        for i, m in enumerate(sct.monitors[1:], 1):
            print(f"  Monitor {i}: {m['width']}x{m['height']} at ({m['left']}, {m['top']}) - Primary: {m.get('is_primary', False)}")
        
        # Test 1.1: Automatic active monitor
        active_mon = _get_smart_monitor(sct, None)
        print("Automatic active monitor:", active_mon['width'], "x", active_mon['height'], "at", (active_mon['left'], active_mon['top']))
        assert active_mon is not None
        
        # Test 1.2: Directional selectors
        left_mon = _get_smart_monitor(sct, "left")
        right_mon = _get_smart_monitor(sct, "right")
        print("Left monitor:", left_mon['width'], "x", left_mon['height'], "at", (left_mon['left'], left_mon['top']))
        print("Right monitor:", right_mon['width'], "x", right_mon['height'], "at", (right_mon['left'], right_mon['top']))
        assert left_mon['left'] <= right_mon['left']
        
        # Test 1.3: Numbered selectors
        if real_count >= 2:
            m1 = _get_smart_monitor(sct, 1)
            m2 = _get_smart_monitor(sct, 2)
            assert m1 != m2, "Monitor 1 and Monitor 2 should have different bounds!"
            print("Successfully distinguished Monitor 1 and Monitor 2!")
            
        # Test 1.4: Screen capture on specific monitors
        img_bytes_active, mime = _capture_screen("active")
        assert len(img_bytes_active) > 1000, "Active screen capture failed"
        print(f"Captured active screen: {len(img_bytes_active):,} bytes ({mime})")
        
        if real_count >= 2:
            img_bytes_m2, _ = _capture_screen(2)
            assert len(img_bytes_m2) > 1000, "Monitor 2 capture failed"
            print(f"Captured Monitor 2: {len(img_bytes_m2):,} bytes")
            
        # Test 1.5: Computer control screenshot with monitor targeting
        test_shot = Path.home() / "Desktop" / "nexus_test_shot.jpg"
        res = _screenshot(str(test_shot), monitor="active")
        print("Computer control screenshot result:", res)
        assert test_shot.exists() and test_shot.stat().st_size > 1000
        test_shot.unlink() # cleanup
        print("✅ Multi-monitor detection and capture verified 100%!")

def test_browser_same_tab_and_find():
    print("\n" + "=" * 60)
    print("TEST 2: Browser Control Same-Tab & Find In Page")
    print("=" * 60)
    
    from actions.browser_control import browser_control, TOOL
    
    # 2.1 Verify TOOL schema includes find_in_page and new_tab
    actions_desc = TOOL["parameters"]["properties"]["action"]["description"]
    assert "find_in_page" in actions_desc, "find_in_page missing from browser_control TOOL"
    assert "new_tab" in TOOL["parameters"]["properties"], "new_tab parameter missing from browser_control TOOL"
    print("✅ browser_control TOOL schema verified (includes find_in_page and new_tab)!")
    
    # 2.2 Test find_in_page dispatch
    res_find = browser_control({"action": "find_in_page", "query": "descargas"})
    print("find_in_page dispatch result:", res_find)
    assert "descargas" in res_find
    print("✅ find_in_page successfully handled!")

def test_computer_control_find_in_page():
    print("\n" + "=" * 60)
    print("TEST 3: Computer Control find_in_page Action")
    print("=" * 60)
    
    from actions.computer_control import computer_control, TOOL
    
    # 3.1 Verify action and parameters
    action_desc = TOOL["parameters"]["properties"]["action"]["description"]
    assert "find_in_page" in action_desc, "find_in_page missing from computer_control TOOL"
    assert "monitor" in TOOL["parameters"]["properties"], "monitor parameter missing from computer_control TOOL"
    
    # 3.2 Test find_in_page dispatch
    res = computer_control({"action": "find_in_page", "text": "NexusTest"})
    print("Computer control find_in_page result:", res)
    assert "NexusTest" in res
    print("✅ computer_control find_in_page verified!")

def test_main_import_and_tool_sanity():
    print("\n" + "=" * 60)
    print("TEST 4: main.py Tool Definitions & Import Sanity")
    print("=" * 60)
    
    import main
    # Check screen_process declaration in main
    sp_tool = None
    for t in main.TOOL_DECLARATIONS:
        if t.get("name") == "screen_process":
            sp_tool = t
            break
    assert sp_tool is not None, "screen_process tool not found in main.TOOL_DECLARATIONS"
    props = sp_tool["parameters"]["properties"]
    assert "monitor" in props, "monitor parameter missing from screen_process in main.py"
    print(f"screen_process monitor property description: {props['monitor']['description']}")
    print("✅ main.py screen_process tool schema verified!")

if __name__ == "__main__":
    test_smart_monitor_detection()
    test_browser_same_tab_and_find()
    test_computer_control_find_in_page()
    test_main_import_and_tool_sanity()
    print("\n" + "🎉" * 20)
    print("ALL TESTS PASSED WITH 100% SUCCESS!")
    print("🎉" * 20)
