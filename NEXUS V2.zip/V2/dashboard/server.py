"""
dashboard/server.py — N.E.X.U.S Remote Control Server

Dual-port architecture:
  - Port 8000: Clean, lightning-fast HTTP (no security warnings, instant QR access).
  - Port 8001: Secure TLS with local Root CA (direct microphone support without flags).
  - Built-in Tailscale support for seamless, secure remote access away from home.
  - Media playback controls, live PC screen monitor, and real-time audio relay to Gemini Live.

Requirements: pip install fastapi "uvicorn[standard]" cryptography
"""

import asyncio
import base64
import hashlib
import json
import os
import re
import secrets
import socket
import string
import subprocess
import time
from datetime import datetime
from pathlib import Path

_DEPS_OK = False
try:
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
    from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
    import uvicorn
    _DEPS_OK = True
except ImportError:
    pass

# python-multipart is required for file uploads — optional dependency
_UPLOAD_OK = False
try:
    from fastapi import UploadFile, File as FastAPIFile
    _UPLOAD_OK = True
except Exception:
    pass

BASE_DIR            = Path(__file__).resolve().parent.parent
STATIC_DIR          = Path(__file__).parent / "static"
CONFIG_DIR          = BASE_DIR / "config"
REMOTE_CFG_PATH     = CONFIG_DIR / "remote_config.json"
PAIRED_DEVICES_PATH = CONFIG_DIR / "paired_devices.json"
PORT                = 8000
MAX_UPLOAD_MB       = 500


def _load_remote_config() -> dict:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    cfg = {
        "master_pin": "NEXUS777",
        "permanent_token": secrets.token_urlsafe(32),
        "auto_login_on_tailscale": True
    }
    if REMOTE_CFG_PATH.exists():
        try:
            with open(REMOTE_CFG_PATH, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                if isinstance(loaded, dict):
                    cfg.update(loaded)
        except Exception:
            pass
    try:
        with open(REMOTE_CFG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except Exception:
        pass
    return cfg


def _load_paired_devices() -> dict:
    if PAIRED_DEVICES_PATH.exists():
        try:
            with open(PAIRED_DEVICES_PATH, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                if isinstance(loaded, dict):
                    return loaded
        except Exception:
            pass
    return {}


def _save_paired_devices(devices: dict) -> None:
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(PAIRED_DEVICES_PATH, "w", encoding="utf-8") as f:
            json.dump(devices, f, indent=2)
    except Exception:
        pass


def _make_uploads_dir() -> Path:
    """Return (and create) the cross-platform uploads folder."""
    for candidate in [
        Path.home() / "Downloads" / "NEXUS Uploads",
        Path.home() / "Documents" / "NEXUS Uploads",
        Path.home() / "Downloads" / "JARVIS Uploads",
        Path.home() / "Documents" / "JARVIS Uploads",
        BASE_DIR / "uploads",
    ]:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            return candidate
        except Exception:
            pass
    return BASE_DIR / "uploads"


UPLOADS_DIR = _make_uploads_dir()

def _get_gemini_key() -> str | None:
    try:
        with open(BASE_DIR / "config" / "api_keys.json", "r", encoding="utf-8") as f:
            return json.load(f).get("gemini_api_key")
    except Exception:
        return None

_KEY_CHARS = [c for c in (string.ascii_uppercase + string.digits)
              if c not in ('O', 'I', 'L', '0', '1')]

# ── AES-256-CBC ───────────────────────────────────────────────────────────────
_AES_SALT = b'JARVIS-DASHBOARD-v1'


def _derive_key(session_key: str) -> bytes:
    """SHA-256(sessionKey‖salt) → 32-byte AES-256 key."""
    return hashlib.sha256(session_key.encode('utf-8') + _AES_SALT).digest()


def _decrypt_cbc(aes_key: bytes, enc_b64: str) -> str:
    """Decrypt base64(IV[16] ‖ ciphertext) with AES-256-CBC + PKCS7."""
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.primitives import padding as sym_pad
    raw      = base64.b64decode(enc_b64)
    iv, ct   = raw[:16], raw[16:]
    dec      = Cipher(algorithms.AES(aes_key), modes.CBC(iv)).decryptor()
    padded   = dec.update(ct) + dec.finalize()
    unpadder = sym_pad.PKCS7(128).unpadder()
    return (unpadder.update(padded) + unpadder.finalize()).decode('utf-8')


# ── CryptoJS (auto-download once, served locally) ─────────────────────────────
_CRYPTOJS_CDN  = ("https://cdnjs.cloudflare.com/ajax/libs/"
                  "crypto-js/4.2.0/crypto-js.min.js")
_CRYPTOJS_FILE = STATIC_DIR / "crypto-js.min.js"


def _ensure_network_access(port: int) -> None:
    """Cross-platform, best-effort: open port in the OS firewall for LAN access."""
    import sys, subprocess, os, tempfile, threading

    if sys.platform == "win32":
        import ctypes

        port_rule = f"NEXUS Dashboard Port {port}"
        prog_rule = "NEXUS Dashboard Python"
        py_exe    = sys.executable

        def _netsh_rule_exists(name: str) -> bool:
            try:
                r = subprocess.run(
                    ["netsh", "advfirewall", "firewall", "show", "rule", f"name={name}"],
                    capture_output=True, text=True, timeout=5,
                )
                return r.returncode == 0 and "No rules match" not in r.stdout
            except Exception:
                return False

        def _network_is_public() -> bool:
            try:
                r = subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                     "(Get-NetConnectionProfile | "
                     "Where-Object {$_.NetworkCategory -eq 'Public'} | "
                     "Measure-Object).Count"],
                    capture_output=True, text=True, timeout=6,
                )
                return r.stdout.strip() not in ("", "0")
            except Exception:
                return False

        need_port    = not _netsh_rule_exists(port_rule)
        need_prog    = not _netsh_rule_exists(prog_rule)
        need_private = _network_is_public()

        if not need_port and not need_prog and not need_private:
            return  # already fully configured

        bat_lines = ["@echo off"]
        if need_private:
            bat_lines.append(
                'powershell -NoProfile -NonInteractive -Command "'
                'Get-NetConnectionProfile | '
                "Where-Object {$_.NetworkCategory -eq 'Public'} | "
                'Set-NetConnectionProfile -NetworkCategory Private"'
            )
        if need_port:
            bat_lines.append(
                f'netsh advfirewall firewall add rule '
                f'name="{port_rule}" protocol=TCP dir=in '
                f'localport={port} action=allow'
            )
        if need_prog:
            bat_lines.append(
                f'netsh advfirewall firewall add rule '
                f'name="{prog_rule}" dir=in action=allow '
                f'program="{py_exe}" enable=yes'
            )

        bat_body = "\r\n".join(bat_lines) + "\r\n"
        fd, bat_path = tempfile.mkstemp(suffix=".bat", prefix="nexus_fw_")
        try:
            os.write(fd, bat_body.encode("mbcs"))
            os.close(fd)
        except Exception:
            try:
                os.close(fd)
            except Exception:
                pass
            return

        try:
            r = subprocess.run([bat_path], capture_output=True, timeout=8, shell=True)
            if r.returncode == 0:
                try:
                    os.unlink(bat_path)
                except Exception:
                    pass
                return
        except Exception:
            pass

        try:
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", bat_path, None, None, 0
            )
        except Exception:
            pass
        finally:
            def _cleanup(path: str) -> None:
                time.sleep(5)
                try:
                    os.unlink(path)
                except Exception:
                    pass
            threading.Thread(target=_cleanup, args=(bat_path,), daemon=True).start()
        return

    if sys.platform == "darwin":
        fw_ctl = "/usr/libexec/ApplicationFirewall/socketfilterfw"
        try:
            r = subprocess.run([fw_ctl, "--getglobalstate"], capture_output=True, text=True, timeout=5)
            if "disabled" in r.stdout.lower():
                return
            py = sys.executable
            listed = subprocess.run([fw_ctl, "--listapps"], capture_output=True, text=True, timeout=5)
            if py in listed.stdout:
                return
            subprocess.run(
                ["osascript", "-e",
                 f'do shell script "{fw_ctl} --add {py} && {fw_ctl} --unblockapp {py}" with administrator privileges'],
                timeout=60,
            )
        except Exception:
            pass
        return

    # Linux (ufw, firewalld, iptables)
    try:
        r = subprocess.run(["ufw", "status"], capture_output=True, text=True, timeout=5)
        if "active" in r.stdout.lower():
            subprocess.run(["sudo", "-n", "ufw", "allow", f"{port}/tcp"], capture_output=True, timeout=10)
    except Exception:
        pass


def _ensure_crypto_js() -> None:
    if _CRYPTOJS_FILE.exists():
        return
    try:
        import urllib.request
        print("[Dashboard] Caching CryptoJS locally…")
        urllib.request.urlretrieve(_CRYPTOJS_CDN, str(_CRYPTOJS_FILE))
    except Exception as e:
        print(f"[Dashboard] CryptoJS download failed: {e}")


_ensure_crypto_js()


# ── Network and Tailscale Helpers ─────────────────────────────────────────────

def _local_ip() -> str:
    """Return the best LAN-facing IPv4 address."""
    for probe in ("8.8.8.8", "1.1.1.1", "192.168.1.1"):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.5)
            s.connect((probe, 80))
            ip = s.getsockname()[0]
            s.close()
            if not ip.startswith("127."):
                return ip
        except Exception:
            pass

    try:
        ip = socket.gethostbyname(socket.gethostname())
        if not ip.startswith("127."):
            return ip
    except Exception:
        pass

    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and not ip.startswith("169.254."):
                return ip
    except Exception:
        pass

    return "127.0.0.1"


def _detect_tailscale() -> dict:
    """Detect Tailscale IPv4 and MagicDNS if active on host."""
    tailscale_bins = [
        "tailscale",
        r"C:\Program Files\Tailscale\tailscale.exe",
        Path.home() / "AppData" / "Local" / "Tailscale" / "tailscale.exe",
    ]
    for cmd in tailscale_bins:
        cmd_str = str(cmd)
        try:
            r = subprocess.run([cmd_str, "status", "--json"], capture_output=True, text=True, timeout=2)
            if r.returncode == 0 and r.stdout.strip():
                data = json.loads(r.stdout)
                self_node = data.get("Self", {})
                ips = self_node.get("TailscaleIPs", [])
                ipv4 = next((ip for ip in ips if "." in ip), None)
                dns_name = self_node.get("DNSName", "").rstrip(".")
                if ipv4:
                    return {
                        "available": True,
                        "ip": ipv4,
                        "dns": dns_name or None,
                        "status": "connected"
                    }
        except Exception:
            pass

        try:
            r = subprocess.run([cmd_str, "ip", "-4"], capture_output=True, text=True, timeout=2)
            if r.returncode == 0 and r.stdout.strip():
                ip = r.stdout.strip().splitlines()[0].strip()
                if ip:
                    return {
                        "available": True,
                        "ip": ip,
                        "dns": None,
                        "status": "connected"
                    }
        except Exception:
            pass

    # Method 2: Inspect network interfaces for 100.64.0.0/10 (Tailscale CGNAT)
    try:
        import ipaddress
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             "Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty IPAddress"],
            capture_output=True, text=True, timeout=3
        )
        ts_net = ipaddress.IPv4Network("100.64.0.0/10")
        for line in r.stdout.splitlines():
            raw = line.strip()
            try:
                ip_obj = ipaddress.IPv4Address(raw)
                if ip_obj in ts_net:
                    return {
                        "available": True,
                        "ip": raw,
                        "dns": None,
                        "status": "connected"
                    }
            except Exception:
                pass
    except Exception:
        pass

    return {
        "available": False,
        "ip": None,
        "dns": None,
        "status": "not_installed"
    }


def _ensure_certs() -> bool:
    """
    Generate a local Root Certificate Authority (nexus-ca.crt) and a server certificate
    (jarvis.crt) signed by that CA.

    The certificates include SANs for:
      - localhost, nexus.local
      - 127.0.0.1
      - Active LAN IP
      - Tailscale IP (if detected)
      - Machine hostname
    """
    certs = BASE_DIR / "config" / "certs"
    certs.mkdir(parents=True, exist_ok=True)
    ca_key_path  = certs / "nexus-ca.key"
    ca_crt_path  = certs / "nexus-ca.crt"
    srv_key_path = certs / "jarvis.key"
    srv_crt_path = certs / "jarvis.crt"

    if srv_key_path.exists() and srv_crt_path.exists() and ca_crt_path.exists():
        return True

    try:
        import datetime
        import ipaddress
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID
    except ImportError:
        print("[Dashboard] cryptography not installed — serving over plain HTTP.")
        return False

    try:
        now = datetime.datetime.now(datetime.timezone.utc)

        # 1. Generate Root CA if not exists
        if not ca_key_path.exists() or not ca_crt_path.exists():
            ca_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            ca_name = x509.Name([
                x509.NameAttribute(NameOID.COMMON_NAME, "NEXUS Root CA"),
                x509.NameAttribute(NameOID.ORGANIZATION_NAME, "NEXUS Assistant"),
            ])
            ca_cert = (
                x509.CertificateBuilder()
                .subject_name(ca_name)
                .issuer_name(ca_name)
                .public_key(ca_key.public_key())
                .serial_number(x509.random_serial_number())
                .not_valid_before(now - datetime.timedelta(days=1))
                .not_valid_after(now + datetime.timedelta(days=3650))
                .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
                .add_extension(
                    x509.KeyUsage(
                        digital_signature=True, key_encipherment=False, key_cert_sign=True,
                        crl_sign=True, content_commitment=False, data_encipherment=False,
                        key_agreement=False, encipher_only=False, decipher_only=False
                    ),
                    critical=True
                )
                .sign(ca_key, hashes.SHA256())
            )
            ca_key_path.write_bytes(ca_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption(),
            ))
            ca_crt_path.write_bytes(ca_cert.public_bytes(serialization.Encoding.PEM))
        else:
            ca_key = serialization.load_pem_private_key(ca_key_path.read_bytes(), password=None)
            ca_cert = x509.load_pem_x509_certificate(ca_crt_path.read_bytes())
            ca_name = ca_cert.subject

        # 2. Build SANs list for Server Certificate
        alt_names = [
            x509.DNSName("localhost"),
            x509.DNSName("nexus.local"),
            x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
        ]

        # Hostname SAN
        try:
            hname = socket.gethostname()
            if hname:
                alt_names.append(x509.DNSName(hname.lower()))
        except Exception:
            pass

        # LAN IP SAN
        try:
            lan = _local_ip()
            if not lan.startswith("127."):
                alt_names.append(x509.IPAddress(ipaddress.IPv4Address(lan)))
        except Exception:
            pass

        # Tailscale IP SAN
        ts = _detect_tailscale()
        if ts.get("ip"):
            try:
                alt_names.append(x509.IPAddress(ipaddress.IPv4Address(ts["ip"])))
            except Exception:
                pass
        if ts.get("dns"):
            try:
                alt_names.append(x509.DNSName(ts["dns"].lower()))
            except Exception:
                pass

        # 3. Generate Server Key & Certificate signed by Root CA
        srv_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        srv_name = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, "nexus.local"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "NEXUS Assistant"),
        ])
        srv_cert = (
            x509.CertificateBuilder()
            .subject_name(srv_name)
            .issuer_name(ca_name)
            .public_key(srv_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=1825))
            .add_extension(x509.SubjectAlternativeName(alt_names), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .sign(ca_key, hashes.SHA256())
        )

        srv_key_path.write_bytes(srv_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        ))
        srv_crt_path.write_bytes(srv_cert.public_bytes(serialization.Encoding.PEM))

        print(f"[Dashboard] Root CA and signed TLS server certificate ready in {certs}")
        return True
    except Exception as e:
        print(f"[Dashboard] Certificate generation error: {e}")
        return False


def _read(name: str) -> str:
    path = STATIC_DIR / name
    if path.exists():
        return path.read_text(encoding="utf-8")
    return ""


# ── DashboardServer ───────────────────────────────────────────────────────────

class DashboardServer:

    def __init__(self):
        self._ip                          = _local_ip()
        self._tokens: set[str]            = set()
        self._token_keys: dict[str, str]  = {}   # auth_token → session_key
        self._aes_cache:  dict[str, bytes]= {}   # session_key → AES bytes
        self._clients: set[WebSocket]     = set()
        self._history: list[dict]         = []
        self._command_queue               = asyncio.Queue()
        self._wake_callback               = None
        self._connect_callback            = None
        self._pending_keys: dict[str, float] = {}
        self._remote_cfg                  = _load_remote_config()
        self._master_pin                  = str(self._remote_cfg.get("master_pin", "NEXUS777")).strip().upper()
        self._permanent_token             = str(self._remote_cfg.get("permanent_token", "")).strip()
        self._device_sessions: dict[str, dict] = _load_paired_devices()
        self._phone_audio_queue: asyncio.Queue = asyncio.Queue(maxsize=200)
        self._uploads_dir                 = UPLOADS_DIR
        self._login_html                  = _read("login.html")
        self._app_html                    = _read("app.html")
        self._cert_html                   = _read("cert.html")
        self.app                          = self._build_app()

    # ── one-time key management ───────────────────────────────────────────

    def new_key(self, expiry_secs: int = 600) -> str:
        now = time.time()
        self._pending_keys = {k: v for k, v in self._pending_keys.items() if v > now}
        key = ''.join(secrets.choice(_KEY_CHARS) for _ in range(6))
        self._pending_keys[key] = now + expiry_secs
        return key

    @staticmethod
    def _ssl_enabled() -> bool:
        certs = BASE_DIR / "config" / "certs"
        return (certs / "jarvis.key").exists() and (certs / "jarvis.crt").exists()

    def get_url(self) -> str:
        """Default HTTP URL for rapid, zero-warning mobile access."""
        return f"http://{self._ip}:{PORT}"

    def get_manual_url(self) -> str:
        """URL string for manual browser entry."""
        return f"{self._ip}:{PORT}"

    def get_https_url(self) -> str:
        """Secure HTTPS URL with direct microphone capabilities."""
        return f"https://{self._ip}:{PORT + 1}"

    def get_remote_details(self, key: str | None = None) -> dict:
        """Complete connection metadata for UI overlay tabs (LAN, Tailscale, HTTP, HTTPS)."""
        ts = _detect_tailscale()
        k = key or self.new_key()
        perm = self._permanent_token
        ts_ip = ts.get("ip")
        return {
            "key": k,
            "master_pin": self._master_pin,
            "permanent_token": perm,
            "lan_ip": self._ip,
            "port_http": PORT,
            "port_https": PORT + 1,
            "lan_http_url": f"http://{self._ip}:{PORT}",
            "lan_https_url": f"https://{self._ip}:{PORT + 1}",
            "lan_auto_login_http": f"http://{self._ip}:{PORT}/auto-login?key={k}",
            "lan_auto_login_https": f"https://{self._ip}:{PORT + 1}/auto-login?key={k}",
            "lan_magic_link_http": f"http://{self._ip}:{PORT}/auto-login?token={perm}",
            "tailscale": ts,
            "tailscale_auto_login_http": f"http://{ts_ip}:{PORT}/auto-login?key={k}" if ts_ip else None,
            "tailscale_auto_login_https": f"https://{ts_ip}:{PORT + 1}/auto-login?key={k}" if ts_ip else None,
            "ts_magic_link": f"http://{ts_ip}:{PORT}/auto-login?token={perm}" if ts_ip else f"http://{self._ip}:{PORT}/auto-login?token={perm}",
            "ts_magic_link_https": f"https://{ts_ip}:{PORT + 1}/auto-login?token={perm}" if ts_ip else f"https://{self._ip}:{PORT + 1}/auto-login?token={perm}",
        }

    def _aes_key(self, session_key: str) -> bytes:
        if session_key not in self._aes_cache:
            self._aes_cache[session_key] = _derive_key(session_key)
        return self._aes_cache[session_key]

    def _decrypt(self, token: str, enc_b64: str) -> str | None:
        sk = self._token_keys.get(token)
        if not sk:
            return None
        try:
            return _decrypt_cbc(self._aes_key(sk), enc_b64)
        except Exception:
            return None

    # ── callbacks ────────────────────────────────────────────────────────

    def set_wake_callback(self, fn) -> None:
        self._wake_callback = fn

    def set_connect_callback(self, fn) -> None:
        self._connect_callback = fn

    # ── broadcast ────────────────────────────────────────────────────────

    async def broadcast(self, msg: dict) -> None:
        self._history.append(msg)
        if len(self._history) > 300:
            self._history = self._history[-300:]
        dead: set[WebSocket] = set()
        for ws in list(self._clients):
            try:
                await ws.send_json(msg)
            except Exception:
                dead.add(ws)
        self._clients -= dead

    # ── FastAPI app ───────────────────────────────────────────────────────

    def _build_app(self) -> "FastAPI":
        app = FastAPI(docs_url=None, redoc_url=None)

        # ── Security headers middleware: eliminates malware / heuristic warnings
        @app.middleware("http")
        async def add_security_headers(request: Request, call_next):
            response = await call_next(request)
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "SAMEORIGIN"
            response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
            response.headers["Permissions-Policy"] = "microphone=(self), camera=()"
            return response

        def _auth(req: Request) -> bool:
            tok = req.headers.get("authorization", "").removeprefix("Bearer ").strip()
            return bool(tok) and tok in self._tokens

        # CryptoJS local cache
        @app.get("/static/crypto.js")
        async def serve_crypto():
            if _CRYPTOJS_FILE.exists():
                return FileResponse(str(_CRYPTOJS_FILE), media_type="application/javascript")
            from fastapi.responses import RedirectResponse
            return RedirectResponse(_CRYPTOJS_CDN)

        # Certificate guide & download endpoints
        @app.get("/cert", response_class=HTMLResponse)
        async def cert_guide_page():
            content = _read("cert.html") or self._cert_html
            return HTMLResponse(content)

        @app.get("/api/cert")
        async def download_ca_cert():
            ca_path = BASE_DIR / "config" / "certs" / "nexus-ca.crt"
            if not ca_path.exists():
                _ensure_certs()
            if ca_path.exists():
                return FileResponse(
                    str(ca_path),
                    media_type="application/x-x509-ca-cert",
                    filename="nexus-ca.crt"
                )
            return JSONResponse({"error": "Certificate not generated"}, status_code=404)

        @app.get("/manifest.json")
        async def manifest_ep():
            m_path = STATIC_DIR / "manifest.json"
            if m_path.exists():
                return FileResponse(str(m_path), media_type="application/manifest+json")
            return JSONResponse({"name": "NEXUS Remote"}, status_code=200)

        @app.get("/static/icon.png")
        async def icon_ep():
            i_path = STATIC_DIR / "icon.png"
            if i_path.exists():
                return FileResponse(str(i_path), media_type="image/png")
            return JSONResponse({"error": "No icon"}, status_code=404)

        @app.get("/login", response_class=HTMLResponse)
        async def login_page():
            content = _read("login.html") or self._login_html
            return HTMLResponse(content)

        @app.get("/", response_class=HTMLResponse)
        async def index():
            content = _read("app.html") or self._app_html
            html = (content
                    .replace("__IP__", self._ip)
                    .replace("__PORT__", str(PORT)))
            return HTMLResponse(html)

        @app.post("/login")
        async def login(req: Request):
            try:
                body = await req.json()
            except Exception:
                return JSONResponse({"ok": False, "error": "Invalid JSON"}, status_code=400)
            entered = str(body.get("pin", "") or body.get("key", "")).strip().upper()
            now = time.time()
            is_temp = entered in self._pending_keys and self._pending_keys[entered] > now
            is_master = bool(self._master_pin and entered == self._master_pin)

            if is_temp or is_master:
                # Do NOT delete from _pending_keys immediately.
                # Keeping it valid for the 10-minute window prevents race conditions,
                # retry issues, and dual-request failures.
                tok = secrets.token_urlsafe(32)
                dev_tok = secrets.token_urlsafe(32)
                self._tokens.add(tok)
                self._token_keys[tok] = entered
                self._aes_key(entered)

                # Persist paired device session
                self._device_sessions[dev_tok] = {
                    "session_key": entered,
                    "created_at": time.time(),
                    "is_master": is_master
                }
                _save_paired_devices(self._device_sessions)

                if self._connect_callback:
                    self._connect_callback()
                asyncio.create_task(self.broadcast(
                    {"type": "sys", "text": "Remote connection established."}
                ))
                return JSONResponse({"ok": True, "token": tok, "device_token": dev_tok, "key": entered})
            return JSONResponse({"ok": False, "error": "Invalid or expired key"}, status_code=401)

        @app.get("/auto-login")
        async def auto_login(key: str = "", pin: str = "", token: str = ""):
            """QR code & permanent Magic Link target — sets tokens and redirects mobile browser."""
            now = time.time()
            clean_key = (key or pin or "").strip().upper()
            clean_tok = (token or "").strip()
            valid = False
            session_key = ""

            # 1. Check permanent token (Magic Link)
            if clean_tok and clean_tok == self._permanent_token:
                valid = True
                session_key = self._master_pin
            # 2. Check Master PIN used directly
            elif clean_key and self._master_pin and clean_key == self._master_pin:
                valid = True
                session_key = self._master_pin
            # 3. Check temporary key
            elif clean_key and clean_key in self._pending_keys and self._pending_keys[clean_key] > now:
                valid = True
                session_key = clean_key
                # DO NOT delete self._pending_keys[clean_key].
                # Mobile cameras/scanners (iOS Safari, Android Google Lens) send a background
                # prefetch GET on scan. Deleting here caused the actual user tap to see "Clave Caducada"!

            if not valid:
                return HTMLResponse(f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>N.E.X.U.S | Acceso Remoto</title>
<style>
  body{{background:#06080d;color:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,sans-serif;
       display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;padding:20px}}
  .box{{background:rgba(14,18,28,0.92);border:1px solid rgba(255,46,77,0.35);border-radius:20px;padding:32px 24px;max-width:360px;box-shadow:0 12px 36px rgba(0,0,0,0.5)}}
  h2{{color:#ff2e4d;margin-bottom:12px;font-size:20px}}p{{color:#94a3b8;font-size:14px;line-height:1.55;margin-bottom:18px}}
  .btn{{background:linear-gradient(135deg,#ff2e4d,#d91b39);color:#fff;text-decoration:none;display:inline-block;padding:12px 24px;border-radius:12px;font-weight:700;font-size:14px;letter-spacing:1px}}
  .recon-msg{{color:#00f0ff;font-size:13px;font-weight:600;margin-bottom:14px;display:none}}
</style></head>
<body><div class="box">
<div class="recon-msg" id="recon-msg">🔄 Sesión previa detectada, conectando…</div>
<h2>Enlace no válido o caducado</h2>
<p>Genera una nueva clave en NEXUS o accede usando tu PIN Maestro <b>{self._master_pin}</b> en la pantalla de inicio.</p>
<a class="btn" href="/login">Ir a Iniciar Sesión ➔</a>
</div>
<script>
  // Intento de autoreconexión transparente si el móvil ya se conectó antes
  const devTok = localStorage.getItem('jarvis_device_token');
  if (devTok) {{
    document.getElementById('recon-msg').style.display = 'block';
    fetch('/api/device-login', {{
      method: 'POST',
      headers: {{ 'Content-Type': 'application/json' }},
      body: JSON.stringify({{ device_token: devTok }})
    }})
    .then(r => r.json())
    .then(d => {{
      if (d.ok && d.token) {{
        sessionStorage.setItem('jarvis_token', d.token);
        sessionStorage.setItem('jarvis_key', d.key || '');
        window.location.replace('/');
      }} else {{
        document.getElementById('recon-msg').style.display = 'none';
      }}
    }})
    .catch(() => {{
      document.getElementById('recon-msg').style.display = 'none';
    }});
  }}
</script>
</body></html>""")

            tok     = secrets.token_urlsafe(32)
            dev_tok = secrets.token_urlsafe(32)
            self._tokens.add(tok)
            self._token_keys[tok] = session_key
            self._aes_key(session_key)
            self._device_sessions[dev_tok] = {
                "session_key": session_key,
                "created_at": time.time(),
                "source": "magic_link" if clean_tok else "qr"
            }
            _save_paired_devices(self._device_sessions)

            if self._connect_callback:
                self._connect_callback()
            asyncio.create_task(self.broadcast(
                {"type": "sys", "text": "Remote connection established."}
            ))

            return HTMLResponse(f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>N.E.X.U.S</title>
<style>
  body{{background:#06080d;color:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,sans-serif;
       display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center}}
  .orb{{width:14px;height:14px;border-radius:50%;background:#00f0ff;box-shadow:0 0 16px #00f0ff;margin-bottom:14px;animation:p 1s infinite alternate}}
  @keyframes p{{from{{transform:scale(0.85);opacity:0.6}}to{{transform:scale(1.15);opacity:1}}}}
  p{{color:#00f0ff;font-size:15px;font-weight:600}}
</style></head>
<body>
<div class="orb"></div>
<p>Conectando a N.E.X.U.S…</p>
<script>
  sessionStorage.setItem('jarvis_token','{tok}');
  sessionStorage.setItem('jarvis_key','{session_key}');
  localStorage.setItem('jarvis_device_token','{dev_tok}');
  setTimeout(function(){{location.replace('/')}},250);
</script>
</body></html>""")

        @app.post("/api/device-login")
        async def device_login_ep(req: Request):
            try:
                body = await req.json()
            except Exception:
                return JSONResponse({"ok": False}, status_code=400)
            dev_tok = (body.get("device_token") or "").strip()
            if not dev_tok or dev_tok not in self._device_sessions:
                return JSONResponse({"ok": False}, status_code=401)
            session_key = self._device_sessions[dev_tok]["session_key"]
            tok = secrets.token_urlsafe(32)
            self._tokens.add(tok)
            self._token_keys[tok] = session_key
            self._aes_key(session_key)
            if self._connect_callback:
                self._connect_callback()
            asyncio.create_task(self.broadcast(
                {"type": "sys", "text": "Known device reconnected automatically."}
            ))
            return JSONResponse({"ok": True, "token": tok, "key": session_key})

        @app.post("/api/revoke-devices")
        async def revoke_devices(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            count = len(self._device_sessions)
            self._device_sessions.clear()
            _save_paired_devices(self._device_sessions)
            return JSONResponse({"ok": True, "revoked": count})

        @app.get("/api/network-info")
        async def network_info_ep(req: Request):
            ts = _detect_tailscale()
            return JSONResponse({
                "ok": True,
                "lan_ip": self._ip,
                "port_http": PORT,
                "port_https": PORT + 1,
                "tailscale": ts,
                "ssl_enabled": self._ssl_enabled(),
                "clients_count": len(self._clients)
            })

        @app.post("/api/media")
        async def media_control_ep(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            try:
                body = await req.json()
            except Exception:
                body = {}
            action = body.get("action") or body.get("command") or "play_pause"
            try:
                from actions.media_player import _handle_media_control
                res = _handle_media_control({"action": action})
                return JSONResponse({"ok": True, "result": res})
            except Exception as e:
                return JSONResponse({"ok": False, "error": str(e)}, status_code=500)

        @app.get("/api/screenshot")
        async def screenshot_ep(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            try:
                from actions.screen_processor import _capture_screen
                img_bytes, mime = _capture_screen()
                if not img_bytes:
                    return JSONResponse({"error": "Screenshot failed"}, status_code=500)
                b64 = base64.b64encode(img_bytes).decode("ascii")
                return JSONResponse({
                    "ok": True,
                    "data": f"data:{mime};base64,{b64}",
                    "size": len(img_bytes)
                })
            except Exception as e:
                return JSONResponse({"error": str(e)}, status_code=500)

        @app.post("/api/command")
        async def command(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            body  = await req.json()
            token = req.headers.get("authorization", "").removeprefix("Bearer ").strip()
            enc   = body.get("enc", "")
            text  = ""
            if enc:
                text = self._decrypt(token, enc)
            if not text:
                text = (body.get("text") or "").strip()
            if text:
                asyncio.create_task(self.broadcast({
                    "type": "log",
                    "speaker": "user",
                    "text": text,
                    "ts": datetime.now().isoformat()
                }))
                await self._command_queue.put(text)
                if self._wake_callback:
                    self._wake_callback()
                return JSONResponse({"ok": True})
            return JSONResponse({"error": "Empty command"}, status_code=400)

        @app.post("/api/wake")
        async def wake_ep(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            if self._wake_callback:
                self._wake_callback()
            return JSONResponse({"ok": True})

        # ── Phone mic real-time audio → Gemini Live ──────────────────────────
        @app.websocket("/ws/phone-audio")
        async def phone_audio_ws(websocket: WebSocket, token: str = ""):
            tok = token.strip()
            if not tok or tok not in self._tokens:
                await websocket.close(code=4001)
                return
            await websocket.accept()
            asyncio.create_task(self.broadcast(
                {"type": "sys", "text": "Phone microphone live."}
            ))
            try:
                while True:
                    data = await websocket.receive_bytes()
                    try:
                        self._phone_audio_queue.put_nowait(
                            {"data": data, "mime_type": "audio/pcm"}
                        )
                    except asyncio.QueueFull:
                        pass
            except WebSocketDisconnect:
                pass
            finally:
                asyncio.create_task(self.broadcast(
                    {"type": "sys", "text": "Phone microphone stopped."}
                ))

        # ── File sharing ──────────────────────────────────────────────────────
        def _safe_filename(raw: str) -> str:
            name = Path(raw).name
            name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name).strip(". ")
            return name or "upload"

        if _UPLOAD_OK:
            @app.post("/api/upload")
            async def upload_file(req: Request, file: UploadFile = FastAPIFile(...)):
                if not _auth(req):
                    return JSONResponse({"error": "Unauthorized"}, status_code=401)

                safe = _safe_filename(file.filename or "upload")
                dest = self._uploads_dir / safe
                stem, suffix = Path(safe).stem, Path(safe).suffix
                counter = 1
                while dest.exists():
                    dest = self._uploads_dir / f"{stem}_{counter}{suffix}"
                    counter += 1

                size = 0
                max_bytes = MAX_UPLOAD_MB * 1024 * 1024
                try:
                    with open(dest, "wb") as fout:
                        while True:
                            chunk = await file.read(65536)
                            if not chunk:
                                break
                            size += len(chunk)
                            if size > max_bytes:
                                fout.close()
                                dest.unlink(missing_ok=True)
                                return JSONResponse(
                                    {"error": f"File too large (max {MAX_UPLOAD_MB} MB)"},
                                    status_code=413,
                                )
                            fout.write(chunk)
                except Exception as exc:
                    try:
                        dest.unlink(missing_ok=True)
                    except Exception:
                        pass
                    return JSONResponse({"error": str(exc)}, status_code=500)

                asyncio.create_task(self.broadcast({
                    "type": "file_received",
                    "name": dest.name,
                    "size": size,
                    "saved_to": str(self._uploads_dir),
                }))
                return JSONResponse({"ok": True, "name": dest.name, "size": size})
        else:
            @app.post("/api/upload")
            async def upload_unavailable(req: Request):
                return JSONResponse(
                    {"error": "File uploads require: pip install python-multipart"},
                    status_code=503,
                )

        @app.get("/api/files")
        async def list_files(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            files = []
            try:
                for f in sorted(
                    (p for p in self._uploads_dir.iterdir() if p.is_file()),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True,
                ):
                    files.append({"name": f.name, "size": f.stat().st_size})
            except Exception:
                pass
            return JSONResponse({"files": files})

        @app.get("/uploads/{filename}")
        async def download_file(filename: str, token: str = ""):
            tok = token.strip()
            if not tok or tok not in self._tokens:
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            safe = re.sub(r'[/\\]', '', filename)
            path = self._uploads_dir / safe
            if not path.exists() or not path.is_file():
                return JSONResponse({"error": "Not found"}, status_code=404)
            return FileResponse(str(path), filename=safe)

        @app.websocket("/ws")
        async def ws_ep(websocket: WebSocket, token: str = ""):
            tok = token.strip()
            if not tok or tok not in self._tokens:
                await websocket.close(code=4001)
                return
            await websocket.accept()
            self._clients.add(websocket)
            for entry in self._history[-50:]:
                try:
                    await websocket.send_json(entry)
                except Exception:
                    break
            try:
                while True:
                    data = await websocket.receive_json()
                    if data.get("type") == "command":
                        enc = data.get("enc", "")
                        t   = self._decrypt(tok, enc) if enc else ""
                        if not t:
                            t = (data.get("text") or "").strip()
                        if t:
                            asyncio.create_task(self.broadcast({
                                "type": "log",
                                "speaker": "user",
                                "text": t,
                                "ts": datetime.now().isoformat()
                            }))
                            await self._command_queue.put(t)
                            if self._wake_callback:
                                self._wake_callback()
            except WebSocketDisconnect:
                pass
            finally:
                self._clients.discard(websocket)

        return app

    # ── Serve ─────────────────────────────────────────────────────────────

    async def _serve_https(self) -> None:
        """Second HTTPS server on PORT + 1 (8001) for direct microphone input with Root CA."""
        ssl_key  = BASE_DIR / "config" / "certs" / "jarvis.key"
        ssl_cert = BASE_DIR / "config" / "certs" / "jarvis.crt"
        if not ssl_key.exists() or not ssl_cert.exists():
            return
        asyncio.get_event_loop().run_in_executor(None, _ensure_network_access, PORT + 1)
        cfg = uvicorn.Config(
            self.app, host="0.0.0.0", port=PORT + 1, log_level="warning",
            ssl_keyfile=str(ssl_key), ssl_certfile=str(ssl_cert),
        )
        print(f"[Dashboard] 🔒 HTTPS (Voz y cifrado):  https://{self._ip}:{PORT + 1}")
        await uvicorn.Server(cfg).serve()

    async def serve(self) -> None:
        if not _DEPS_OK:
            print("[Dashboard] fastapi/uvicorn not installed — dashboard disabled.")
            print("[Dashboard] Run:  pip install fastapi 'uvicorn[standard]' cryptography")
            return

        asyncio.get_event_loop().run_in_executor(None, _ensure_network_access, PORT)

        # Generate / check TLS certificate pair with Root CA
        _ensure_certs()

        # Start HTTPS server on Port 8001 concurrently
        if self._ssl_enabled():
            asyncio.create_task(self._serve_https())

        # Main HTTP server on Port 8000 — 0 security warnings, fast mobile pairing
        cfg = uvicorn.Config(
            self.app, host="0.0.0.0", port=PORT, log_level="warning",
        )
        print(f"[Dashboard] ⚡ HTTP (Rápido, sin advertencias): http://{self._ip}:{PORT}")

        ts = _detect_tailscale()
        if ts.get("available") and ts.get("ip"):
            print(f"[Dashboard] 🌐 Tailscale IP:  http://{ts['ip']}:{PORT}")

        print("[Dashboard] Pulsa 'Control Remoto' en la app de escritorio para obtener el código QR.")
        await uvicorn.Server(cfg).serve()
